package uk.me.bstephen.Chess;

import java.io.*;
import java.util.*;
import javax.swing.tree.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;

/**
 * This class represents a Two-mover chess problem.
 *
 * @author Brian Stephenson (2003)
 * @version 1.0
 */

public class ThreeMover extends Problem
{
   private static final int SET = 0;
   private static final int TRY = 1;
   private static final int ACTUAL = 2;
   
   private ArrayList generalClasses;
   private ArrayList setClasses;
   private ArrayList triesClasses;
   private ArrayList keyClasses;
   private LetterGetter lg;
   
   private HashMap setMap;
   
   private boolean sound;
   private MoveList tries;
   private MoveList setPlay;
   private MoveList keys;
   private MoveList triesKeys;
   private boolean setComplete;
   
   private int unprovidedFlights;
   
   
   public ThreeMover(String inName)
   {
      super(inName, new Integer(3));
   }
   
   public ThreeMover()
   {
      super(null, new Integer(3));
      lg = new LetterGetter();
   }
   
   public void solve(boolean verbose)
   {
      long t0 = System.currentTimeMillis();
      
      generalClasses = new ArrayList(20);
      setClasses = new ArrayList(100);
      triesClasses = new ArrayList(100);
      keyClasses = new ArrayList(100);
      
      sound = true;
      unprovidedFlights = 0;
      
      if (brd.isBlackInCheck() == true)
      {
	 sound = false;
      }
      else
      {
	 if (brd.isWhiteInCheck() == false)
	    SET_PLAY:
	    {
	       Iterator i;
	       Iterator ii;
	       MoveList ml;
	       Move m;
	       Move mm;
	       int setMoves;
	       StringBuffer sb;
	       
	       setPlay = brd.generateBlackMoveList(1);
	       setMoves = setPlay.size();
	       i = setPlay.iterator();
	       while (i.hasNext() == true)
	       {
		  sb = new StringBuffer();
		  m = (Move) i.next();
		  brd.makeMove(m);
		  ml = this.firstMove(brd, 2, 0);
		  //if (ml != null)
		  //{
		  // now remove 2nd move tries, which aren't needed.
		  //ii = ml.iterator();
		  //while (ii.hasNext() == true)
		  //{
		  //mm = (Move) ii.next();
		  //if (mm.isKey() == false)
		  //{
		  //ii.remove();
		  //}
		  //}
		  //}
		  
		  if ((ml != null) && (ml.size() != 0))
		  {
		     // Remove long mates where short are present.
		     this.keepMinMates(ml);
		     
		     m.setNext(ml);
		  }
		  else
		  {
		     if (m.getPiece() == 'k')
		     {
			unprovidedFlights++;
		     }
		     
		     i.remove();
		  }
		  brd.undoMove(m);
	       }
	       
	       setPlay.trimToSize();
	       if (setPlay.size() == setMoves)
	       {
		  setComplete = true;
	       }
	       else
	       {
		  setComplete = false;
	       }
	    }
	 else
	 {
	    setPlay = new MoveList(BLACK, 1);
	 }
	 
	 TRIES_AND_KEYS:
	 {
	    Iterator i;
	    Move m;
	    triesKeys = this.first3Move(brd, 1, 1);
	    
	    keys = new MoveList(WHITE, 1);
	    tries = new MoveList(WHITE, 1);
	    
	    if (triesKeys != null)
	    {
	       i = triesKeys.iterator();
	       while (i.hasNext() == true)
	       {
		  m = (Move) i.next();
		  if (m.isKey() == true)
		  {
		     keys.add(m);
		  }
		  else
		  {
		     tries.add(m);
		  }
	       }
	    }
	    
	    if (	(keys == null) ||
	       (keys.size() != 1))
	    {
	       sound = false;
	    }
	 }
      }
      
      long t1 = System.currentTimeMillis();
      runTime = t1 - t0;
   }
   
   public void classify(boolean verbose)
   {
      if (sound == false)
      {
	 generalClasses.add(new String("UNSOUND"));
      }
      else
      {
	 GENERAL_CLASS:
	 {
	    Move wKey;
	    
	    generalClasses.add(new String("WHITE = " + WhitePieces));
	    generalClasses.add(new String("BLACK = " + BlackPieces));
	    generalClasses.add(new String("TOTAL = " + TotalPieces));
	    
	    if (TotalPieces < 8)
	    {
	       generalClasses.add(new String("MINIATURE"));
	    }
	    else if (TotalPieces < 13)
	    {
	       generalClasses.add(new String("MEREDITH"));
	    }
	    else
	    {
	       generalClasses.add(new String("HEAVY"));
	    }
	    
	    if (setPlay == null)
	    {
	       generalClasses.add(new String("SET = 0"));
	    }
	    else
	    {
	       generalClasses.add(new String("SET = " + setPlay.size()));
	    }
	    
	    UNPROVIDED_FLIGHTS:
	    {
	       generalClasses.add(new String("UNPROVIDED_FLIGHTS(" +
		  unprovidedFlights +
		  ")"));
	    }
	    
	    wKey = (Move) keys.get(0);
	    if (wKey.getCheck() == true)
	    {
	       generalClasses.add(new String("CHECKING KEY"));
	    }
	    else if (wKey.getThreat() == null)
	       BLOCK:
	       {
		  if ((setPlay.size() > 0) && (setComplete == true))
		     MUTATE_CHECK:
		     {
			MoveList setBlack = setPlay;
			MoveList blackDefences = wKey.getNext();
			MoveList setMates;
			MoveList actualMates;
			Move var;
			Move defence;
			Move sMate;
			Move aMate;
			Iterator i;
			Iterator j;
			
			generalClasses.add(new String("COMPLETE BLOCK"));
			
			// Now check for mutate.
			//	It's a mutate if a variation (leading to a single mate) in the set play is met by a
			//	different dual-free mate in the actual play.
			
			i = setBlack.iterator();
			while (i.hasNext() == true)
			{
			   var = (Move) i.next();
			   setMates = var.getNext();
			   if (setMates.size() == 1)
			   {
			      j = blackDefences.iterator();
			      while (j.hasNext() == true)
			      {
				 defence = (Move) j.next();
				 if (var.Blackequals(defence) == true)
				 {
				    actualMates = defence.getNext();
				    if (actualMates.size() == 1)
				    {
				       sMate = (Move) setMates.get(0);
				       aMate = (Move) actualMates.get(0);
				       if (sMate.mateEquals(aMate) == false)
				       {
					  generalClasses.add(new String("MUTATE"));
					  break MUTATE_CHECK;
				       }
				    }
				 }
			      }
			   }
			}
		     }
		  else
		  {
		     generalClasses.add(new String("INCOMPLETE BLOCK"));
		  }
	       }
	    else
	       THREAT_PROBLEM:
	       {
		  generalClasses.add(new String("THREAT"));
		  //System.out.println("THREAT");
		  
		  if ((setPlay.size() > 0) && (setComplete == true))
		  {
		     generalClasses.add(new String("BLOCK-THREAT"));
		  }
	       }
	 }
	 
	 SET_PLAY_CLASS:
	 {
	 }
	 
	 TRY_PLAY_CLASS:
	 {
	 }
	 
	 ACTUAL_PLAY_CLASS:
	 {
	 }
	 
      }
   }
   
   public MoveNode enTreeSolution()
   {
      MoveNode root = new MoveNode("Solution");
      
      MoveNode setNode = new MoveNode("Set play");
      MoveNode triesNode = new MoveNode("Tries");
      MoveNode keysNode = new MoveNode("Keys");
      
      
      setPlay.getBlackMoveTree(setNode);
      setNode.pack();
      tries.getWhiteMoveTree(triesNode);
      triesNode.pack();
      keys.getWhiteMoveTree(keysNode);
      keysNode.pack();
      
      root.add(setNode);
      root.add(triesNode);
      root.add(keysNode);
      
      root.pack();
      
      return root;
   }
   
   public MoveNode enTreeClassification()
   {
      int j;
      Iterator i;
      ArrayList al;
      Iterator ij;
      MoveNode root = new MoveNode("Classification");
      
      MoveNode general = new MoveNode("General");
      MoveNode set = new MoveNode("Set");
      MoveNode tries = new MoveNode("Tries");
      MoveNode keys = new MoveNode("keys");
      
      i = generalClasses.iterator();
      while (i.hasNext() == true)
      {
	 general.add(new MoveNode((String) i.next()));
      }
      general.pack();
      
      //i = setClasses.iterator();
      //while (i.hasNext() == true)
      //{
      //	set.add(new MoveNode((String) i.next()));
      //}
      //set.pack();
      
      //i = triesClasses.iterator();
      //j = 0;
      //while (i.hasNext() == true)
      //{
      //	j++;
      //	MoveNode mn = new MoveNode(String.valueOf(j));
      //	tries.add(mn);
      //	al = (ArrayList) i.next();
      //	ij = al.iterator();
      //	while (ij.hasNext() == true)
      //	{
      //		mn.add(new MoveNode((String) ij.next()));
      //	}
      //}
      //tries.pack();
      
      //i = keyClasses.iterator();
      //while (i.hasNext() == true)
      //{
      //	keys.add(new MoveNode((String) i.next()));
      //}
      //keys.pack();
      
      root.add(general);
      root.add(set);
      root.add(tries);
      root.add(keys);
      root.pack();
      
      return root;
   }

   public Document enXMLSolution()
   {
      Document doc = null;
      DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
      
      try
      {
	 DocumentBuilder builder = factory.newDocumentBuilder();
	 doc = builder.newDocument();
	 Element root = (Element) doc.createElement("solution");
	 root.setAttribute("text", "Solution");
	 Element setx = (Element) doc.createElement("setplay");
	 setx.setAttribute("text", "Set play");
	 setPlay.getXMLBlackMoveTree(doc, setx);
	 Element triesx = (Element) doc.createElement("tries");
	 triesx.setAttribute("text", "Tries");
	 tries.getXMLWhiteMoveTree(doc, triesx);
	 Element keysx = (Element) doc.createElement("keys");
	 keysx.setAttribute("text", "Keys");
	 keys.getXMLWhiteMoveTree(doc, keysx);
	 doc.appendChild(root);
	 root.appendChild(setx);
	 root.appendChild(triesx);
	 root.appendChild(keysx);
      }
      
      catch (Exception e)
      {
	 e.printStackTrace();
	 System.exit(1);
      }
      
      return doc;
   }

   public Document enXMLClassification()
   {
       Document doc = null;
      int j;
      Iterator i;
      Iterator ij;
      ArrayList al;
      DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
      
      try
      {
	 DocumentBuilder builder = factory.newDocumentBuilder();
	 doc = builder.newDocument();
	 Element root = (Element) doc.createElement("Classification");
	 root.setAttribute("text", "Classification");
	 Element general = (Element) doc.createElement("General");
	 general.setAttribute("text", "General");
	 Element set = (Element) doc.createElement("Set");
	 set.setAttribute("text", "Set");
	 Element tries = (Element) doc.createElement("Tries");
	 tries.setAttribute("text", "Tries");
	 Element keys = (Element) doc.createElement("Keys");
	 keys.setAttribute("text", "Keys");
	 
	 i = generalClasses.iterator();
	 while (i.hasNext() == true)
	 {
	    Element cl = (Element) doc.createElement("Class");
	    cl.setAttribute("text", (String) i.next());
	    general.appendChild(cl);
	 }
	 
	 i = setClasses.iterator();
	 while (i.hasNext() == true)
	 {
	    Element cl = (Element) doc.createElement("Class");
	    cl.setAttribute("text", (String) i.next());
	    set.appendChild(cl);
	 }
	 
	 i = triesClasses.iterator();
	 j = 0;
	 while (i.hasNext() == true)
	 {
	    j++;
	    Element tr = (Element) doc.createElement("Try");
	    tr.setAttribute("text", String.valueOf(j));
	    tries.appendChild(tr);
	    al = (ArrayList) i.next();
	    ij = al.iterator();
	    while (ij.hasNext() == true)
	    {
	       Element mn = (Element) doc.createElement("Class");
	       mn.setAttribute("text", (String) ij.next());
	       tr.appendChild(mn);
	    }
	 }
	 
	 i = keyClasses.iterator();
	 while (i.hasNext() == true)
	 {
	    Element cl = (Element) doc.createElement("Class");
	    cl.setAttribute("text", (String) i.next());
	    keys.appendChild(cl);
	 }
	 
	 doc.appendChild(root);
	 root.appendChild(general);
	 root.appendChild(set);
	 root.appendChild(tries);
	 root.appendChild(keys);
      }
      catch (Exception e)
      {
	 e.printStackTrace();
	 System.exit(1);
      }
      
      return doc;
  }
   
}