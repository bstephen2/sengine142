package uk.me.bstephen.Chess;

import java.io.*;
import java.util.*;
import javax.swing.tree.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;


/**
 * This class represents a Two-mover chess problem.
 *
 * @author Brian Stephenson (2003)
 * @version 1.0
 */

public class TwoMover extends Problem
{
    private static final int SET = 0;
    private static final int TRY = 1;
    private static final int ACTUAL = 2;

    private ArrayList generalClasses;
    private ArrayList setClasses;
    private ArrayList triesClasses;
    private ArrayList keyClasses;
    private LetterGetter lg;

    private HashMap setMap;

    private boolean sound;
    private MoveList tries;
    private MoveList setPlay;
    private MoveList keys;
    private MoveList triesKeys;
    private boolean setComplete;

    private int unprovidedFlights;
    private int unprovidedChecks;
    private int unprovidedFlightGivers;
    private int unprovidedCaptures;
    private int totalUnprovided;
    private int addedMates;
    private int changedMates;
    private int removedMates;
    private int kingFlights;

    public TwoMover(String inName)
    {
        super(inName, new Integer(2));
    }

    public TwoMover()
    {
        super(null, new Integer(2));
        lg = new LetterGetter();
    }

    public MoveNode enTreeSolution()
    {
        MoveNode root = new MoveNode("Solution");

        MoveNode setNode = new MoveNode("Set play");
        MoveNode triesNode = new MoveNode("Tries");
        MoveNode keysNode = new MoveNode("Keys");

        setPlay.getBlackMoveTree(setNode);
        setNode.pack();
        tries.getWhiteMoveTree(triesNode);
        triesNode.pack();
        keys.getWhiteMoveTree(keysNode);
        keysNode.pack();

        root.add(setNode);
        root.add(triesNode);
        root.add(keysNode);

        root.pack();

        return root;
    }

    public MoveNode enTreeClassification()
    {
        int j;
        Iterator i;
        ArrayList al;
        Iterator ij;
        MoveNode root = new MoveNode("Classification");

        MoveNode general = new MoveNode("General");
        MoveNode set = new MoveNode("Set");
        MoveNode tries = new MoveNode("Tries");
        MoveNode keys = new MoveNode("keys");

        i = generalClasses.iterator();

        while (i.hasNext() == true) {
            general.add(new MoveNode((String) i.next()));
        }

        general.pack();

        i = setClasses.iterator();

        while (i.hasNext() == true) {
            set.add(new MoveNode((String) i.next()));
        }

        set.pack();

        i = triesClasses.iterator();
        j = 0;

        while (i.hasNext() == true) {
            j++;
            MoveNode mn = new MoveNode(String.valueOf(j));
            tries.add(mn);
            al = (ArrayList) i.next();
            ij = al.iterator();

            while (ij.hasNext() == true) {
                mn.add(new MoveNode((String) ij.next()));
            }
        }

        tries.pack();

        i = keyClasses.iterator();

        while (i.hasNext() == true) {
            keys.add(new MoveNode((String) i.next()));
        }

        keys.pack();

        root.add(general);
        root.add(set);
        root.add(tries);
        root.add(keys);
        root.pack();

        return root;
    }

    public void solve(boolean verbose)
    {
        long t0 = System.currentTimeMillis();

        generalClasses = new ArrayList(20);
        setClasses = new ArrayList(100);
        triesClasses = new ArrayList(100);
        keyClasses = new ArrayList(100);

        sound = true;
        unprovidedFlights = 0;
        unprovidedChecks = 0;
        unprovidedFlightGivers = 0;
        unprovidedCaptures = 0;
        totalUnprovided = 0;
        addedMates = 0;
        changedMates = 0;
        removedMates = 0;
        kingFlights = 0;

        if (brd.isBlackInCheck() == true) {
            sound = false;
        } else {
            if (brd.isWhiteInCheck() == false)
                SET_PLAY: {
                Iterator i;
                MoveList ml;
                Move m;
                int setMoves;
                StringBuffer sb;

                setPlay = brd.generateBlackMoveList(1);
                setMoves = setPlay.size();

                // Count king flights, provided or not.
                i = setPlay.iterator();

                while (i.hasNext() == true) {
                    m = (Move) i.next();

                    if (m.getPiece() == 'k') {
                        kingFlights++;
                    }
                }

                i = setPlay.iterator();

                while (i.hasNext() == true) {
                    sb = new StringBuffer();
                    m = (Move) i.next();
                    brd.makeMove(m);
                    ml = this.finalMove(brd, 2);

                    if (ml != null) {
                        m.setNext(ml);
                    } else {
                        if (m.getPiece() == 'k') {
                            unprovidedFlights++;
                        } else {
                            if (m.getCheck() == true) {
                                unprovidedChecks++;
                            }

                            if (m.getCaptures() == true) {
                                unprovidedCaptures++;
                            }

                            int f = 0;
                            MoveList mList = brd.generateBlackMoveList(1);
                            Iterator it = mList.iterator();

                            while (it.hasNext() == true) {
                                Move mov = (Move) it.next();

                                if (mov.getPiece() == 'k') {
                                    f++;
                                }
                            }

                            if (f > kingFlights) {
                                unprovidedFlightGivers++;
                            }

                        }

                        i.remove();
                    }

                    brd.undoMove(m);
                }

                setPlay.trimToSize();

                if (setPlay.size() == setMoves) {
                    setComplete = true;
                } else {
                    setComplete = false;
                }
            } else {
                setPlay = new MoveList(BLACK, 1);
            }

            TRIES_AND_KEYS: {
                Iterator i;
                Move m;
                triesKeys = this.firstMove(brd, 1, 1);

                //	Now split them up between tries and keys.

                keys = new MoveList(WHITE, 1);
                tries = new MoveList(WHITE, 1);

                if (triesKeys != null) {
                    i = triesKeys.iterator();

                    while (i.hasNext() == true) {
                        m = (Move) i.next();

                        if (m.isKey() == true) {
                            keys.add(m);
                        } else {
                            tries.add(m);
                        }
                    }
                }

                if ((keys == null) ||
                        (keys.size() != 1)) {
                    sound = false;
                } else {
                    Move nKey = (Move) keys.get(0);

                    if (nKey.getMate() == true) {
                        sound = false;
                    }
                }
            }
        }

        long t1 = System.currentTimeMillis();
        runTime = t1 - t0;
        //this.printSolution(verbose);
    }



    public void classify(boolean verbose)
    {

        if (sound == false) {
            generalClasses.add(new String("UNSOUND"));
        } else {
            GENERAL_CLASS: {
                Move wKey;

                generalClasses.add(new String("WHITE = " + WhitePieces));
                generalClasses.add(new String("BLACK = " + BlackPieces));
                generalClasses.add(new String("TOTAL = " + TotalPieces));

                if (TotalPieces < 8) {
                    generalClasses.add(new String("MINIATURE"));
                } else if (TotalPieces < 13) {
                    generalClasses.add(new String("MEREDITH"));
                } else {
                    generalClasses.add(new String("HEAVY"));
                }

                if (setPlay == null) {
                    generalClasses.add(new String("SET = 0"));
                } else {
                    generalClasses.add(new String("SET = " + setPlay.size()));
                }

                UNPROVIDED_FLIGHTS: {
                    generalClasses.add(new String("UP_FLIGHTS = " + unprovidedFlights));
                }

                UNPROVIDED_CHECKS: {
                    generalClasses.add(new String("UP_CHECKS = " + unprovidedChecks));
                }

                UNPROVIDED_FLIGHT_GIVERS: {
                    generalClasses.add(new String("UP_FGIVERS = " + unprovidedFlightGivers));
                }

                UNPROVIDED_CAPTURES: {
                    generalClasses.add(new String("UP_CAPS = " + unprovidedCaptures));
                }

                TOTAL_UNPROVIDEDS: {
                    totalUnprovided = unprovidedFlights + unprovidedChecks + unprovidedFlightGivers + unprovidedCaptures;
                    generalClasses.add(new String("TOT_UP = " + totalUnprovided));
                }

                COUNT_MATES: {
                    this.countMates();
                    generalClasses.add(new String("ADDED = " + addedMates));
                    generalClasses.add(new String("CHANGED = " + changedMates));
                    generalClasses.add(new String("REMOVED = " + removedMates));
                }

                wKey = (Move) keys.get(0);

                if (wKey.getCheck() == true) {
                    generalClasses.add(new String("CHECKING KEY"));
                } else if (wKey.getThreat() == null)
                    BLOCK: {
                    if ((setPlay.size() > 0) && (setComplete == true)) {
                        generalClasses.add(new String("COMPLETE BLOCK"));

                        if (changedMates > 0) {
                            generalClasses.add(new String("MUTATE"));
                        }
                    } else {
                        generalClasses.add(new String("INCOMPLETE BLOCK"));
                    }
                } else
                    THREAT_PROBLEM: {
                    generalClasses.add(new String("THREAT"));

                    if ((setPlay.size() > 0) && (setComplete == true)) {
                        generalClasses.add(new String("BLOCK-THREAT"));
                    }
                }
            }

            SET_PLAY_CLASS: {
                Iterator i;
                ClassMap cm = new ClassMap();
                Set st;
                String cl;
                Integer in;
                String ff;

                this.classifyBlackWhite(brd, cm, setPlay, SET);

                // Get all classes and add to setClasses.

                st = cm.keySet();
                i = st.iterator();

                while (i.hasNext() == true) {
                    cl = (String) i.next();
                    in = (Integer) cm.get(cl);
                    ff = new String(cl + "(x" + in.toString() + ")");
                    setClasses.add(ff);
                }
            }

            TRY_PLAY_CLASS: {
                Iterator i;
                Iterator j;
                int k;
                ClassMap cm;
                ArrayList al;
                Set st;
                Move mtry;
                String cl;
                Integer in;
                String ff;
                Move cTry;

                j = tries.iterator();
                k = 0;

                while (j.hasNext() == true) {
                    StringBuffer sb = new StringBuffer();
                    MoveList thr;

                    mtry = (Move) j.next();
                    brd.makeMove(mtry);
                    thr = mtry.getThreat();
                    cm = new ClassMap();
                    cTry  = (Move) tries.get(k);
                    sb.append("TRY_" + cTry.getPiece());

                    if (cTry.getPromotee() != ' ') {
                        sb.append("=" + cTry.getPromotee());
                    }

                    sb.append(new String("(" + lg.getLetter('W', cTry.getId()) + ")"));

                    if (cTry.getCaptures() == true) sb.append('x');

                    cm.addClass(sb.toString());

                    if (thr != null) {
                        int ii;
                        int ij;
                        StringBuffer sbb;
                        boolean bat;
                        char pi;
                        int bkPos;
                        int wmPos;
                        int mDist;

                        for (ii = 0; ii < thr.size(); ii++) {
                            Move mt = (Move) thr.get(ii);
                            sbb = new StringBuffer();
                            brd.makeMove(mt);
                            bkPos = brd.getBKing();
                            wmPos = mt.getTo();
                            mDist = Math.abs(bkPos - wmPos);
                            String checks = brd.getWhiteCheckers(false, mt.getPiece());
                            brd.undoMove(mt);
                            sbb.append("THREAT_");
                            bat = false;

                            for (ij = 0; ij < checks.length(); ij++) {
                                if (checks.charAt(ij) != mt.getPiece()) {
                                    sbb.append(checks.charAt(ij));
                                    bat = true;
                                }
                            }

                            pi = mt.getPiece();
                            sbb.append(pi);

                            if (bat == false) {
                                if (pi == 'B') {
                                    if ((mDist == 11) || (mDist == 13)) {
                                        sbb.append("1");
                                    } else {
                                        sbb.append("n");
                                    }
                                } else if (pi == 'R') {
                                    if ((mDist == 1) || (mDist == 12)) {
                                        sbb.append("1");
                                    } else {
                                        sbb.append("n");
                                    }
                                } else if (pi == 'Q') {
                                    if ((mDist == 13) || (mDist == 11)) {
                                        sbb.append("AB1");
                                    } else if ((mDist == 1) || (mDist == 12)) {
                                        sbb.append("AR1");
                                    } else if ((mDist == 2) || (mDist == 24)) {
                                        sbb.append("AR2");
                                    } else if (((mDist % 11) == 0) || ((mDist % 13) == 0)) {
                                        sbb.append("ABn");
                                    } else {
                                        sbb.append("ARn");
                                    }
                                }
                            }

                            if (mt.getPromotee() != ' ') {
                                sbb.append("=" + mt.getPromotee());
                            }

                            sbb.append(new String("(" + lg.getLetter('W', mt.getId()) + ")"));

                            if (mt.getCaptures() == true) sbb.append('x');

                            cm.addClass(sbb.toString());
                        }
                    }

                    this.classifyBlackWhite(brd, cm, mtry.getNext(), TRY);
                    brd.undoMove(mtry);
                    al = new ArrayList();
                    st = cm.keySet();
                    i = st.iterator();

                    while (i.hasNext() == true) {
                        cl = (String) i.next();
                        in = (Integer) cm.get(cl);
                        ff = new String(cl + "(x" + in.toString() + ")");
                        al.add(ff);
                    }

                    triesClasses.add(al);
                    k++;
                }
            }

            KEY_PLAY_CLASS: {
                Iterator i;
                ClassMap cm = new ClassMap();
                Set st;
                String cl;
                Integer in;
                String ff;
                StringBuffer sb = new StringBuffer();
                MoveList thr;
                Move keyMove = (Move) keys.get(0);
                brd.makeMove(keyMove);
                thr = keyMove.getThreat();
                sb.append("KEY_" + keyMove.getPiece());

                if (keyMove.getPromotee() != ' ') {
                    sb.append("=" + keyMove.getPromotee());
                }

                sb.append(new String("(" + lg.getLetter('W', keyMove.getId()) + ")"));

                if (keyMove.getCaptures() == true) sb.append('x');

                cm.addClass(sb.toString());

                if (thr != null) {
                    int ii;
                    int ij;
                    StringBuffer sbb;
                    int bkPos;
                    int wmPos;
                    int mDist;
                    boolean bat;
                    char pi;

                    for (ii = 0; ii < thr.size(); ii++) {
                        Move mt = (Move) thr.get(ii);
                        sbb = new StringBuffer();
                        brd.makeMove(mt);
                        bkPos = brd.getBKing();
                        wmPos = mt.getTo();
                        mDist = Math.abs(bkPos - wmPos);
                        String checks = brd.getWhiteCheckers(false, mt.getPiece());
                        brd.undoMove(mt);
                        sbb.append("THREAT_");
                        bat = false;

                        for (ij = 0; ij < checks.length(); ij++) {
                            if (checks.charAt(ij) != mt.getPiece()) {
                                sbb.append(checks.charAt(ij));
                                bat = true;
                            }
                        }

                        pi = mt.getPiece();
                        sbb.append(pi);

                        if (bat == false) {
                            if (pi == 'B') {
                                if ((mDist == 11) || (mDist == 13)) {
                                    sbb.append("1");
                                } else {
                                    sbb.append("n");
                                }
                            } else if (pi == 'R') {
                                if ((mDist == 1) || (mDist == 12)) {
                                    sbb.append("1");
                                } else {
                                    sbb.append("n");
                                }
                            } else if (pi == 'Q') {
                                if ((mDist == 13) || (mDist == 11)) {
                                    sbb.append("AB1");
                                } else if ((mDist == 1) || (mDist == 12)) {
                                    sbb.append("AR1");
                                } else if ((mDist == 2) || (mDist == 24)) {
                                    sbb.append("AR2");
                                } else if (((mDist % 11) == 0) || ((mDist % 13) == 0)) {
                                    sbb.append("ABn");
                                } else {
                                    sbb.append("ARn");
                                }
                            }
                        }

                        if (mt.getPromotee() != ' ') {
                            sbb.append("=" + mt.getPromotee());
                        }

                        sbb.append(new String("(" + lg.getLetter('W', mt.getId()) + ")"));

                        if (mt.getCaptures() == true) sbb.append('x');

                        cm.addClass(sbb.toString());
                    }
                }

                this.classifyBlackWhite(brd, cm, keyMove.getNext(), ACTUAL);
                brd.undoMove(keyMove);

                // Get all classes and add to setClasses.

                st = cm.keySet();
                i = st.iterator();

                while (i.hasNext() == true) {
                    cl = (String) i.next();
                    in = (Integer) cm.get(cl);
                    ff = new String(cl + "(x" + in.toString() + ")");
                    keyClasses.add(ff);
                }
            }
        }
    }

    private void classifyCommon(Board inBrd, TreeSet cList, Move bm1, Move mate)
    {
        inBrd.makeMove(mate);

        if (inBrd.isBlackInCheck() == false) {
            inBrd.undoMove(mate);
            return;
        }

        MoveList refuts = inBrd.generateBlackMoveList(2);
        inBrd.undoMove(mate);
        Iterator it = refuts.iterator();
        int bID = bm1.getId();

        while (it.hasNext() == true) {
            StringBuffer p;
            Move rf = (Move) it.next();
            int refId = rf.getId();

            switch (rf.getPiece()) {
            case 'k':
                if (bm1.getTo() == rf.getTo()) {
                    cList.add("BLOCK");
                } else if (bm1.getPiece() != 'k') {
                    cList.add("N_CUT");
                }

                break;

            case 'q':
                if (rf.getId() != bID) {
                    inBrd.makeMove(bm1);
                    inBrd.makeMove(mate);

                    if (inBrd.isBlackPiecePinned(rf.getFrom()) == true) {
                        p = new StringBuffer("PIN_Q(");
                    } else {
                        p = new StringBuffer("CUT_Q(");
                    }

                    p.append(lg.getLetter('b', refId) + ")");
                    cList.add(p.toString());

                    // The moving piece may pin itself also ...
                    if ((bm1.getTo() != mate.getTo()) &&
                            (inBrd.isBlackPiecePinned(bm1.getTo()) == true)) {
                        cList.add("PIN");
                    }

                    inBrd.undoMove(mate);
                    inBrd.undoMove(bm1);
                } else {
                    inBrd.makeMove(bm1);
                    inBrd.makeMove(mate);

                    if ((bm1.getTo() != mate.getTo()) &&
                            (inBrd.isBlackPiecePinned(bm1.getTo()) == true)) {
                        cList.add("PIN");
                    } else {
                        cList.add("N_GUARD");
                    }

                    inBrd.undoMove(mate);
                    inBrd.undoMove(bm1);
                }

                break;

            case 'r':
                if (rf.getId() != bID) {
                    inBrd.makeMove(bm1);
                    inBrd.makeMove(mate);

                    if (inBrd.isBlackPiecePinned(rf.getFrom()) == true) {
                        p = new StringBuffer("PIN_R(");
                    } else {
                        p = new StringBuffer("CUT_R(");
                    }

                    p.append(lg.getLetter('b', refId) + ")");
                    cList.add(p.toString());

                    // The moving piece may pin itself also ...
                    if ((bm1.getTo() != mate.getTo()) &&
                            (inBrd.isBlackPiecePinned(bm1.getTo()) == true)) {
                        cList.add("PIN");
                    }

                    inBrd.undoMove(mate);
                    inBrd.undoMove(bm1);
                } else {
                    inBrd.makeMove(bm1);
                    inBrd.makeMove(mate);

                    if ((bm1.getTo() != mate.getTo()) &&
                            (inBrd.isBlackPiecePinned(bm1.getTo()) == true)) {
                        cList.add("PIN");
                    } else {
                        cList.add("N_GUARD");
                    }

                    inBrd.undoMove(mate);
                    inBrd.undoMove(bm1);
                }

                break;

            case 'b':
                if (rf.getId() != bID) {
                    inBrd.makeMove(bm1);
                    inBrd.makeMove(mate);

                    if (inBrd.isBlackPiecePinned(rf.getFrom()) == true) {
                        p = new StringBuffer("PIN_B(");
                    } else {
                        p = new StringBuffer("CUT_B(");
                    }

                    p.append(lg.getLetter('b', refId) + ")");
                    cList.add(p.toString());

                    // The moving piece may pin itself also ...
                    if ((bm1.getTo() != mate.getTo()) &&
                            (inBrd.isBlackPiecePinned(bm1.getTo()) == true)) {
                        cList.add("PIN");
                    }

                    inBrd.undoMove(mate);
                    inBrd.undoMove(bm1);
                } else {
                    inBrd.makeMove(bm1);
                    inBrd.makeMove(mate);

                    if ((bm1.getTo() != mate.getTo()) &&
                            (inBrd.isBlackPiecePinned(bm1.getTo()) == true)) {
                        cList.add("PIN");
                    } else {
                        cList.add("N_GUARD");
                    }

                    inBrd.undoMove(mate);
                    inBrd.undoMove(bm1);
                }

                break;

            case 's':
                if (rf.getId() != bID) {
                    p = new StringBuffer("PIN_S(");
                    p.append(lg.getLetter('b', refId) + ")");
                    cList.add(p.toString());
                    // The moving piece may pin itself also ...
                    inBrd.makeMove(bm1);
                    inBrd.makeMove(mate);

                    if ((bm1.getTo() != mate.getTo()) &&
                            (inBrd.isBlackPiecePinned(bm1.getTo()) == true)) {
                        cList.add("PIN");
                    }

                    inBrd.undoMove(mate);
                    inBrd.undoMove(bm1);
                } else {
                    inBrd.makeMove(bm1);
                    inBrd.makeMove(mate);

                    if ((bm1.getTo() != mate.getTo()) &&
                            (inBrd.isBlackPiecePinned(bm1.getTo()) == true)) {
                        cList.add("PIN");
                    } else {
                        cList.add("N_GUARD");
                    }

                    inBrd.undoMove(mate);
                    inBrd.undoMove(bm1);
                }

                break;

            case 'p':
                if (rf.getId() != bID) {
                    inBrd.makeMove(bm1);
                    inBrd.makeMove(mate);

                    if (inBrd.isBlackPiecePinned(rf.getFrom()) == true) {
                        p = new StringBuffer("PIN_P(");
                    } else {
                        p = new StringBuffer("CUT_P(");
                    }

                    p.append(lg.getLetter('b', refId) + ")");
                    cList.add(p.toString());

                    // The moving piece may pin itself also ...
                    if ((bm1.getTo() != mate.getTo()) &&
                            (inBrd.isBlackPiecePinned(bm1.getTo()) == true)) {
                        cList.add("PIN");
                    }

                    inBrd.undoMove(mate);
                    inBrd.undoMove(bm1);
                } else {
                    //inBrd.makeMove(bm1);
                    //inBrd.makeMove(mate);
                    //if (inBrd.isBlackPiecePinned(bm1.getTo()) == true)
                    //{
                    //cList.add("PIN");
                    //}
                    //else
                    //{
                    cList.add("N_GUARD");
                    //}
                    //inBrd.undoMove(mate);
                    //inBrd.undoMove(bm1);
                }

                break;
            }
        }
    }

    private void classifyBlackWhite(Board inBrd, ClassMap cm, MoveList bList, int type)
    {
        Iterator i;
        Move bm1;
        int bID;
        //ArrayList cList;
        TreeSet cList;
        int ct;
        boolean n_rguard;
        boolean o_gate;
        boolean n_pinw;
        boolean n_pini;
        boolean cap;
        boolean pcap;
        boolean pgate;
        boolean battery;
        int bkPos;
        int wmPos;
        int mDist;

        if (bList == null) return;

        MoveList wm1 = inBrd.generateWhiteMoveList(1);

        i = bList.iterator();

        while (i.hasNext() == true) {
            StringBuffer sb = new StringBuffer();
            bm1 = (Move) i.next();
            // classify moving black piece
            bID = bm1.getId();
            char bh = bm1.getPiece();

            switch (bh) {
            case 'k':
                sb.append("K(" + lg.getLetter('b', bID) + ")");
                break;

            case 'q':
                sb.append("Q(" + lg.getLetter('b', bID) + ")");
                break;

            case 'r':
                sb.append("R(" + lg.getLetter('b', bID) + ")");
                break;

            case 'b':
                sb.append("B(" + lg.getLetter('b', bID) + ")");
                break;

            case 's':
                sb.append("S(" + lg.getLetter('b', bID) + ")");
                break;

            case 'p':
                sb.append("P(" + lg.getLetter('b', bID) + ")");
                break;
            }

            if (bm1.getCaptures() == true) sb.append('x');

            if (bm1.getCheck() == true) sb.append('+');

            MoveList mates = bm1.getNext();

            if (mates == null) {
                sb.insert(0, "REFUTATION_");
                cm.addClass(sb.toString());
            } else {
                if (mates.size() == 2) {
                    // Deal with P=Q/B and P=Q/R allowable duals by deleting the minor promotion.
                    mates.deleteAllowablePromotions();
                }

                if (mates.size() > 1) {
                    sb.append("/DUALS");
                    cm.addClass(sb.toString());
                } else {
                    boolean moveEnabled = true;
                    cList = new TreeSet();

                    Move mate = (Move) mates.get(0);
                    char matePiece = mate.getPiece();

                    Iterator wi = wm1.iterator();
                    LOOP_1:

                    while (wi.hasNext() == true) {
                        Move om = (Move) wi.next();

                        if (mate.sameMove(om) == true) {
                            moveEnabled = false;
                            break LOOP_1;
                        }
                    }

                    ME_BLOCK:

                    if (moveEnabled == true) {
                        n_rguard = false;
                        o_gate = false;
                        n_pinw = false;
                        n_pini = false;
                        cap = false;
                        pcap = false;
                        pgate = false;

                        // N_RGUARD? (negative guard for royal)

                        if ((bm1.getCaptures() == true) &&
                                (mate.getTo() == bm1.getTo())) {
                            cList.add("CAP");
                            cap = true;
                        }

                        if ((mate.getPiece() == 'K') &&
                                (cap == false)) {
                            cList.add("N_RGUARD");
                            n_rguard = true;
                        }

                        if ((mate.getCaptures() == true) &&
                                (mate.getPiece() == 'P') &&
                                (bm1.getTo() == mate.getTo())) {
                            cList.add("CAP");
                            cap = true;
                            pcap = true;
                        }

                        // O_GATE?

                        if (mate.getPiece() == 'P') {
                            int bmFrom = bm1.getFrom();
                            int mateTo = mate.getTo();

                            if ((bmFrom == mateTo) ||
                                    (mateTo == (bmFrom - 12))) {
                                cList.add("O_GATEA");
                                o_gate = true;
                                pgate = true;
                                // The black mover could also have pinned itself ...
                                inBrd.makeMove(bm1);
                                inBrd.makeMove(mate);

                                if (inBrd.isBlackPiecePinned(bm1.getTo()) == true) {
                                    cList.add("PIN");
                                }

                                inBrd.undoMove(mate);
                                inBrd.undoMove(bm1);
                            }
                        } else if ((mate.getPiece() == 'Q') ||
                                   (mate.getPiece() == 'R') ||
                                   (mate.getPiece() == 'B')) {
                            if (mate.getTo() != bm1.getFrom()) {
                                if (inBrd.isOpenGate(mate.getFrom(), mate.getTo(), bm1.getFrom()) == true) {
                                    cList.add("O_GATEA");
                                    o_gate = true;
                                }
                            }
                        }

                        //	N_PIN? (Black unpin of White)
                        // Make mating move before Black has moved. If White in Check, then unpin.

                        if (mate.getPiece() != 'K') {
                            inBrd.makeMove(mate);
                            boolean ch = inBrd.isWhiteInCheck();
                            inBrd.undoMove(mate);

                            if (ch == true) {
                                if (bm1.getPiece() == 'p') {
                                    cList.add("N_PINI");
                                    n_pini = true;
                                } else if (bm1.getPiece() == 'k') {
                                    cList.add("N_PINI");
                                    n_pini = true;
                                } else if (bm1.getPiece() == 's') {
                                    cList.add("N_PINI");
                                    n_pini = true;
                                } else if (bm1.getPiece() == 'q') {
                                    cList.add("N_PINW");
                                    n_pinw = true;
                                } else {
                                    // BDS B or R
                                    // How to distinguish between withdrawal and interference?

                                    cList.add("N_PIN");
                                }
                            }
                        }

                        if ((pgate == false) && (pcap == false)) {
                            this.classifyCommon(inBrd, cList, bm1, mate);
                        }
                    } else {
                        // not move-enabled.

                        inBrd.makeMove(mate);

                        if (inBrd.isBlackInCheck() == false) {
                            inBrd.undoMove(mate);
                            cList.add("O_GATEB");
                            // The piece could have pinned itself as well ...
                            // The risk is that although some of these moves will indeed be pins
                            // they will not be needed in the mate ...
                            inBrd.makeMove(bm1);
                            inBrd.makeMove(mate);

                            if (inBrd.isBlackPiecePinned(bm1.getTo()) == true) {
                                cList.add("PIN");
                            }

                            inBrd.undoMove(mate);
                            inBrd.undoMove(bm1);
                        } else if (bm1.getPiece() == 'k') {
                            // BDS - Work out whether FLIGHTS or FLIGHTP

                            int diff = Math.abs(bm1.getFrom() - bm1.getTo());
                            inBrd.undoMove(mate);

                            if ((diff == 1) || (diff == 12)) {
                                cList.add("FLIGHTP");
                            } else {
                                cList.add("FLIGHTS");
                            }
                        } else {
                            inBrd.undoMove(mate);
                            this.classifyCommon(inBrd, cList, bm1, mate);
                        }
                    }

                    Iterator tsi = cList.iterator();

                    while (tsi.hasNext() == true) {
                        sb.append((String) tsi.next());

                        if (tsi.hasNext() == true) {
                            sb.append(',');
                        }
                    }

                    sb.append('/');
                    inBrd.makeMove(bm1);
                    inBrd.makeMove(mate);
                    // Classify mating move.
                    char ch = mate.getPiece();

                    battery = false;

                    if (mate.getPromotee() == ' ') {
                        // BDS - Still need to cope with a promotion involved in a battery mate.

                        String checks = inBrd.getWhiteCheckers(false, ch);

                        for (int ij = 0; ij < checks.length(); ij++) {
                            if (checks.charAt(ij) != ch) {
                                sb.append(checks.charAt(ij));
                                battery = true;
                            }
                        }
                    }

                    bkPos = inBrd.getBKing();
                    wmPos = mate.getTo();
                    mDist = Math.abs(bkPos - wmPos);

                    switch (ch) {
                    case 'K':
                        sb.append("K(" + lg.getLetter('W', mate.getId()) + ")");
                        break;

                    case 'Q':
                        sb.append("Q");

                        if ((mDist == 13) || (mDist == 11)) {
                            sb.append("AB1");
                        } else if ((mDist == 1) || (mDist == 12)) {
                            sb.append("AR1");
                        } else if ((mDist == 2) || (mDist == 24)) {
                            sb.append("AR2");
                        } else if (((mDist % 11) == 0) || ((mDist % 13) == 0)) {
                            sb.append("ABn");
                        } else {
                            sb.append("ARn");
                        }

                        sb.append("(" + lg.getLetter('W', mate.getId()) + ")");
                        break;

                    case 'R':
                        sb.append("R");

                        /* distance if not battery */
                        if (battery == false) {
                            if ((mDist == 1) || (mDist == 12)) {
                                sb.append("1");
                            } else {
                                sb.append("n");
                            }

                        }

                        sb.append("(" + lg.getLetter('W', mate.getId()) + ")");
                        break;

                    case 'B':
                        sb.append("B");

                        /* distance if not battery */
                        if (battery == false) {
                            if ((mDist == 11) || (mDist == 13)) {
                                sb.append("1");
                            } else {
                                sb.append("n");
                            }
                        }

                        sb.append("(" + lg.getLetter('W', mate.getId()) + ")");
                        break;

                    case 'S':
                        sb.append("S(" + lg.getLetter('W', mate.getId()) + ")");
                        break;

                    case 'P':
                        sb.append('P');

                        if (mate.getPromotee() != ' ') {
                            sb.append("=" + mate.getPromotee());
                        }

                        sb.append("(" + lg.getLetter('W', mate.getId()) + ")");
                        break;
                    }

                    if (mate.getCaptures() == true) sb.append('x');

                    cm.addClass(sb.toString());
                    inBrd.undoMove(mate);
                    inBrd.undoMove(bm1);
                }
            }
        }
    }

    public Document enXMLSolution()
    {
        Document doc = null;
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

        try {
            DocumentBuilder builder = factory.newDocumentBuilder();
            doc = builder.newDocument();
            Element root = (Element) doc.createElement("solution");
            root.setAttribute("text", "Solution");
            Element setx = (Element) doc.createElement("setplay");
            setx.setAttribute("text", "Set play");
            setPlay.getXMLBlackMoveTree(doc, setx);
            Element triesx = (Element) doc.createElement("tries");
            triesx.setAttribute("text", "Tries");
            tries.getXMLWhiteMoveTree(doc, triesx);
            Element keysx = (Element) doc.createElement("keys");
            keysx.setAttribute("text", "Keys");
            keys.getXMLWhiteMoveTree(doc, keysx);
            doc.appendChild(root);
            root.appendChild(setx);
            root.appendChild(triesx);
            root.appendChild(keysx);
        }

        catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }

        return doc;
    }

    public Document enXMLClassification()
    {
        Document doc = null;
        int j;
        Iterator i;
        Iterator ij;
        ArrayList al;
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

        try {
            DocumentBuilder builder = factory.newDocumentBuilder();
            doc = builder.newDocument();
            Element root = (Element) doc.createElement("Classification");
            root.setAttribute("text", "Classification");
            Element general = (Element) doc.createElement("General");
            general.setAttribute("text", "General");
            Element set = (Element) doc.createElement("Set");
            set.setAttribute("text", "Set");
            Element tries = (Element) doc.createElement("Tries");
            tries.setAttribute("text", "Tries");
            Element keys = (Element) doc.createElement("Keys");
            keys.setAttribute("text", "Keys");

            i = generalClasses.iterator();

            while (i.hasNext() == true) {
                Element cl = (Element) doc.createElement("Class");
                cl.setAttribute("text", (String) i.next());
                general.appendChild(cl);
            }

            i = setClasses.iterator();

            while (i.hasNext() == true) {
                Element cl = (Element) doc.createElement("Class");
                cl.setAttribute("text", (String) i.next());
                set.appendChild(cl);
            }

            i = triesClasses.iterator();
            j = 0;

            while (i.hasNext() == true) {
                j++;
                Element tr = (Element) doc.createElement("Try");
                tr.setAttribute("text", String.valueOf(j));
                tries.appendChild(tr);
                al = (ArrayList) i.next();
                ij = al.iterator();

                while (ij.hasNext() == true) {
                    Element mn = (Element) doc.createElement("Class");
                    mn.setAttribute("text", (String) ij.next());
                    tr.appendChild(mn);
                }
            }

            i = keyClasses.iterator();

            while (i.hasNext() == true) {
                Element cl = (Element) doc.createElement("Class");
                cl.setAttribute("text", (String) i.next());
                keys.appendChild(cl);
            }

            doc.appendChild(root);
            root.appendChild(general);
            root.appendChild(set);
            root.appendChild(tries);
            root.appendChild(keys);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }

        return doc;
    }

    private void countMates()
    {
        Move wKey = (Move) keys.get(0);
        MoveList setBlack = setPlay;
        MoveList blackDefences = wKey.getNext();
        MoveList setMates;
        MoveList actualMates;
        Move var;
        Move defence;
        Move sMate;
        Move aMate;
        Iterator i;
        Iterator j;
        boolean found;

        if (blackDefences == null) {
            blackDefences = new MoveList();
        }

        // Iterate round set variations counting changed and removed.
        // Only inspect variations that a dual-free in set and actual.

        i = setBlack.iterator();

        while (i.hasNext() == true) {
            var = (Move) i.next();
            setMates = var.getNext();

            if (setMates.size() == 1) {
                found = false;
                j = blackDefences.iterator();
                L1:

                while (j.hasNext() == true) {
                    defence = (Move) j.next();

                    if (var.Blackequals(defence) == true) {
                        actualMates = defence.getNext();

                        if (actualMates.size() == 1) {
                            found = true;
                            sMate = (Move) setMates.get(0);
                            aMate = (Move) actualMates.get(0);

                            if (sMate.mateEquals(aMate) == false) {
                                changedMates++;
                            }

                            break L1;
                        }
                    }
                }

                if (found == false) {
                    removedMates++;
                }
            }
        }

        // Iterate round actual variations counting added mates.
        // Inspect dual-free variations only.

        i = blackDefences.iterator();

        while (i.hasNext() == true) {
            defence = (Move) i.next();
            actualMates = defence.getNext();

            if (actualMates.size() == 1) {
                found = false;
                j = setBlack.iterator();
                L2:

                while (j.hasNext() == true) {
                    var = (Move) j.next();

                    if (var.Blackequals(defence) == true) {
                        setMates = var.getNext();

                        if (setMates.size() == 1) {
                            found = true;
                            break L2;
                        }
                    }
                }

                if (found == false) {
                    addedMates++;
                }
            }
        }
    }

}
