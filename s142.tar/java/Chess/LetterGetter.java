package uk.me.bstephen.Chess;

import java.util.*;

public class LetterGetter extends HashMap
{
   public static final String Whites = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
   public static final String Blacks = "abcdefghijklmnopqrstuvwxyz";
   
   private int iWhite;
   private int iBlack;
   
   public LetterGetter()
   {
      super(32);
      iWhite = 0;
      iBlack = 0;
   }
   
   public char getLetter(char inLetter, int inID)
   {
      Integer id = new Integer(inID);
      Character t;
      
      if (this.containsKey(id) == true)
      {
	 t = (Character) this.get(id);
	 return t.charValue();
      }
      else
      {
	 if (Character.isUpperCase(inLetter) == true)
	 {
	    t = new Character(Whites.charAt(iWhite));
	    this.put(id, t);
	    iWhite++;
	    return t.charValue();
	 }
	 else
	 {
	    t = new Character(Blacks.charAt(iBlack));
	    this.put(id, t);
	    iBlack++;
	    return t.charValue();
	 }
      }
   }
}