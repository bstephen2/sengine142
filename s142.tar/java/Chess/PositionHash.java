package uk.me.bstephen.Chess;

import java.util.*;

/**
 *	This class represents a hashtable of positions.
 * @author Brian Stephenson (bstephen@freeuk.com)
 * @version 1.0
 */

public class PositionHash extends Hashtable
{
}
