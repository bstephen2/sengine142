package uk.me.bstephen.Chess;

/**
 * This class represents a knight.
 *
 * @author Brian Stephenson
 * @version 1.0
 */

public class Knight extends Leaper
{
   /**
    *
    */
   
   static int[] moves = { -25, -23, -10, 14, 25, 23, 10, -14 };
   
   /**
    *
    */
   
   public Knight(int inColour)
   {
      super(inColour);
      letter = (inColour == WHITE)? 'S': 's';
   }
   
   /**
    *
    */
   
   public static int[] getMoves()
   {
      return moves;
   }
   
   public int[] getDisplacements()
   {
      return moves;
   }
}