package uk.me.bstephen.Chess;

import java.util.*;

public class ClassMap extends HashMap
{
   public void addClass(String inClass)
   {
      if (this.containsKey(inClass) == true)
      {
	 int i;
	 Integer oldInt = (Integer) this.get(inClass);
	 i = oldInt.intValue() + 1;
	 this.put(inClass, new Integer(i));
      }
      else
      {
	 this.put(inClass, new Integer(1));
      }
   }
}