package uk.me.bstephen.Chess;

import java.util.*;

/**
 *	This class represents a position as stored in the PositionHash.
 * @author Brian Stephenson (bstephen@freeuk.com)
 * @version 1.0
 */

public class Position
{
   private boolean finished;
   private Integer shortestMate;
   private MoveList ml;
   
   public void Position()
   {
      finished = false;
   }
   
   public Integer getFinished()
   {
      return shortestMate;
   }
   
   public void setFinished(boolean inFin)
   {
      finished = inFin;
   }
   
   public Integer getShortestMate()
   {
      return shortestMate;
   }
   
   public void setShortestMate(Integer inSM)
   {
      shortestMate = inSM;
   }
   
   public MoveList getMl()
   {
      return ml;
   }
   
   public void setMl(MoveList inMl)
   {
      ml = inMl;
   }
}
