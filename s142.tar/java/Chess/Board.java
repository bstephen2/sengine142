package uk.me.bstephen.Chess;
import java.util.*;

/**
 *	This class represents the chessboard upon which the testing is carried out. The
 * board is a 12x12, which is the 8x8 board with a two-square rim around the edge.
 * This makes move generation simpler.
 * @author Brian Stephenson (bstephen@freeuk.com)
 * @version 1.0
 */

public class Board implements ChessConstants, Cloneable
{
   
   /**
    *	The 12x12 board implemented as a 144 element array.
    */
   
   private SquareOccupant[] sq;
   
   /**
    * Each square points to what was last captured on it, or Empty.
    */
   
   private Stack[] captures;
   
   /**
    *	Each square points to what was promoted from on it.
    */
   
   private Stack[] promotedPawns;
   
   /**
    *	The index of the square currently occupied by the white king.
    */
   
   private int wKing;
   
   /**
    *	The index of the square currently occupied by the black king.
    */
   
   private int bKing;
   
   /**
    *	The number of white pieces in the diagram position.
    */
   
   private int whitePieces;
   
   /**
    *	The number of black pieces in the diagram position.
    */
   
   private int blackPieces;
   
   /**
    *	The total number of pieces in the diagram position.
    */
   
   private int totalPieces;
   
   /**
    *	This stores the square from which the last move came.
    */
   
   private int to;
   
   /**
    *	This stores the square to which the last move went.
    */
   
   private int from;
   private String ep;
   private String castling;
   
   private static char[] wProms = { 'Q', 'R', 'B', 'S' };
   private static char[] bProms = { 'q', 'r', 'b', 's' };
   
   public Board()
   {
   }
   
   public Object clone()
   {
      Board bd;
      
      try
      {
	 bd = (Board) super.clone();
	 
	 //	All primitives are copied by the above, but now we have to provide
	 //	copies of the objects.
	 //
	 //	SquareOccupant sq[]
	 //	Stack captures[]
	 //	Stack promotedPawns[]
	 
      }
      catch(CloneNotSupportedException cnse)
      {
	 throw new Error("Can't clone a board!");
      }
      
      return bd;
   }
   
   public int getBKing()
   {
      return bKing;
   }
   
   public String getHash()
   {
      int i;
      int j;
      StringBuffer sb = new StringBuffer();
      
      for (i = 26; i < 122; i+=12)
      {
	 for (j = i; j < (i + 8); j++)
	 {
	    sb.append(sq[j].getLetter());
	 }
      }
      
      return sb.toString();
   }
   
   /**
    *
    */
   
   public Board(String Forsythe)
   {
      super();
      
      int i;
      int j;
      char ch;
      StringBuffer sb = null;
      Integer blanks;
      int b;
      int k;
      
      this.initialise();
      
      j = 26;
      i = 0;
      while (i < Forsythe.length())
      {
	 ch = Forsythe.charAt(i);
	 if (ch == '/')
	 {
	    // End of rank marker. Go to next rank.
	    j += 4;
	    i++;
	 }
	 else if (Character.isDigit(ch) == true)
	 {
	    // A digit so here are some empty squares.
	    if (i < (Forsythe.length()) - 1)
	    {
	       ch = Forsythe.charAt(i + 1);
	       if (Character.isDigit(ch) == true)
	       {
		  blanks = Integer.decode(Forsythe.substring(i, i + 2));
		  k = 0;
		  for (b = (blanks.intValue() - 1); b >= 0; b--)
		  {
		     sq[j] = new Empty();
		     k++;
		     if (k == 8)
		     {
			if (b != 0)
			{
			   j += 5;
			}
			else
			{
			   j++;
			}
			k = 0;
		     }
		     else
		     {
			j++;
		     }
		  }
		  i += 2;
	       }
	       else
	       {
		  blanks = Integer.decode(Forsythe.substring(i, i + 1));
		  for (b = 0; b < blanks.intValue(); b++)
		  {
		     sq[j] = new Empty();
		     j++;
		  }
		  i++;
	       }
	    }
	    else
	    {
	       blanks = Integer.decode(Forsythe.substring(i, i + 1));
	       for (b = 0; b < blanks.intValue(); b++)
	       {
		  sq[j] = new Empty();
		  j++;
	       }
	       i++;
	    }
	 }
	 else if (Character.isLetter(ch) == true)
	 {
	    // A piece. So find out which and place it on the board.
	    // Count colours and record king positions.
	    
	    switch (ch)
	    {
	       case 'p':	sq[j] = new Pawn(BLACK);
	       blackPieces++;
	       break;
	       case 'P':	sq[j] = new Pawn(WHITE);
	       whitePieces++;
	       break;
	       case 's':	sq[j] = new Knight(BLACK);
	       blackPieces++;
	       break;
	       case 'S':	sq[j] = new Knight(WHITE);
	       whitePieces++;
	       break;
	       case 'b':	sq[j] = new Bishop(BLACK);
	       blackPieces++;
	       break;
	       case 'B':	sq[j] = new Bishop(WHITE);
	       whitePieces++;
	       break;
	       case 'r':	sq[j] = new Rook(BLACK);
	       blackPieces++;
	       break;
	       case 'R':	sq[j] = new Rook(WHITE);
	       whitePieces++;
	       break;
	       case 'q':	sq[j] = new Queen(BLACK);
	       blackPieces++;
	       break;
	       case 'Q':	sq[j] = new Queen(WHITE);
	       whitePieces++;
	       break;
	       case 'k':	sq[j] = new King(BLACK);
	       blackPieces++;
	       bKing = j;
	       break;
	       case 'K':	sq[j] = new King(WHITE);
	       whitePieces++;
	       wKing = j;
	       break;
	       default: System.out.println("Forsythe error!");
	       return;
	    }
	    j++;
	    i++;
	 }
	 else
	 {
	    System.out.println("Forsythe error!");
	    return;
	 }
      }
      
      totalPieces = whitePieces + blackPieces;
   }
   
   /**
    *
    */
   
   public Board(String Kings, String GBR, String Position, String inEp, String inCastling)
   {
      super();
      int i;
      int j;
      Integer pc;
      int k;
      
      if (inEp == null)
      {
	 ep = new String("");
      }
      else
      {
	 ep = inEp;
      }
      
      if (inCastling == null)
      {
	 castling = new String("");
      }
      else
      {
	 castling = inCastling;
      }
      
      this.initialise();
      for (i = 26; i <=110; i += 12)
      {
	 for (j = i; j < (i + 8); j++)
	 {
	    sq[j] = new Empty();
	 }
      }
      
      // Kings
      
      i = Utils.toInt(Kings.substring(0,2));
      sq[i] = new King(WHITE);
      whitePieces++;
      wKing = i;
      
      i = Utils.toInt(Kings.substring(2,4));
      sq[i] = new King(BLACK);
      blackPieces++;
      bKing = i;
      
      j = 0;
      // White Queens
      pc = Integer.decode(GBR.substring(0, 1));
      i = pc.intValue();
      while ((i % 3) != 0)
      {
	 k = Utils.toInt(Position.substring(j, j + 2));
	 sq[k] = new Queen(WHITE);
	 whitePieces++;
	 j += 2;
	 i--;
      }
      // Black Queens
      while (i >= 3)
      {
	 k = Utils.toInt(Position.substring(j, j + 2));
	 sq[k] = new Queen(BLACK);
	 blackPieces++;
	 j += 2;
	 i -= 3;
      }
      // White Rooks
      pc = Integer.decode(GBR.substring(1, 2));
      i = pc.intValue();
      while ((i % 3) != 0)
      {
	 k = Utils.toInt(Position.substring(j, j + 2));
	 sq[k] = new Rook(WHITE);
	 whitePieces++;
	 j += 2;
	 i--;
      }
      // Black Rooks
      while (i >= 3)
      {
	 k = Utils.toInt(Position.substring(j, j + 2));
	 sq[k] = new Rook(BLACK);
	 blackPieces++;
	 j += 2;
	 i -= 3;
      }
      // White Bishops
      pc = Integer.decode(GBR.substring(2, 3));
      i = pc.intValue();
      while ((i % 3) != 0)
      {
	 k = Utils.toInt(Position.substring(j, j + 2));
	 sq[k] = new Bishop(WHITE);
	 whitePieces++;
	 j += 2;
	 i--;
      }
      // Black Bishops
      while (i >= 3)
      {
	 k = Utils.toInt(Position.substring(j, j + 2));
	 sq[k] = new Bishop(BLACK);
	 blackPieces++;
	 j += 2;
	 i -= 3;
      }
      // White Knights
      pc = Integer.decode(GBR.substring(3, 4));
      i = pc.intValue();
      while ((i % 3) != 0)
      {
	 k = Utils.toInt(Position.substring(j, j + 2));
	 sq[k] = new Knight(WHITE);
	 whitePieces++;
	 j += 2;
	 i--;
      }
      // Black Knights
      while (i >= 3)
      {
	 k = Utils.toInt(Position.substring(j, j + 2));
	 sq[k] = new Knight(BLACK);
	 blackPieces++;
	 j += 2;
	 i -= 3;
      }
      // White Pawns
      pc = Integer.decode(GBR.substring(5, 6));
      i = pc.intValue();
      while (i > 0)
      {
	 k = Utils.toInt(Position.substring(j, j + 2));
	 sq[k] = new Pawn(WHITE);
	 whitePieces++;
	 j += 2;
	 i--;
      }
      // Black Pawns
      pc = Integer.decode(GBR.substring(6, 7));
      i = pc.intValue();
      while (i > 0)
      {
	 k = Utils.toInt(Position.substring(j, j + 2));
	 sq[k] = new Pawn(BLACK);
	 blackPieces++;
	 j += 2;
	 i--;
      }
      
      totalPieces = whitePieces + blackPieces;
   }
   
   /**
    *
    */
   
   private void initialise()
   {
      int i;
      
      sq = new SquareOccupant[144];
      captures = new Stack[144];
      promotedPawns = new Stack[144];
      whitePieces = 0;
      blackPieces = 0;
      totalPieces = whitePieces + blackPieces;
      
      if (ep.compareTo("") == 0)
      {
	 to = 0;
	 from = 0;
      }
      else
      {
	 to = Utils.toInt(ep);
	 from = to - 24;
      }
      
      for (i = 0; i < 144; i++)
      {
	 sq[i] = new Rim();
	 captures[i] = new Stack();
	 promotedPawns[i] = new Stack();
      }
      
      Piece.restartStream();
   }
   
   /**
    *
    */
   
   public int getWhitePieces()
   {
      return whitePieces;
   }
   
   /**
    *
    */
   
   public int getBlackPieces()
   {
      return blackPieces;
   }
   
   /**
    *
    */
   
   public int getTotalPieces()
   {
      return totalPieces;
   }
   
   /**
    *
    */
   
   public int countWhiteCheckers()
   {
      int count = 0;
      int pos;
      int i;
      
      int[] leaperMoves;
      int[] riderMoves;
      
      // Pawn checks?
      
      pos = bKing + 11;
      
      if (sq[pos].getLetter() == 'P')
      {
	 count++;
      }
      
      pos = bKing + 13;
      
      if (sq[pos].getLetter() == 'P')
      {
	 count++;
      }
      
      // Knight checks?
      
      leaperMoves = Knight.getMoves();
      
      for (i = 0; i < leaperMoves.length; i++)
      {
	 pos = bKing + leaperMoves[i];
	 S_CHECK:
	    if (sq[pos].getLetter() == 'S')
	    {
	       count++;
	    }
      }
      
      // Bishop/Queen checks?
      
      riderMoves = Bishop.getMoves();
      
      B_CHECK:
	 for (i = 0; i < riderMoves.length; i++)
	 {
	    pos = bKing + riderMoves[i];
	    while (sq[pos] instanceof Empty)
	    {
	       pos = pos + riderMoves[i];
	    }
	    if (	(sq[pos].getLetter() == 'B') ||
	       (sq[pos].getLetter() == 'Q'))
	    {
	       count++;
	    }
	 }
	 
	 // Rook/Queen checks?
	 
	 riderMoves = Rook.getMoves();
	 R_CHECK:
	    for (i = 0; i < riderMoves.length; i++)
	    {
	       pos = bKing + riderMoves[i];
	       while (sq[pos] instanceof Empty)
	       {
		  pos = pos + riderMoves[i];
	       }
	       if (	(sq[pos].getLetter() == 'R') ||
		  (sq[pos].getLetter() == 'Q'))
	       {
		  count++;
	       }
	    }
	    
	    return count;
   }
   
   public String getWhiteCheckers(boolean actual, char mover)
   {
      StringBuffer sb = new StringBuffer();
      
      int pos;
      int i;
      
      int[] leaperMoves;
      int[] riderMoves;
      
      // Pawn checks?
      
      pos = bKing + 11;
      
      if (sq[pos].getLetter() == 'P')
      {
	 sb.append('P');
      }
      
      pos = bKing + 13;
      
      if (sq[pos].getLetter() == 'P')
      {
	 sb.append('P');
      }
      
      // King checks?
      
      //leaperMoves = King.getMoves();
      
      //for (i = 0; i < leaperMoves.length; i++)
      //{
      //pos = bKing + leaperMoves[i];
      //if (sq[pos].getLetter() == 'K')
      //{
      //return true;
      //}
      //}
      
      // Knight checks?
      
      leaperMoves = Knight.getMoves();
      
      for (i = 0; i < leaperMoves.length; i++)
      {
	 pos = bKing + leaperMoves[i];
	 S_CHECK:
	    if (sq[pos].getLetter() == 'S')
	    {
	       sb.append('S');
	       break S_CHECK;
	    }
      }
      
      // Bishop/Queen checks?
      
      riderMoves = Bishop.getMoves();
      
      B_CHECK:
	 for (i = 0; i < riderMoves.length; i++)
	 {
	    pos = bKing + riderMoves[i];
	    while (sq[pos] instanceof Empty)
	    {
	       pos = pos + riderMoves[i];
	    }
	    if (	(sq[pos].getLetter() == 'B') ||
	       (sq[pos].getLetter() == 'Q'))
	    {
	       if ((actual == false) && (mover != sq[pos].getLetter()))
	       {
		  sb.append('B');
	       }
	       else
	       {
		  sb.append(sq[pos].getLetter());
	       }
	       
	       break B_CHECK;
	    }
	 }
	 
	 // Rook/Queen checks?
	 
	 riderMoves = Rook.getMoves();
	 R_CHECK:
	    for (i = 0; i < riderMoves.length; i++)
	    {
	       pos = bKing + riderMoves[i];
	       while (sq[pos] instanceof Empty)
	       {
		  pos = pos + riderMoves[i];
	       }
	       if (	(sq[pos].getLetter() == 'R') ||
		  (sq[pos].getLetter() == 'Q'))
	       {
		  if ((actual == false) && (mover != sq[pos].getLetter()))
		  {
		     sb.append('R');
		  }
		  else
		  {
		     sb.append(sq[pos].getLetter());
		  }
		  
		  break R_CHECK;
	       }
	    }
	    
	    return sb.toString();
   }
   
   public boolean isBlackInCheck()
   {
      int pos;
      int i;
      
      int[] leaperMoves;
      int[] riderMoves;
      
      // Pawn checks?
      
      pos = bKing + 11;
      
      if (sq[pos].getLetter() == 'P')
      {
	 return true;
      }
      
      pos = bKing + 13;
      
      if (sq[pos].getLetter() == 'P')
      {
	 return true;
      }
      
      // King checks?
      
      leaperMoves = King.getMoves();
      
      for (i = 0; i < leaperMoves.length; i++)
      {
	 pos = bKing + leaperMoves[i];
	 if (sq[pos].getLetter() == 'K')
	 {
	    return true;
	 }
      }
      
      // Knight checks?
      
      leaperMoves = Knight.getMoves();
      
      for (i = 0; i < leaperMoves.length; i++)
      {
	 pos = bKing + leaperMoves[i];
	 if (sq[pos].getLetter() == 'S')
	 {
	    return true;
	 }
      }
      
      // Bishop/Queen checks?
      
      riderMoves = Bishop.getMoves();
      
      for (i = 0; i < riderMoves.length; i++)
      {
	 pos = bKing + riderMoves[i];
	 while (sq[pos] instanceof Empty)
	 {
	    pos = pos + riderMoves[i];
	 }
	 if (	(sq[pos].getLetter() == 'B') ||
	    (sq[pos].getLetter() == 'Q'))
	 {
	    return true;
	 }
      }
      
      // Rook/Queen checks?
      
      riderMoves = Rook.getMoves();
      
      for (i = 0; i < riderMoves.length; i++)
      {
	 pos = bKing + riderMoves[i];
	 while (sq[pos] instanceof Empty)
	 {
	    pos = pos + riderMoves[i];
	 }
	 if (	(sq[pos].getLetter() == 'R') ||
	    (sq[pos].getLetter() == 'Q'))
	 {
	    return true;
	 }
      }
      
      return false;
   }
   
   /**
    *
    */
   
   public boolean isWhiteInCheck()
   {
      int pos;
      int i;
      
      int[] leaperMoves;
      int[] riderMoves;
      
      // Pawn checks?
      
      pos = wKing - 11;
      
      if (sq[pos].getLetter() == 'p')
      {
	 return true;
      }
      
      pos = wKing - 13;
      
      if (sq[pos].getLetter() == 'p')
      {
	 return true;
      }
      
      // King checks?
      
      leaperMoves = King.getMoves();
      
      for (i = 0; i < leaperMoves.length; i++)
      {
	 pos = wKing + leaperMoves[i];
	 if (sq[pos].getLetter() == 'k')
	 {
	    return true;
	 }
      }
      
      // Knight checks?
      
      leaperMoves = Knight.getMoves();
      
      for (i = 0; i < leaperMoves.length; i++)
      {
	 pos = wKing + leaperMoves[i];
	 if (sq[pos].getLetter() == 's')
	 {
	    return true;
	 }
      }
      
      // Bishop/Queen checks?
      
      riderMoves = Bishop.getMoves();
      
      for (i = 0; i < riderMoves.length; i++)
      {
	 pos = wKing + riderMoves[i];
	 while (sq[pos] instanceof Empty)
	 {
	    pos = pos + riderMoves[i];
	 }
	 if (	(sq[pos].getLetter() == 'b') ||
	    (sq[pos].getLetter() == 'q'))
	 {
	    return true;
	 }
      }
      
      // Rook/Queen checks?
      
      riderMoves = Rook.getMoves();
      
      for (i = 0; i < riderMoves.length; i++)
      {
	 pos = wKing + riderMoves[i];
	 while (sq[pos] instanceof Empty)
	 {
	    pos = pos + riderMoves[i];
	 }
	 if (	(sq[pos].getLetter() == 'r') ||
	    (sq[pos].getLetter() == 'q'))
	 {
	    return true;
	 }
      }
      
      return false;
   }
   
   /**
    *
    */
   
   public MoveList generateBlackMoveList(int inNumber)
   {
      int i;
      int j;
      int k;
      int p;
      int pos;
      int[] leaperMoves;
      int[] riderMoves;
      boolean check;
      Move move;
      MoveList ml = new MoveList(BLACK, inNumber);
      SquareOccupant so;
      SquareOccupant capturedPiece;
      Rider rider;
      Leaper leaper;
      Pawn pawn;
      Piece pc;
      
      for (i = 26; i < 122; i+=12)
      {
	 for (j = i; j < (i + 8); j++)
	 {
	    so = sq[j];
	    if (so instanceof Piece)
	    {
	       if (so.getColour() == BLACK)
	       {
		  if (so instanceof Leaper)
		  {
		     leaper = (Leaper) so;
		     leaperMoves = leaper.getDisplacements();
		     for (k = 0; k < leaperMoves.length; k++)
		     {
			pos = j + leaperMoves[k];
			if (	(sq[pos] instanceof Empty)	||
			   (	(sq[pos] instanceof Piece) &&
			   (sq[pos].getColour() == WHITE)))
			{
			   move = new Move((Piece) so, j, pos, so.getLetter());
			   this.makeMove(move);
			   if (this.isBlackInCheck() == false)
			   {
			      move.setCheck(this.isWhiteInCheck());
			      move.setId(leaper.getId());
			      ml.add(move);
			   }
			   this.undoMove(move);
			}
		     }
		  }
		  else if (so instanceof Rider)
		  {
		     rider = (Rider) so;
		     riderMoves = rider.getDisplacements();
		     for (k = 0; k < riderMoves.length; k++)
		     {
			pos = j + riderMoves[k];
			while (sq[pos] instanceof Empty)
			{
			   move = new Move((Piece) so, j, pos, so.getLetter());
			   this.makeMove(move);
			   if (this.isBlackInCheck() == false)
			   {
			      move.setCheck(this.isWhiteInCheck());
			      move.setId(rider.getId());
			      ml.add(move);
			   }
			   this.undoMove(move);
			   pos = pos + riderMoves[k];
			}
			if (	(sq[pos] instanceof Piece) &&
			   (sq[pos].getColour() == WHITE))
			{
			   move = new Move((Piece) so, j, pos, so.getLetter());
			   this.makeMove(move);
			   if (this.isBlackInCheck() == false)
			   {
			      move.setCheck(this.isWhiteInCheck());
			      move.setId(rider.getId());
			      ml.add(move);
			   }
			   this.undoMove(move);
			}
		     }
		  }
		  //else if (so instanceof Pawn)
		  else if (so.getLetter() == 'p')
		  {
		     
		     pawn = (Pawn) so;
		     if ((j >= 98) && (j <=105))
		     {
			// Promoting pawn.
			
			pos = j + 11;
			if (	(sq[pos] instanceof Piece) &&
			   (sq[pos].getColour() == WHITE))
			{
			   for (p = 0; p < 4; p++)
			   {
			      move = new Move((Piece) so, j, pos, 'p', bProms[p]);
			      this.makeMove(move);
			      if (this.isBlackInCheck() == false)
			      {
				 move.setCheck(this.isWhiteInCheck());
				 move.setId(pawn.getId());
				 ml.add(move);
			      }
			      this.undoMove(move);
			   }
			}
			
			pos = j + 13;
			if (	(sq[pos] instanceof Piece) &&
			   (sq[pos].getColour() == WHITE))
			{
			   for (p = 0; p < 4; p++)
			   {
			      move = new Move((Piece) so, j, pos, 'p', bProms[p]);
			      this.makeMove(move);
			      if (this.isBlackInCheck() == false)
			      {
				 move.setCheck(this.isWhiteInCheck());
				 move.setId(pawn.getId());
				 ml.add(move);
			      }
			      this.undoMove(move);
			   }
			}
			
			pos = j + 12;
			if (sq[pos] instanceof Empty)
			{
			   for (p = 0; p < 4; p++)
			   {
			      move = new Move((Piece) so, j, pos, 'p', bProms[p]);
			      this.makeMove(move);
			      if (this.isBlackInCheck() == false)
			      {
				 move.setCheck(this.isWhiteInCheck());
				 move.setId(pawn.getId());
				 ml.add(move);
			      }
			      this.undoMove(move);
			   }
			}
		     }
		     else if ((j >= 38) && (j <= 45))
		     {
			// Pawn on starting square.
			pos = j + 11;
			if (	(sq[pos] instanceof Piece) &&
			   (sq[pos].getColour() == WHITE))
			{
			   move = new Move((Piece) so, j, pos, 'p');
			   this.makeMove(move);
			   if (this.isBlackInCheck() == false)
			   {
			      move.setCheck(this.isWhiteInCheck());
			      move.setId(pawn.getId());
			      ml.add(move);
			   }
			   this.undoMove(move);
			}
			
			pos = j + 13;
			if (	(sq[pos] instanceof Piece) &&
			   (sq[pos].getColour() == WHITE))
			{
			   move = new Move((Piece) so, j, pos, 'p');
			   this.makeMove(move);
			   if (this.isBlackInCheck() == false)
			   {
			      move.setCheck(this.isWhiteInCheck());
			      move.setId(pawn.getId());
			      ml.add(move);
			   }
			   this.undoMove(move);
			}
			
			pos = j + 12;
			if (sq[pos] instanceof Empty)
			{
			   move = new Move((Piece) so, j, pos, 'p');
			   this.makeMove(move);
			   if (this.isBlackInCheck() == false)
			   {
			      move.setCheck(this.isWhiteInCheck());
			      move.setId(pawn.getId());
			      ml.add(move);
			   }
			   this.undoMove(move);
			   
			   pos = j + 24;
			   if (sq[pos] instanceof Empty)
			   {
			      move = new Move((Piece) so, j, pos, 'p');
			      this.makeMove(move);
			      if (this.isBlackInCheck() == false)
			      {
				 move.setCheck(this.isWhiteInCheck());
				 move.setId(pawn.getId());
				 ml.add(move);
			      }
			      this.undoMove(move);
			   }
			}
		     }
		     else if ((j >= 74) && (j <= 81))
		     {
			// Pawn on 5th rank.
			pos = j + 11;
			if (	(sq[pos] instanceof Piece) &&
			   (sq[pos].getColour() == WHITE))
			{
			   move = new Move((Piece) so, j, pos, 'p');
			   this.makeMove(move);
			   if (this.isBlackInCheck() == false)
			   {
			      move.setCheck(this.isWhiteInCheck());
			      move.setId(pawn.getId());
			      ml.add(move);
			   }
			   this.undoMove(move);
			}
			
			pos = j + 13;
			if (	(sq[pos] instanceof Piece) &&
			   (sq[pos].getColour() == WHITE))
			{
			   move = new Move((Piece) so, j, pos, 'p');
			   this.makeMove(move);
			   if (this.isBlackInCheck() == false)
			   {
			      move.setCheck(this.isWhiteInCheck());
			      move.setId(pawn.getId());
			      ml.add(move);
			   }
			   this.undoMove(move);
			}
			
			pos = j + 12;
			if (sq[pos] instanceof Empty)
			{
			   move = new Move((Piece) so, j, pos, 'p');
			   this.makeMove(move);
			   if (this.isBlackInCheck() == false)
			   {
			      move.setCheck(this.isWhiteInCheck());
			      move.setId(pawn.getId());
			      ml.add(move);
			   }
			   this.undoMove(move);
			}
			
			// Do ep. bit.
			
			pos = j - 1;
			if (	(sq[pos] instanceof Pawn) &&
			   (sq[pos].getColour() == WHITE) &&
			   (to == pos) &&
			   (from == (pos + 24)))
			{
			   move = new Move((Piece) so, j, pos, 'p');
			   this.makeMove(move);
			   if (this.isBlackInCheck() == false)
			   {
			      move.setCheck(this.isWhiteInCheck());
			      move.setId(pawn.getId());
			      ml.add(move);
			   }
			   this.undoMove(move);
			}
			
			pos = j + 1;
			if (	(sq[pos] instanceof Pawn) &&
			   (sq[pos].getColour() == WHITE) &&
			   (to == pos) &&
			   (from == (pos + 24)))
			{
			   move = new Move((Piece) so, j, pos, 'p');
			   this.makeMove(move);
			   if (this.isBlackInCheck() == false)
			   {
			      move.setCheck(this.isWhiteInCheck());
			      move.setId(pawn.getId());
			      ml.add(move);
			   }
			   this.undoMove(move);
			}
		     }
		     else
		     {
			// Pawn elsewhere.
			pos = j + 11;
			if (	(sq[pos] instanceof Piece) &&
			   (sq[pos].getColour() == WHITE))
			{
			   move = new Move((Piece) so, j, pos, 'p');
			   this.makeMove(move);
			   if (this.isBlackInCheck() == false)
			   {
			      move.setCheck(this.isWhiteInCheck());
			      move.setId(pawn.getId());
			      ml.add(move);
			   }
			   this.undoMove(move);
			}
			
			pos = j + 13;
			if (	(sq[pos] instanceof Piece) &&
			   (sq[pos].getColour() == WHITE))
			{
			   move = new Move((Piece) so, j, pos, 'p');
			   this.makeMove(move);
			   if (this.isBlackInCheck() == false)
			   {
			      move.setCheck(this.isWhiteInCheck());
			      move.setId(pawn.getId());
			      ml.add(move);
			   }
			   this.undoMove(move);
			}
			
			pos = j + 12;
			if (sq[pos] instanceof Empty)
			{
			   move = new Move((Piece) so, j, pos, 'p');
			   this.makeMove(move);
			   if (this.isBlackInCheck() == false)
			   {
			      move.setCheck(this.isWhiteInCheck());
			      move.setId(pawn.getId());
			      ml.add(move);
			   }
			   this.undoMove(move);
			}
		     }
		  }
		  else
		  {
		     // Error - so throw an exception.
		     System.out.println("ERROR: Generate move!");
		  }
	       }
	    }
	 }
      }
      
      // Castling
      
      if (this.isBlackInCheck() == false)
      {
	 if (bKing == 30)
	 {
	    pc = (Piece) sq[30];
	    if (pc.getMoveCount() == 0)
	    {
	       if (  (castling.indexOf('k') != -1) &&
		     (sq[33] instanceof Rook) &&
		     (sq[31] instanceof Empty) &&
		     (sq[32] instanceof Empty))
	       {
		  pc = (Piece) sq[33];
		  if (	(pc.getMoveCount() == 0) &&
		     (pc.getColour() == BLACK))
		  {
		     move = new Move((Piece) sq[30], 30, 31, 'k');
		     this.makeMove(move);
		     check = this.isBlackInCheck();
		     this.undoMove(move);
		     if (check == false)
		     {
			move = new Move((Piece) sq[30], 30, 32, 'k');
			this.makeMove(move);
			if (this.isBlackInCheck() == false)
			{
			   move.setCheck(this.isWhiteInCheck());
			   move.setId(pc.getId());
			   ml.add(move);
			}
			this.undoMove(move);
		     }
		  }
	       }
	       
	       if (  (castling.indexOf('q') != -1) &&
		     (sq[26] instanceof Rook) &&
		     (sq[27] instanceof Empty) &&
		     (sq[28] instanceof Empty) &&
		     (sq[29] instanceof Empty))
	       {
		  pc = (Piece) sq[26];
		  if (	(pc.getMoveCount() == 0) &&
		     (pc.getColour() == BLACK))
		  {
		     move = new Move((Piece) sq[30], 30, 29, 'k');
		     this.makeMove(move);
		     check = this.isBlackInCheck();
		     this.undoMove(move);
		     if (check == false)
		     {
			move = new Move((Piece) sq[30], 30, 28, 'k');
			this.makeMove(move);
			if (this.isBlackInCheck() == false)
			{
			   move.setCheck(this.isWhiteInCheck());
			   move.setId(pc.getId());
			   ml.add(move);
			}
			this.undoMove(move);
		     }
		  }
	       }
	    }
	 }
      }
      
      ml.trimToSize();
      ml.GenerateAlgebraicNotation();
      
      ml.sortBlackMoveList();
      
      return ml;
   }
   
   public boolean isOpenGate(int mateFrom, int mateTo, int blackFrom)
   {
      Rider rider;
      SquareOccupant so;
      int[] riderMoves;
      int k;
      int pos;
      boolean rc;
      
      rc = false;
      so = sq[mateFrom];
      rider = (Rider) so;
      riderMoves = rider.getDisplacements();
      
      IS_LOOP:
	 for (k = 0; k < riderMoves.length; k++)
	 {
	    pos = mateFrom + riderMoves[k];
	    while (sq[pos] instanceof Empty)
	    {
	       pos = pos + riderMoves[k];
	    }
	    if (	(sq[pos] instanceof Piece) &&
	       (sq[pos].getColour() == BLACK) &&
	       (pos == blackFrom))
	    {
	       pos = pos + riderMoves[k];
	       while (sq[pos] instanceof Empty)
	       {
		  if (pos == mateTo)
		  {
		     rc = true;
		     break IS_LOOP;
		  }
		  pos = pos + riderMoves[k];
	       }
	       if (	(sq[pos] instanceof Piece) &&
		  (sq[pos].getColour() == BLACK) &&
		  (pos == mateTo))
	       {
		  rc = true;
		  break IS_LOOP;
	       }
	    }
	 }
	 
	 return rc;
   }
   
   /**
    *
    */
   
   public MoveList generateWhiteMoveList(int inNumber)
   {
      int i;
      int j;
      int k;
      int p;
      int pos;
      int[] leaperMoves;
      int[] riderMoves;
      boolean check;
      Move move;
      MoveList ml = new MoveList(WHITE, inNumber);
      SquareOccupant so;
      Rider rider;
      Leaper leaper;
      Piece pc;
      Pawn pawn;
      
      for (i = 26; i < 122; i+=12)
      {
	 for (j = i; j < (i + 8); j++)
	 {
	    so = sq[j];
	    if (so instanceof Piece)
	    {
	       if (so.getColour() == WHITE)
	       {
		  if (so instanceof Leaper)
		  {
		     leaper = (Leaper) so;
		     leaperMoves = leaper.getDisplacements();
		     for (k = 0; k < leaperMoves.length; k++)
		     {
			pos = j + leaperMoves[k];
			if (	(sq[pos] instanceof Empty)	||
			   (	(sq[pos] instanceof Piece) &&
			   (sq[pos].getColour() == BLACK)))
			{
			   move = new Move((Piece) so, j, pos, so.getLetter());
			   this.makeMove(move);
			   if (this.isWhiteInCheck() == false)
			   {
			      move.setCheck(this.isBlackInCheck());
			      move.setId(leaper.getId());
			      ml.add(move);
			   }
			   this.undoMove(move);
			}
		     }
		  }
		  else if (so instanceof Rider)
		  {
		     rider = (Rider) so;
		     riderMoves = rider.getDisplacements();
		     for (k = 0; k < riderMoves.length; k++)
		     {
			pos = j + riderMoves[k];
			while (sq[pos] instanceof Empty)
			{
			   move = new Move((Piece) so, j, pos, so.getLetter());
			   this.makeMove(move);
			   if (this.isWhiteInCheck() == false)
			   {
			      move.setCheck(this.isBlackInCheck());
			      move.setId(rider.getId());
			      ml.add(move);
			   }
			   this.undoMove(move);
			   pos = pos + riderMoves[k];
			}
			if (	(sq[pos] instanceof Piece) &&
			   (sq[pos].getColour() == BLACK))
			{
			   move = new Move((Piece) so, j, pos, so.getLetter());
			   this.makeMove(move);
			   if (this.isWhiteInCheck() == false)
			   {
			      move.setCheck(this.isBlackInCheck());
			      move.setId(rider.getId());
			      ml.add(move);
			   }
			   this.undoMove(move);
			}
		     }
		  }
		  else if (so.getLetter() == 'P')
		  {
		     pawn = (Pawn) so;
		     if ((j >= 38) && (j <=45))
		     {
			// Promoting pawn.
			
			pos = j - 11;
			if (	(sq[pos] instanceof Piece) &&
			   (sq[pos].getColour() == BLACK))
			{
			   for (p = 0; p < 4; p++)
			   {
			      move = new Move((Piece) so, j, pos, 'P', wProms[p]);
			      this.makeMove(move);
			      if (this.isWhiteInCheck() == false)
			      {
				 move.setCheck(this.isBlackInCheck());
				 move.setId(pawn.getId());
				 ml.add(move);
			      }
			      this.undoMove(move);
			   }
			}
			
			pos = j - 13;
			if (	(sq[pos] instanceof Piece) &&
			   (sq[pos].getColour() == BLACK))
			{
			   for (p = 0; p < 4; p++)
			   {
			      move = new Move((Piece) so, j, pos, 'P', wProms[p]);
			      this.makeMove(move);
			      if (this.isWhiteInCheck() == false)
			      {
				 move.setCheck(this.isBlackInCheck());
				 move.setId(pawn.getId());
				 ml.add(move);
			      }
			      this.undoMove(move);
			   }
			}
			
			pos = j - 12;
			if (sq[pos] instanceof Empty)
			{
			   for (p = 0; p < 4; p++)
			   {
			      move = new Move((Piece) so, j, pos, 'P', wProms[p]);
			      this.makeMove(move);
			      if (this.isWhiteInCheck() == false)
			      {
				 move.setCheck(this.isBlackInCheck());
				 move.setId(pawn.getId());
				 ml.add(move);
			      }
			      this.undoMove(move);
			   }
			}
		     }
		     else if ((j >= 98) && (j <= 105))
		     {
			// Pawn on starting square.
			pos = j - 11;
			if (	(sq[pos] instanceof Piece) &&
			   (sq[pos].getColour() == BLACK))
			{
			   move = new Move((Piece) so, j, pos, 'P');
			   this.makeMove(move);
			   if (this.isWhiteInCheck() == false)
			   {
			      move.setCheck(this.isBlackInCheck());
			      move.setId(pawn.getId());
			      ml.add(move);
			   }
			   this.undoMove(move);
			}
			
			pos = j - 13;
			if (	(sq[pos] instanceof Piece) &&
			   (sq[pos].getColour() == BLACK))
			{
			   move = new Move((Piece) so, j, pos, 'P');
			   this.makeMove(move);
			   if (this.isWhiteInCheck() == false)
			   {
			      move.setCheck(this.isBlackInCheck());
			      move.setId(pawn.getId());
			      ml.add(move);
			   }
			   this.undoMove(move);
			}
			
			pos = j - 12;
			if (sq[pos] instanceof Empty)
			{
			   move = new Move((Piece) so, j, pos, 'P');
			   this.makeMove(move);
			   if (this.isWhiteInCheck() == false)
			   {
			      move.setCheck(this.isBlackInCheck());
			      move.setId(pawn.getId());
			      ml.add(move);
			   }
			   this.undoMove(move);
			   
			   pos = j - 24;
			   if (sq[pos] instanceof Empty)
			   {
			      move = new Move((Piece) so, j, pos, 'P');
			      this.makeMove(move);
			      if (this.isWhiteInCheck() == false)
			      {
				 move.setCheck(this.isBlackInCheck());
				 move.setId(pawn.getId());
				 ml.add(move);
			      }
			      this.undoMove(move);
			   }
			}
		     }
		     else if ((j >= 62) && (j <= 69))
		     {
			// Pawn on 5th rank.
			pos = j - 11;
			if (	(sq[pos] instanceof Piece) &&
			   (sq[pos].getColour() == BLACK))
			{
			   move = new Move((Piece) so, j, pos, 'P');
			   this.makeMove(move);
			   if (this.isWhiteInCheck() == false)
			   {
			      move.setCheck(this.isBlackInCheck());
			      move.setId(pawn.getId());
			      ml.add(move);
			   }
			   this.undoMove(move);
			}
			
			pos = j - 13;
			if (	(sq[pos] instanceof Piece) &&
			   (sq[pos].getColour() == BLACK))
			{
			   move = new Move((Piece) so, j, pos, 'P');
			   this.makeMove(move);
			   if (this.isWhiteInCheck() == false)
			   {
			      move.setCheck(this.isBlackInCheck());
			      move.setId(pawn.getId());
			      ml.add(move);
			   }
			   this.undoMove(move);
			}
			
			pos = j - 12;
			if (sq[pos] instanceof Empty)
			{
			   move = new Move((Piece) so, j, pos, 'P');
			   this.makeMove(move);
			   if (this.isWhiteInCheck() == false)
			   {
			      move.setCheck(this.isBlackInCheck());
			      move.setId(pawn.getId());
			      ml.add(move);
			   }
			   this.undoMove(move);
			}
			
			// Do ep. bit.
			
			pos = j - 1;
			if (	(sq[pos] instanceof Pawn) &&
			   (sq[pos].getColour() == BLACK) &&
			   (to == pos) &&
			   (from == (pos - 24)))
			{
			   move = new Move((Piece) so, j, pos, 'P');
			   this.makeMove(move);
			   if (this.isWhiteInCheck() == false)
			   {
			      move.setCheck(this.isBlackInCheck());
			      move.setId(pawn.getId());
			      ml.add(move);
			   }
			   this.undoMove(move);
			}
			
			pos = j + 1;
			if (	(sq[pos] instanceof Pawn) &&
			   (sq[pos].getColour() == BLACK) &&
			   (to == pos) &&
			   (from == (pos - 24)))
			{
			   move = new Move((Piece) so, j, pos, 'P');
			   this.makeMove(move);
			   if (this.isWhiteInCheck() == false)
			   {
			      move.setCheck(this.isBlackInCheck());
			      move.setId(pawn.getId());
			      ml.add(move);
			   }
			   this.undoMove(move);
			}
		     }
		     else
		     {
			// Pawn elsewhere.
			pos = j - 11;
			if (	(sq[pos] instanceof Piece) &&
			   (sq[pos].getColour() == BLACK))
			{
			   move = new Move((Piece) so, j, pos, 'P');
			   this.makeMove(move);
			   if (this.isWhiteInCheck() == false)
			   {
			      move.setCheck(this.isBlackInCheck());
			      move.setId(pawn.getId());
			      ml.add(move);
			   }
			   this.undoMove(move);
			}
			
			pos = j - 13;
			if (	(sq[pos] instanceof Piece) &&
			   (sq[pos].getColour() == BLACK))
			{
			   move = new Move((Piece) so, j, pos, 'P');
			   this.makeMove(move);
			   if (this.isWhiteInCheck() == false)
			   {
			      move.setCheck(this.isBlackInCheck());
			      move.setId(pawn.getId());
			      ml.add(move);
			   }
			   this.undoMove(move);
			}
			
			pos = j - 12;
			if (sq[pos] instanceof Empty)
			{
			   move = new Move((Piece) so, j, pos, 'P');
			   this.makeMove(move);
			   if (this.isWhiteInCheck() == false)
			   {
			      move.setCheck(this.isBlackInCheck());
			      move.setId(pawn.getId());
			      ml.add(move);
			   }
			   this.undoMove(move);
			}
		     }
		  }
		  else
		  {
		     // Error - so throw an exception.
		     System.out.println("ERROR: Generate move!");
		  }
	       }
	    }
	 }
      }
      
      // Castling
      
      if (this.isWhiteInCheck() == false)
      {
	 if (wKing == 114)
	 {
	    pc = (Piece) sq[114];
	    if (pc.getMoveCount() == 0)
	    {
	       if (  (castling.indexOf('K') != -1) &&
		     (sq[117] instanceof Rook) &&
		     (sq[115] instanceof Empty) &&
		     (sq[116] instanceof Empty))
	       {
		  pc = (Piece) sq[117];
		  if (	(pc.getMoveCount() == 0) &&
		     (pc.getColour() == WHITE))
		  {
		     move = new Move((Piece) sq[114], 114, 115, 'K');
		     this.makeMove(move);
		     check = this.isWhiteInCheck();
		     this.undoMove(move);
		     if (check == false)
		     {
			move = new Move((Piece) sq[114], 114, 116, 'K');
			this.makeMove(move);
			if (this.isWhiteInCheck() == false)
			{
			   move.setCheck(this.isBlackInCheck());
			   move.setId(pc.getId());
			   ml.add(move);
			}
			this.undoMove(move);
		     }
		  }
	       }
	       if (  (castling.indexOf('Q') != -1) &&
		     (sq[110] instanceof Rook) &&
		     (sq[111] instanceof Empty) &&
		     (sq[112] instanceof Empty) &&
		     (sq[113] instanceof Empty))
	       {
		  pc = (Piece) sq[110];
		  if (	(pc.getMoveCount() == 0) &&
		     (pc.getColour() == WHITE))
		  {
		     move = new Move((Piece) sq[114], 114, 113, 'K');
		     this.makeMove(move);
		     check = this.isWhiteInCheck();
		     this.undoMove(move);
		     if (check == false)
		     {
			move = new Move((Piece) sq[114], 114, 112, 'K');
			this.makeMove(move);
			if (this.isWhiteInCheck() == false)
			{
			   move.setCheck(this.isBlackInCheck());
			   move.setId(pc.getId());
			   ml.add(move);
			}
			this.undoMove(move);
		     }
		  }
	       }
	    }
	 }
      }
      
      ml.trimToSize();
      ml.GenerateAlgebraicNotation();
      
      return ml;
   }
   
   public void makeMove(Move inMove)
   {
      char p;
      char prom;
      int from;
      int to;
      Piece pc;
      
      p = inMove.getPiece();
      from = inMove.getFrom();
      to = inMove.getTo();
      prom = inMove.getPromotee();
      
      // Get rid of special cases first -
      
      if (prom != ' ')
      {
	 // Promotion
	 
	 this.commonMakeMove(inMove);
	 promotedPawns[to].push(sq[to]);
	 switch (prom)
	 {
	    case 'Q':	sq[to] = new Queen(WHITE);
	    break;
	    case 'q':	sq[to] = new Queen(BLACK);
	    break;
	    case 'R':	sq[to] = new Rook(WHITE);
	    break;
	    case 'r':	sq[to] = new Rook(BLACK);
	    break;
	    case 'B':	sq[to] = new Bishop(WHITE);
	    break;
	    case 'b':	sq[to] = new Bishop(BLACK);
	    break;
	    case 'S':	sq[to] = new Knight(WHITE);
	    break;
	    case 's':	sq[to] = new Knight(BLACK);
	    break;
	    default :	System.out.println("Move error!");
	    return;
	 }
      }
      else if (	(p == 'k') &&
	 (from == 30) &&
	 (to == 32))
      {
	 // Black K-side castling.
	 
	 this.commonMakeMove(inMove);
	 sq[31] = sq[33];
	 sq[33] = new Empty();
      }
      else if (	(p == 'k') &&
	 (from == 30) &&
	 (to == 28))
      {
	 // Black Q-side castling.
	 this.commonMakeMove(inMove);
	 sq[29] = sq[26];
	 sq[26] = new Empty();
      }
      else if (	(p == 'K') &&
	 (from == 114) &&
	 (to == 116))
      {
	 // White K-Side castling.
	 this.commonMakeMove(inMove);
	 sq[115] = sq[117];
	 sq[117] = new Empty();
      }
      else if (	(p == 'K') &&
	 (from == 114) &&
	 (to ==112))
      {
	 // White Q-Side castling.
	 this.commonMakeMove(inMove);
	 sq[113] = sq[110];
	 sq[110] = new Empty();
      }
      else if (	(p == 'p') &&
	 (Math.abs(from - to) == 1))
      {
	 // Black ep.
	 pc = (Piece) sq[from];
	 pc.incrementMove();
	 inMove.setCaptures(true);
	 inMove.setSaveFrom(this.from);
	 inMove.setSaveTo(this.to);
	 this.from = from;
	 this.to = to;
	 captures[to].push(sq[to]);
	 sq[to] = new Empty();
	 sq[to + 12] = sq[from];
	 sq[from] = new Empty();
      }
      else if (	(p == 'P') &&
	 (Math.abs(from - to) == 1))
      {
	 // White ep.
	 pc = (Piece) sq[from];
	 pc.incrementMove();
	 inMove.setCaptures(true);
	 inMove.setSaveFrom(this.from);
	 inMove.setSaveTo(this.to);
	 this.from = from;
	 this.to = to;
	 captures[to].push(sq[to]);
	 sq[to] = new Empty();
	 sq[to - 12] = sq[from];
	 sq[from] = new Empty();
      }
      else
      {
	 // Any other move.
	 
	 this.commonMakeMove(inMove);
      }
   }
   
   /**
    *
    */
   
   private void commonMakeMove(Move inMove)
   {
      char p;
      Piece pc;
      
      p = inMove.getPiece();
      inMove.setSaveFrom(from);
      inMove.setSaveTo(to);
      from = inMove.getFrom();
      to = inMove.getTo();
      
      pc = (Piece) sq[from];
      pc.incrementMove();
      if (sq[to] instanceof Piece)
      {
	 inMove.setCaptures(true);
      }
      else
      {
	 inMove.setCaptures(false);
      }
      captures[to].push(sq[to]);
      sq[to] = sq[from];
      sq[from] = new Empty();
      
      
      if (p == 'K')
      {
	 wKing = to;
      }
      
      if (p == 'k')
      {
	 bKing = to;
      }
      
   }
   
   /**
    *
    */
   
   public void undoMove(Move inMove)
   {
      char p;
      char prom;
      int from;
      int to;
      Piece pc;
      
      p = inMove.getPiece();
      from = inMove.getFrom();
      to = inMove.getTo();
      prom = inMove.getPromotee();
      
      // Get rid of special cases first -
      
      if (prom != ' ')
      {
	 // Promotion.
	 
	 sq[to] = (SquareOccupant) promotedPawns[to].pop();
	 this.commonUndoMove(inMove);
      }
      else if (	(p == 'k') &&
	 (from == 30) &&
	 (to == 32))
      {
	 // Black K-side castling.
	 sq[33] = sq[31];
	 sq[31] = new Empty();
	 this.commonUndoMove(inMove);
      }
      else if (	(p == 'k') &&
	 (from == 30) &&
	 (to == 28))
      {
	 // Black Q-side castling.
	 sq[26] = sq[29];
	 sq[29] = new Empty();
	 this.commonUndoMove(inMove);
      }
      else if (	(p == 'K') &&
	 (from == 114) &&
	 (to == 116))
      {
	 // White K-Side castling.
	 sq[117] = sq[115];
	 sq[115] = new Empty();
	 this.commonUndoMove(inMove);
      }
      else if (	(p == 'K') &&
	 (from == 114) &&
	 (to ==112))
      {
	 // White Q-Side castling.
	 sq[110] = sq[113];
	 sq[113] = new Empty();
	 this.commonUndoMove(inMove);
      }
      else if (	(p == 'p') &&
	 (Math.abs(from - to) == 1))
      {
	 // Black ep.
	 
	 pc = (Piece) sq[to + 12];
	 pc.decrementMove();
	 
	 sq[to] = (SquareOccupant) captures[to].pop();
	 sq[from] = sq[to + 12];
	 sq[to + 12] = new Empty();
	 this.from = inMove.getSaveFrom();
	 this.to = inMove.getSaveTo();
      }
      else if (	(p == 'P') &&
	 (Math.abs(from - to) == 1))
      {
	 // White ep.
	 
	 pc = (Piece) sq[to - 12];
	 pc.decrementMove();
	 
	 sq[to] = (SquareOccupant) captures[to].pop();
	 sq[from] = sq[to - 12];
	 sq[to - 12] = new Empty();
	 this.from = inMove.getSaveFrom();
	 this.to = inMove.getSaveTo();
      }
      else
      {
	 // Any other move.
	 
	 this.commonUndoMove(inMove);
      }
   }
   
   /**
    *
    */
   
   private void commonUndoMove(Move inMove)
   {
      char p;
      Piece pc;
      
      p = inMove.getPiece();
      
      pc = (Piece) sq[to];
      pc.decrementMove();
      
      sq[from] = sq[to];
      sq[to] = (SquareOccupant) captures[to].pop();
      
      if (p == 'K')
      {
	 wKing = from;
      }
      
      if (p == 'k')
      {
	 bKing = from;
      }
      
      from = inMove.getSaveFrom();
      to = inMove.getSaveTo();
   }
   
   /**
    *
    */
   
   public boolean isBlackPiecePinned(int s)
   {
      boolean rc;
      
      // Very naughty quick fix to allow for ep captures being to the wrong square.
      if (sq[s] instanceof Empty)
      {
	 s += 12;
      }
      
      int before = this.countWhiteCheckers();
      Piece pc = this.removePiece(s);
      int after = this.countWhiteCheckers();
      this.addPiece(s, pc);
      
      rc = (before == after)? false: true;
      
      return rc;
   }
   
   public Piece removePiece(int s)
   {
      Piece pc = (Piece) sq[s];
      sq[s] = new Empty();
      return pc;
   }
   
   public void addPiece(int s, Piece inP)
   {
      sq[s] = inP;
   }
   
   public void printPosition()
   {
      int i;
      int j;
      
      System.out.println("");
      
      for (i = 0; i <= 132; i += 12)
      {
	 System.out.print("\t");
	 for (j = i; j < (i + 12); j++)
	 {
	    System.out.print(" " + sq[j].getLetter() + " ");
	 }
	 System.out.println("");
      }
      
      System.out.println("");
   }
}