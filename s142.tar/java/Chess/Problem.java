package uk.me.bstephen.Chess;

import java.io.*;
import java.util.*;
import javax.swing.tree.*;
import org.w3c.dom.Document;
/**
 * This abstract class is the superclass for a chess problem for solving.
 *
 * @author Brian Stephenson
 * @version 1.0
 */

public abstract class Problem implements ChessConstants
{
   /**
    *	The Kalulu file name, without the '.prb' suffix.
    */
   
   protected String Name;
   
   /**
    * The board on which the problem is to be solved.
    */
   
   protected Board brd;
   
   /**
    * The epoch time (in milleseconds) when solving started
    */
   
   protected long startTime;
   
   /**
    * The epoch time (in milleseconds) when solving ended and classifying began.
    */
   
   protected long endSolveTime;
   
   /**
    * The epoch time (in milliseconds) when classifying ended.
    */
   
   protected long endClassifyTime;
   
   /**
    * The length of the problem (in White moves!)
    */
   
   protected int length;
   protected int WhitePieces;
   protected int BlackPieces;
   protected int TotalPieces;
   protected int Solutions;
   protected boolean threats;
   protected String ep;
   protected String castling;
   
   protected long runTime;
   
   public Problem(String inName, Integer inLength)
   {
      super();
      Name = inName;
      length = inLength.intValue();
      threats = false;
   }
   
   public void setThreats(boolean inTh)
   {
      threats = inTh;
   }
   
   public void setPosition(String Kings, String GBR, String Position, String inEp, String inCastling)
   {
      ep = inEp;
      castling = inCastling;
      brd = new Board(Kings, GBR, Position, ep, castling);
      WhitePieces = brd.getWhitePieces();
      BlackPieces = brd.getBlackPieces();
      TotalPieces = WhitePieces + BlackPieces;
   }
   
   public void setPosition(String Forsythe)
   {
      brd = new Board(Forsythe);
      WhitePieces = brd.getWhitePieces();
      BlackPieces = brd.getBlackPieces();
      TotalPieces = WhitePieces + BlackPieces;
   }
   
   /**
    * This method prints the position on the console (for debugging).
    */
   
   public void printPosition()
   {
      brd.printPosition();
   }
   
   public String getClassifyTime()
   {
      long ms;
      float et;
      String rc;
      
      ms = endClassifyTime - endSolveTime;
      et = ((float) ms/(float) 1000);
      
      rc = new Float(et).toString();
      
      return rc;
   }
   
   public abstract void solve(boolean verbose);
   public abstract void classify(boolean verbose);
   public abstract MoveNode enTreeClassification();
   public abstract MoveNode enTreeSolution();
   public abstract Document enXMLSolution();
   public abstract Document enXMLClassification();
   
   protected MoveList first3Move(Board inBrd, int moveNumber, int maxRefuts)
   {
      MoveList wm1;
      MoveList bm1;
      MoveList w2ml = null;
      Iterator wi;
      Iterator bi;
      Iterator ii;
      Move wMove;
      Move bMove;
      Move mm;
      boolean posit;
      int refutations;
      
      wm1 = inBrd.generateWhiteMoveList(moveNumber);
      
      wi = wm1.iterator();
      
      while (wi.hasNext() == true)
      {
	 wMove = (Move) wi.next();
	 inBrd.makeMove(wMove);
	 refutations = 0;
	 posit = true;
	 
	 POSIT:
	 {
	    bm1 = inBrd.generateBlackMoveList(moveNumber);
	    if (	(wMove.getCheck() == true) &&
	       (	(bm1 == null) ||
	       (bm1.isEmpty() == true)))
	    {
	       wMove.setMate(true);
	       wMove.setForcedMateIn(moveNumber);
	    }
	    else
	    {
	       if	(	(bm1 == null) ||
		  (bm1.isEmpty() == true))
	       {
		  posit = false;
		  break POSIT;
	       }
	       
	       bi = bm1.iterator();
	       while (bi.hasNext() == true)
	       {
		  bMove = (Move) bi.next();
		  inBrd.makeMove(bMove);
		  w2ml = this.firstMove(inBrd, moveNumber + 1, 0);
		  inBrd.undoMove(bMove);
		  
		  //if (w2ml != null)
		  //{
		  // now remove 2nd move tries, which aren't needed.
		  //ii = w2ml.iterator();
		  //while (ii.hasNext() == true)
		  //{
		  //mm = (Move) ii.next();
		  //if (mm.isKey() == false)
		  //{
		  //ii.remove();
		  //}
		  //}
		  //}
		  
		  if ((w2ml != null) && (w2ml.size() != 0))
		  {
		     // Remove long mates where short are present.
		     this.keepMinMates(w2ml);
		     bMove.setNext(w2ml);
		     w2ml.calcMinMax();
		     bMove.setForcedMateIn(w2ml.getMinForced());
		     w2ml.retainMin();
		     // Remove if short mate.
		     
		     Move tm = (Move) w2ml.get(0);
		     if (tm.getMate() == true)
		     {
			bi.remove();
		     }
		  }
		  else
		  {
		     refutations++;
		     if (refutations > maxRefuts)
		     {
			posit = false;
			break POSIT;
		     }
		  }
		  
		  wMove.setNext(bm1);
		  bm1.calcMinMax();
		  wMove.setForcedMateIn(bm1.getMaxForced());
		  
	       }
	       
	       if (wMove.getCheck() == false)
	       {
		  w2ml = this.firstMove(inBrd, moveNumber + 1, 0);
		  //if (w2ml != null)
		  //{
		  // now remove 2nd move tries, which aren't needed.
		  //ii = w2ml.iterator();
		  //while (ii.hasNext() == true)
		  //{
		  //mm = (Move) ii.next();
		  //if (mm.isKey() == false)
		  //{
		  //ii.remove();
		  //}
		  //}
		  //}
		  
		  if ((w2ml != null) && (w2ml.size() != 0))
		  {
		     wMove.setThreat(w2ml);
		     w2ml.calcMinMax();
		     //w2ml.retainMin();
		     this.weed3Variations(wMove);
		  }
	       }
	    }
	 }
	 
	 if ((posit == false) || ((bm1.size() == 1) && (refutations == 1)))
	 {
	    wi.remove();
	 }
	 else
	 {
	    if (refutations == 0)
	    {
	       wMove.setKey(true);
	    }
	 }
	 
	 inBrd.undoMove(wMove);
      }
      
      if (wm1.isEmpty() == true)
      {
	 wm1 = null;
      }
      else
      {
	 wm1.trimToSize();
      }
      
      return wm1;
   }
   
   protected MoveList first4Move(Board inBrd, int moveNumber, int maxRefuts)
   {
      MoveList wm1;
      MoveList bm1;
      MoveList w2ml = null;
      Iterator wi;
      Iterator bi;
      Iterator ii;
      Move wMove;
      Move bMove;
      Move mm;
      boolean posit;
      int refutations;
      
      wm1 = inBrd.generateWhiteMoveList(moveNumber);
      
      wi = wm1.iterator();
      
      while (wi.hasNext() == true)
      {
	 wMove = (Move) wi.next();
	 inBrd.makeMove(wMove);
	 refutations = 0;
	 posit = true;
	 
	 POSIT:
	 {
	    bm1 = inBrd.generateBlackMoveList(moveNumber);
	    if (	(wMove.getCheck() == true) &&
	       (	(bm1 == null) ||
	       (bm1.isEmpty() == true)))
	    {
	       wMove.setMate(true);
	       wMove.setForcedMateIn(moveNumber);
	    }
	    else
	    {
	       if	(	(bm1 == null) ||
		  (bm1.isEmpty() == true))
	       {
		  posit = false;
		  break POSIT;
	       }
	       
	       bi = bm1.iterator();
	       while (bi.hasNext() == true)
	       {
		  bMove = (Move) bi.next();
		  inBrd.makeMove(bMove);
		  w2ml = this.first3Move(inBrd, moveNumber + 1, 0);
		  inBrd.undoMove(bMove);
		  
		  //if (w2ml != null)
		  //{
		  // now remove 2nd move tries, which aren't needed.
		  //ii = w2ml.iterator();
		  //while (ii.hasNext() == true)
		  //{
		  //mm = (Move) ii.next();
		  //if (mm.isKey() == false)
		  //{
		  //ii.remove();
		  //}
		  //}
		  //}
		  
		  if ((w2ml != null) && (w2ml.size() != 0))
		  {
		     // Remove long mates where short are present.
		     this.keepMinMates(w2ml);
		     bMove.setNext(w2ml);
		     w2ml.calcMinMax();
		     bMove.setForcedMateIn(w2ml.getMinForced());
		     w2ml.retainMin();
		     // Remove if short mate.
		     
		     Move tm = (Move) w2ml.get(0);
		     if (tm.getMate() == true)
		     {
			bi.remove();
		     }
		  }
		  else
		  {
		     refutations++;
		     if (refutations > maxRefuts)
		     {
			posit = false;
			break POSIT;
		     }
		  }
		  
		  wMove.setNext(bm1);
		  bm1.calcMinMax();
		  wMove.setForcedMateIn(bm1.getMaxForced());
		  
	       }
	       
	       if (wMove.getCheck() == false)
	       {
		  w2ml = this.firstMove(inBrd, moveNumber + 1, 0);
		  //if (w2ml != null)
		  //{
		  // now remove 2nd move tries, which aren't needed.
		  //ii = w2ml.iterator();
		  //while (ii.hasNext() == true)
		  //{
		  //mm = (Move) ii.next();
		  //if (mm.isKey() == false)
		  //{
		  //ii.remove();
		  //}
		  //}
		  //}
		  
		  if ((w2ml != null) && (w2ml.size() != 0))
		  {
		     wMove.setThreat(w2ml);
		     w2ml.calcMinMax();
		     //w2ml.retainMin();
		     this.weed3Variations(wMove);
		  }
	       }
	    }
	 }
	 
	 if ((posit == false) || ((bm1.size() == 1) && (refutations == 1)))
	 {
	    wi.remove();
	 }
	 else
	 {
	    if (refutations == 0)
	    {
	       wMove.setKey(true);
	    }
	 }
	 
	 inBrd.undoMove(wMove);
      }
      
      if (wm1.isEmpty() == true)
      {
	 wm1 = null;
      }
      else
      {
	 wm1.trimToSize();
      }
      
      return wm1;
   }
   
   protected void keepMinMates(MoveList mList)
   {
      boolean shortMates = false;
      boolean longMates = false;
      Iterator it;
      Move m;
      
      it = mList.iterator();
      while (it.hasNext() == true)
      {
	 m = (Move) it.next();
	 if (m.getMate() == true)
	 {
	    shortMates = true;
	 }
	 else
	 {
	    longMates = true;
	 }
      }
      
      if ((longMates == true) && (shortMates == true))
      {
	 it = mList.iterator();
	 while (it.hasNext() == true)
	 {
	    m = (Move) it.next();
	    if (m.getMate() == false)
	    {
	       it.remove();
	    }
	 }
      }
   }
   
   protected MoveList firstMove(Board inBrd, int moveNumber, int maxRefuts)
   {
      MoveList wm1;
      MoveList bm1;
      MoveList w2ml = null;
      Iterator wi;
      Iterator bi;
      Move wMove;
      Move bMove;
      boolean posit;
      int refutations;
      
      wm1 = inBrd.generateWhiteMoveList(moveNumber);
      wi = wm1.iterator();
      
      while (wi.hasNext() == true)
      {
	 wMove = (Move) wi.next();
	 inBrd.makeMove(wMove);
	 refutations = 0;
	 posit = true;
	 
	 POSIT:
	 {
	    bm1 = inBrd.generateBlackMoveList(moveNumber);
	    if (	(wMove.getCheck() == true) &&
	       (	(bm1 == null) ||
	       (bm1.isEmpty() == true)))
	    {
	       wMove.setMate(true);
	       wMove.setForcedMateIn(moveNumber);
	    }
	    else
	    {
	       if (	(bm1 ==  null) ||
		  (bm1.isEmpty() == true))
	       {
		  posit = false;
		  break POSIT;
	       }
	       
	       bi = bm1.iterator();
	       while (bi.hasNext() == true)
	       {
		  bMove = (Move) bi.next();
		  inBrd.makeMove(bMove);
		  w2ml = this.finalMove(inBrd, moveNumber + 1);
		  inBrd.undoMove(bMove);
		  if (	(w2ml == null) ||
		     (w2ml .isEmpty() == true))
		  {
		     refutations++;
		     if (refutations > maxRefuts)
		     {
			posit = false;
			break POSIT;
		     }
		  }
		  else
		  {
		     bMove.setNext(w2ml);
		     w2ml.calcMinMax();
		     bMove.setForcedMateIn(w2ml.getMinForced());
		     w2ml.retainMin();
		  }
	       }
	       
	       wMove.setNext(bm1);
	       bm1.calcMinMax();
	       wMove.setForcedMateIn(bm1.getMaxForced());
	       
	       if (wMove.getCheck() == false)
	       {
		  w2ml = this.finalMove(inBrd, moveNumber + 1);
		  
		  if (	(w2ml != null) &&
		     (w2ml.isEmpty() == false))
		  {
		     wMove.setThreat(w2ml);
		     w2ml.calcMinMax();
		     w2ml.retainMin();
		     this.weedVariations(wMove);
		  }
	       }
	    }
	 }
	 if ((posit == false) || ((bm1.size() == 1) && (refutations == 1)))
	 {
	    wi.remove();
	 }
	 else
	 {
	    if (refutations == 0)
	    {
	       wMove.setKey(true);
	    }
	 }
	 
	 inBrd.undoMove(wMove);
      }
      
      if (wm1.isEmpty() == true)
      {
	 wm1 = null;
      }
      else
      {
	 wm1.trimToSize();
      }
      
      return wm1;
   }
   
   protected void weedVariations(Move wMove)
   {
      MoveList thr;
      MoveList bml;
      MoveList wml;
      Iterator iBml;
      Iterator iWml;
      Iterator iT;
      Move bMove;
      Move wm;
      Move tm;
      
      thr = wMove.getThreat();
      bml = wMove.getNext();
      iBml = bml.iterator();
      while (iBml.hasNext() == true)
      {
	 bMove = (Move) iBml.next();
	 wml = bMove.getNext();
	 if (wml != null)
	 {
	    iWml = wml.iterator();
	    L01:
	       while (iWml.hasNext() == true)
	       {
	       wm = (Move) iWml.next();
	       iT = thr.iterator();
	       while (iT.hasNext() == true)
	       {
		  tm = (Move) iT.next();
		  if (wm.equals(tm) == true)
		  {
		     iBml.remove();
		     break L01;
		  }
	       }
	       }
	 }
      }
   }
   
   protected void weed3Variations(Move wMove)
   {
      MoveList thr;
      MoveList bml;
      MoveList wml;
      Iterator iBml;
      Iterator iWml;
      Iterator iT;
      Move bMove;
      Move wm;
      Move tm;
      
      thr = wMove.getThreat();
      bml = wMove.getNext();
      iBml = bml.iterator();
      
      while (iBml.hasNext() == true)
      {
	 bMove = (Move) iBml.next();
	 wml = bMove.getNext();
	 if (wml != null)
	 {
	    iWml = wml.iterator();
	    L001:
	       while (iWml.hasNext() == true)
	       {
	       wm = (Move) iWml.next();
	       iT = thr.iterator();
	       while (iT.hasNext() == true)
	       {
		  tm = (Move) iT.next();
		  if (wm.treeEquals(tm) == true)
		  {
		     iBml.remove();
		     break L001;
		  }
	       }
	       }
	 }
      }
   }
   
   protected MoveList finalMove(Board inBrd, int moveNumber)
   {
      MoveList m1;
      MoveList m2;
      Move m;
      Iterator i;
      
      m1 = inBrd.generateWhiteMoveList(moveNumber);
      
      i = m1.iterator();
      while (i.hasNext() == true)
      {
	 m = (Move) i.next();
	 if (m.getCheck() == false)
	 {
	    i.remove();
	 }
	 else
	 {
	    inBrd.makeMove(m);
	    m2 = inBrd.generateBlackMoveList(moveNumber);
	    inBrd.undoMove(m);
	    if (m2.isEmpty() == true)
	    {
	       m.setForcedMateIn(moveNumber);
	       m.setMate(true);
	    }
	    else
	    {
	       i.remove();
	    }
	    m2 = null;
	 }
      }
      
      if (m1.isEmpty() == true)
      {
	 m1 = null;
      }
      else
      {
	 m1.trimToSize();
      }
      
      return m1;
   }
   
   public long getRunTime()
   {
      return runTime;
   }
}