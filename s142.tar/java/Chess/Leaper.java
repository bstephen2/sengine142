package uk.me.bstephen.Chess;

/**
 * This abstract class represents a leaper.
 *
 * @author Brian Stephenson
 * @version 1.0
 */

public abstract class Leaper extends Piece
{
   public Leaper(int inColour)
   {
      super(inColour);
   }
   
   public abstract int[] getDisplacements();
}