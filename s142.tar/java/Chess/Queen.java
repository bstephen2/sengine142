package uk.me.bstephen.Chess;

/**
 * This class represents a queen.
 *
 * @author Brian Stephenson
 * @version 1.0
 */

public class Queen extends Rider
{
   /**
    *
    */
   
   static int[] moves = { 11, -13, -11, 13, -1, -12, 1, 12};
   
   /**
    *
    */
   
   public Queen(int inColour)
   {
      super(inColour);
      letter = (inColour == WHITE)? 'Q': 'q';
   }
   
   /**
    *
    */
   
   public static int[] getMoves()
   {
      return moves;
   }
   
   public int[] getDisplacements()
   {
      return moves;
   }
}