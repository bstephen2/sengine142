package uk.me.bstephen.Chess;

/**
 * This class represents a king.
 *
 * @author Brian Stephenson
 * @version 1.0
 */

public class King extends Leaper
{
   /**
    *
    */
   
   static int[] moves = { -13, -12, -11, -1, 13, 12, 11, 1 };
   
   /**
    *
    */
   
   public King(int inColour)
   {
      super(inColour);
      letter = (inColour == WHITE)? 'K': 'k';
   }
   
   /**
    *
    */
   
   public static int[] getMoves()
   {
      return moves;
   }
   
   public int[] getDisplacements()
   {
      return moves;
   }
}