package uk.me.bstephen.Chess;

import java.io.*;
import java.util.*;
import javax.swing.tree.*;
import org.w3c.dom.*;

/**
 *	This class represents a list of moves available from a given position.
 * @author Brian Stephenson (bstephen@freeuk.com)
 * @version 1.0
 */

public class MoveList extends ArrayList
{
   private int colour;
   private int moveNumber;
   private int maxForced;
   private int minForced;
   
   public MoveList()
   {
      super(1);
   }
   
   public MoveList(int inColour, int inNumber)
   {
      super(50);
      colour = inColour;
      moveNumber = inNumber;
      maxForced = 0;
      minForced = 0;
   }
   
   public void getXMLBlackMoveTree(Document doc, Element parent)
   {
      Move m;
      Element nd;
      String prefix;
      String suffix;
      Iterator i;
      
      prefix = (moveNumber == 1)? new String("1..."): new String("");
      
      i = this.iterator();
      while (i.hasNext() == true)
      {
	 m = (Move) i.next();
	 suffix = ((moveNumber == 1) && (m.getNext() == null))? new String("!"): new String("");
	 nd = doc.createElement("bmove");
	 //nd.setNodeValue(prefix + m.toString() + suffix);
	 nd.setAttribute("text", prefix + m.toString() + suffix);
	 if (m.getNext() != null)
	 {
	    m.getNext().getXMLWhiteMoveTree(doc, nd);
	 }
	 parent.appendChild(nd);
      }
   }
   
   public void getBlackMoveTree(MoveNode parent)
   {
      Move m;
      MoveNode node;
      String prefix;
      String suffix;
      Iterator i;
      
      prefix = (moveNumber == 1)? new String("1..."): new String("");
      
      i = this.iterator();
      while (i.hasNext() == true)
      {
	 m = (Move) i.next();
	 suffix = ((moveNumber == 1) && (m.getNext() == null))? new String("!"): new String("");
	 node = new MoveNode(prefix + m.toString() + suffix);
	 if (m.getNext() != null)
	 {
	    m.getNext().getWhiteMoveTree(node);
	 }
	 node.pack();
	 parent.add(node);
	 parent.pack();
      }
   }
   
   public void getXMLWhiteMoveTree(Document doc, Element parent)
   {
      Move m;
      Element node;
      Element threat;
      String prefix;
      String suffix;
      Iterator i;
      
      prefix = Integer.toString(moveNumber) + ".";
      
      i = this.iterator();
      while (i.hasNext() == true)
      {
	 m = (Move) i.next();
	 
	 if ((m.isKey() == true) && (moveNumber == 1))
	 {
	    suffix = new String("!");
	 }
	 else if (moveNumber == 1)
	 {
	    suffix = new String("?");
	 }
	 else
	 {
	    suffix = new String("");
	 }
	 node = doc.createElement("wmove");
	 node.setAttribute("text", prefix + m.toString() + suffix);
	 if (m.getThreat() != null)
	 {
	    threat = doc.createElement("threat");
	    threat.setAttribute("text", "threat");
	    m.getThreat().getXMLWhiteMoveTree(doc, threat);
	    node.appendChild(threat);
	 }
	 else if (m.getCheck() == false)
	 {
	    Element block = doc.createElement("block");
	    block.setAttribute("text", "block");
	    node.appendChild(block);
	 }
	 if (m.getNext() != null)
	 {
	    m.getNext().getXMLBlackMoveTree(doc, node);
	 }
	 parent.appendChild(node);
      }
   }
   
   public void getWhiteMoveTree(MoveNode parent)
   {
      Move m;
      MoveNode node;
      MoveNode threat;
      String prefix;
      String suffix;
      Iterator i;
      
      prefix = Integer.toString(moveNumber) + ".";
      
      i = this.iterator();
      while (i.hasNext() == true)
      {
	 m = (Move) i.next();
	 
	 if ((m.isKey() == true) && (moveNumber == 1))
	 {
	    //System.out.println("Added ! in getWhiteMoveTree()");
	    suffix = new String("!");
	 }
	 else if (moveNumber == 1)
	 {
	    //System.out.println("Added ? in getWhiteMoveTree()");
	    suffix = new String("?");
	 }
	 else
	 {
	    //System.out.println("Added blank in getWhiteMoveTree()");
	    suffix = new String("");
	 }
	 
	 node = new MoveNode(prefix + m.toString() + suffix);
	 if (m.getThreat() != null)
	 {
	    threat = new MoveNode("threat");
	    m.getThreat().getWhiteMoveTree(threat);
	    threat.pack();
	    node.add(threat);
	 }
	 else if (m.getCheck() == false)
	 {
	    node.add(new MoveNode("block"));
	 }
	 if (m.getNext() != null)
	 {
	    m.getNext().getBlackMoveTree(node);
	 }
	 node.pack();
	 parent.add(node);
	 parent.pack();
      }
   }
   
   public void deleteAllowablePromotions()
   {
      Move mva;
      Move mvb;
      int mvaid;
      int mvbid;
      int mvaTo;
      int mvbTo;
      
      char mvaPromotee;
      char mvbPromotee;
      
      mva = (Move) this.get(0);
      mvaPromotee = mva.getPromotee();
      if (mvaPromotee != ' ')
      {
	 mvaid = mva.getId();
	 mvaTo = mva.getTo();
	 mvb = (Move) this.get(1);
	 mvbid = mvb.getId();
	 if (mvaid == mvbid)
	 {
	    mvbTo = mvb.getTo();
	    if (mvaTo == mvbTo)
	    {
	       mvbPromotee = mvb.getPromotee();
	       if (mvaPromotee == 'Q')
	       {
		  if ((mvbPromotee == 'R') || (mvbPromotee == 'B'))
		  {
		     this.remove(1);
		  }
	       }
	       else if ((mvaPromotee == 'R') || (mvaPromotee == 'B'))
	       {
		  if (mvbPromotee == 'Q')
		  {
		     this.remove(0);
		  }
	       }
	    }
	 }
      }
      
      return;
   }
   
   public void retainMin()
   {
      Iterator i;
      Move m;
      
      i = this.iterator();
      while (i.hasNext() == true)
      {
	 m = (Move) i.next();
	 if (m.getForcedMateIn() > minForced)
	 {
	    i.remove();
	 }
      }
   }
   
   public void calcMinMax()
   {
      Iterator i;
      int min;
      int max;
      Move ml;
      int j;
      
      min = 32767;
      max = 0;
      
      i = this.iterator();
      while (i.hasNext() == true)
      {
	 ml = (Move) i.next();
	 j = ml.getForcedMateIn();
	 if (min > j)
	 {
	    min = j;
	 }
	 if (max < j)
	 {
	    max = j;
	 }
      }
      
      maxForced = max;
      minForced = min;
   }
   
   public int getMaxForced()
   {
      return maxForced;
   }
   
   public int getMinForced()
   {
      return minForced;
   }
   
   public void setMaxForced(int inMax)
   {
      maxForced = inMax;
   }
   
   public void setMinForced(int inMin)
   {
      minForced = inMin;
   }
   
   public int getMoveNumber()
   {
      return moveNumber;
   }
   
   /**
    *	Generate short algebraic notation.
    */
   
   public void GenerateAlgebraicNotation()
   {
      ArrayList a;
      Iterator i;
      Iterator j;
      Move m;
      Move m1;
      String stm;
      String stm1;
      
      //this.trimToSize();
      
		/*
		 *	Generate the algebraic.
		 */
      
      i = this.iterator();
      
      while (i.hasNext() == true)
      {
	 m = (Move) i.next();
	 m.setStrings();
      }
      
		/*
		 *	Now shorten it
		 */
      
      i = this.iterator();
      
      while (i.hasNext() == true)
      {
	 m = (Move) i.next();
	 a = new ArrayList(4);
	 
	 if (	(m.getPiece() != 'K') &&
	    (m.getPiece() != 'k') &&
	    (m.getPiece() != 'P') &&
	    (m.getPiece() != 'p') &&
	    (m.getInspected() == false))
	 {
	    j = this.iterator();
	    while (j.hasNext() == true)
	    {
	       m1 = (Move) j.next();
	       if (	(m1.getPiece() != 'K') &&
		  (m1.getPiece() != 'k') &&
		  (m1.getPiece() != 'P') &&
		  (m1.getPiece() != 'p') &&
		  (m.getFrom() != m1.getFrom()) &&
		  (m.getTo() == m1.getTo()) &&
		  (m.getPiece() == m1.getPiece()))
	       {
		  a.add(m1);
		  m1.setInspected(true);
	       }
	    }
	    
	    if (a.size() > 1)
	    {
	       // Don't do anything.
	    }
	    else if (a.size() == 1)
	    {
	       // Qualify - there is only two of them;
	       m1 = (Move) a.get(0);
	       stm = m.getStFrom();
	       stm1 = m1.getStFrom();
	       if (stm.charAt(0) == stm1.charAt(0))
	       {
		  stm = new String(stm.substring(1, 2));
		  stm1 = new String(stm1.substring(1, 2));
	       }
	       else
	       {
		  stm = new String(stm.substring(0, 1));
		  stm1 = new String(stm1.substring(0, 1));
	       }
	       m.setStFrom(stm);
	       m1.setStFrom(stm1);
	    }
	    else
	    {
	       //It's a unique move, so shorten it.
	       m.shorten();
	    }
	 }
      }
      
		/*
		 *	Now ready it for printing
		 */
      
      i = this.iterator();
      
      while (i.hasNext() == true)
      {
	 m = (Move) i.next();
	 m.readyForPrinting();
      }
   }
   
   public void printWhiteMoveList(PrintWriter out, StringBuffer sb)
   {
      Move m;
      StringBuffer osb;
      StringBuffer msb;
      String prefix;
      Iterator i;
      int l;
      int k;
      
      osb = sb;
      
      prefix = new String(moveNumber + ".");
      
      i = this.iterator();
      while (i.hasNext() == true)
      {
	 m = (Move) i.next();
	 msb = new StringBuffer(prefix);
	 msb.append(m.getStMove());
	 if (m.isKey() == true)
	 {
	    msb.append("!");
	 }
	 else if (moveNumber == 1)
	 {
	    msb.append("?");
	 }
	 l = msb.length();
	 l = (10 - l);
	 for (k = 0; k < l; k++)
	 {
	    msb.append(' ');
	 }
	 osb.append(msb.toString());
	 if (m.getThreat() != null)
	 {
	    if (moveNumber == 1)
	    {
	       osb.append(" (");
	    }
	    else
	    {
	       osb.append("       (");
	    }
	    m.getThreat().printWhiteMoveList(out, osb);
	 }
	 if (m.getNext() == null)
	 {
	    out.println(osb.toString());
	    if (moveNumber == 1)
	    {
	       out.println();
	    }
	 }
	 else
	 {
	    if (moveNumber == 1)
	    {
	       if (m.getThreat() == null)
	       {
		  out.println(osb.toString());
	       }
	       out.println();
	       osb = new StringBuffer();
	    }
	    m.getNext().printBlackMoveList(out, osb);
	    if (moveNumber == 1)
	    {
	       out.println();
	    }
	 }
	 osb = new StringBuffer();
	 l = ((moveNumber - 1) * 18) - 6;
	 for (k = 0; k < l; k++)
	 {
	    osb.append(' ');
	 }
      }
   }
   
   public void printBlackMoveList(PrintWriter out, StringBuffer sb)
   {
      Move m;
      StringBuffer osb;
      StringBuffer msb;
      String prefix;
      Iterator i;
      int l;
      int k;
      
      osb = sb;
      
      if (moveNumber == 1)
      {
	 prefix = new String("1...");
      }
      else
      {
	 prefix = new String("");
      }
      
      i = this.iterator();
      while (i.hasNext() == true)
      {
	 m = (Move) i.next();
	 msb = new StringBuffer(prefix);
	 msb.append(m.getStMove());
	 if (	(moveNumber == 1) &&
	    (m.getNext() == null))
	 {
	    msb.append("!");
	 }
	 l = msb.length();
	 l = (moveNumber == 1)? (12 - l): (8 - l);
	 for (k = 0; k < l; k++)
	 {
	    msb.append(' ');
	 }
	 osb.append(msb.toString());
	 if (m.getNext() == null)
	 {
	    out.println(osb.toString());
	 }
	 else
	 {
	    m.getNext().printWhiteMoveList(out, osb);
	 }
	 osb = new StringBuffer();
	 if (moveNumber != 1)
	 {
	    l = ((moveNumber - 1)*18) + 4;
	    for (k = 0; k < l; k++)
	    {
	       osb.append(' ');
	    }
	 }
      }
   }
   
   /**
    *	Sort the Black MoveList so that it is in order of
    *
    *	(1)	checks
    *	(2)	flights
    *	(3)	promotions
    *	(4)	captures
    *	(5)	others
    *
    *	Perhaps add killer heuristic later!
    */
   
   public void sortBlackMoveList()
   {
      Move move;
      ArrayList strongMoves;
      Iterator i;
      
      strongMoves = new ArrayList(20);
      
      // Captures
      i = this.iterator();
      while (i.hasNext() == true)
      {
	 move = (Move) i.next();
	 if (move.getCaptures() == true)
	 {
	    strongMoves.add(move);
	    i.remove();
	 }
      }
      
      if (strongMoves.isEmpty() != true)
      {
	 this.addAll(0, strongMoves);
      }
      
      // promotions
      
      strongMoves.clear();
      i = this.iterator();
      while (i.hasNext() == true)
      {
	 move = (Move) i.next();
	 if (move.getPromotee() != ' ')
	 {
	    strongMoves.add(move);
	    i.remove();
	 }
      }
      
      if (strongMoves.isEmpty() != true)
      {
	 this.addAll(0, strongMoves);
      }
      
      // Flights
      
      strongMoves.clear();
      i = this.iterator();
      while (i.hasNext() == true)
      {
	 move = (Move) i.next();
	 if (move.getPiece() == 'k')
	 {
	    strongMoves.add(move);
	    i.remove();
	 }
      }
      
      if (strongMoves.isEmpty() != true)
      {
	 this.addAll(0, strongMoves);
      }
      
      // Checks
      
      strongMoves.clear();
      i = this.iterator();
      while (i.hasNext() == true)
      {
	 move = (Move) i.next();
	 if (move.getCheck() == true)
	 {
	    strongMoves.add(move);
	    i.remove();
	 }
      }
      
      if (strongMoves.isEmpty() != true)
      {
	 this.addAll(0, strongMoves);
      }
   }
}
