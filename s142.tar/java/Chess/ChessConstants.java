package uk.me.bstephen.Chess;

/**
 *	This interface contains all the constant definitions used in package
 * com.freeuk.bstephen.chess.
 * @author Brian Stephenson
 * @version 1.0
 */

public interface ChessConstants
{
   public static final int WHITE = 1;
   public static final int BLACK = 2;
}