package uk.me.bstephen.Chess;

/**
 *	This abstract class represents something that occupies a square on the chessboard.
 * @author Brian Stephenson (bstephen@freeuk.com)
 * @version 1.0
 */

public abstract class SquareOccupant implements ChessConstants, Cloneable
{
   protected char letter;
   protected int colour;
   
   public SquareOccupant()
   {
      super();
   }
   
   public Object clone()
   {
      SquareOccupant so;
      
      try
      {
	 so = (SquareOccupant) super.clone();
	 return so;
      }
      catch(CloneNotSupportedException cnse)
      {
	 throw new Error("Can't clone SquareOccupant!");
      }
   }
   
   public char getLetter()
   {
      return letter;
   }
   
   public int getColour()
   {
      return colour;
   }
}