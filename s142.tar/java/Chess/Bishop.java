package uk.me.bstephen.Chess;

/**
 * This class represents a bishop.
 *
 * @author Brian Stephenson
 * @version 1.0
 */

public class Bishop extends Rider
{
   static int[] moves = { 11, -13, -11, 13 };
   
   /**
    *
    */
   
   public Bishop(int inColour)
   {
      super(inColour);
      letter = (inColour == WHITE)? 'B': 'b';
   }
   
   /**
    *
    */
   
   public static int[] getMoves()
   {
      return moves;
   }
   
   public int[] getDisplacements()
   {
      return moves;
   }
}