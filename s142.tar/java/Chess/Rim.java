package uk.me.bstephen.Chess;

/**
 * This class represents a rim square.
 */

public class Rim extends SquareOccupant
{
   public Rim()
   {
      super();
      letter = 'X';
   }
}