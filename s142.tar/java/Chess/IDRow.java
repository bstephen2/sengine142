package uk.me.bstephen.Chess;

public class IDRow
{
   int id;
   char letter;
   
   public IDRow()
   {
   }
}
