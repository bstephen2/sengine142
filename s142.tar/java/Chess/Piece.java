package uk.me.bstephen.Chess;

/**
 * This abstract class represents a piece.
 *
 * @author Brian Stephenson
 * @version 1.0
 */

public abstract class Piece extends SquareOccupant
{
   static int idStream;
   protected int moves;
   protected int id;
   
   public Piece(int inColour)
   {
      super();
      colour = inColour;
      moves = 0;
      idStream++;
      id = idStream;
   }
   
   static void restartStream()
   {
      idStream = 0;
   }
   
   public int getMoveCount()
   {
      return moves;
   }
   
   public int getId()
   {
      return id;
   }
   
   public void incrementMove()
   {
      moves++;
   }
   
   public void decrementMove()
   {
      moves--;
   }
}