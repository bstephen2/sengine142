package uk.me.bstephen.Chess;

import javax.swing.tree.*;

public class MoveNode extends DefaultMutableTreeNode
{
   public MoveNode(Object inObj)
   {
      super(inObj);
   }
   
   public void pack()
   {
      if (children != null)
      {
	 children.trimToSize();
      }
   }
}
