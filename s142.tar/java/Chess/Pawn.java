package uk.me.bstephen.Chess;

/**
 * This class represents a pawn.
 *
 * @author Brian Stephenson
 * @version 1.0
 */

public class Pawn extends Piece
{
   public Pawn(int inColour)
   {
      super(inColour);
      letter = (inColour == WHITE)? 'P': 'p';
   }
}