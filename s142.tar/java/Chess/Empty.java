package uk.me.bstephen.Chess;

/**
 * This class represents an empty square.
 */

public class Empty extends SquareOccupant
{
   public Empty()
   {
      super();
      letter = '.';
   }
}