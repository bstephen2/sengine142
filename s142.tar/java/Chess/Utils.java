package uk.me.bstephen.Chess;
import java.util.*;

/**
 *	Some basic chess utilities.
 *
 * @author Brian Stephenson (bstephen@freeuk.com)
 * @version 1.0
 */

public class Utils
{
   private static String files = "abcdefgh";
   private static String ranks = "87654321";
   
   public static String square(int inSquare)
   {
      StringBuffer ret;
      int f;
      int r;
      
      f = (inSquare % 12) - 2;
      r = (inSquare / 12) - 2;
      
      ret = new StringBuffer();
      ret = ret.append(files.charAt(f));
      ret = ret.append(ranks.charAt(r));
      
      return ret.toString();
   }
   
   public static int toInt(String inSquare)
   {
      int f;
      int r;
      
      f = files.indexOf(inSquare.charAt(0));
      r = ranks.indexOf(inSquare.charAt(1));
      
      return (((r + 2)*12) + f + 2);
   }
}