package uk.me.bstephen.Chess;

/**
 *	This class represents a single move.
 * @author Brian Stephenson (bstephen@freeuk.com)
 * @version 1.0
 */

public class Move
{
    private boolean inspected;
    private int from;
    private int to;
    private int id;
    private char piece;
    private String stFrom;
    private String stTo;
    private String stMove;
    private String stPiece;
    private char promotee;
    private boolean captures;
    private boolean check;
    private boolean mate;
    private boolean done;			// Indicates whether this move has been done.
    private int saveTo;
    private int saveFrom;
    private int forcedMateIn;
    private MoveList threat;
    private MoveList next;
    private boolean bKey;

    public int getId()
    {
        return id;
    }

    public void setId(int inId)
    {
        id = inId;
    }

    public Move()
    {
        super();
    }

    public Move(Piece inP, int inFrom, int inTo, char inPiece)
    {
        super();
        from = inFrom;
        to = inTo;
        promotee = ' ';
        piece = inPiece;
        captures = false;
        check = false;
        mate = false;
        stFrom = null;
        stTo = null;
        stMove = null;
        stPiece = null;
        saveTo = 0;
        saveFrom = 0;
        inspected = false;
        threat = null;
        next = null;
        forcedMateIn = 0;
        done = false;
        bKey = false;
        id = inP.getId();
    }

    public Move(Piece inP, int inFrom, int inTo, char inPiece, char inProm)
    {
        super();
        from = inFrom;
        to = inTo;
        promotee = inProm;
        piece = inPiece;
        captures = false;
        mate = false;
        stFrom = null;
        stTo = null;
        stMove = null;
        stPiece = null;
        check = false;
        saveTo = 0;
        saveFrom = 0;
        inspected = false;
        threat = null;
        next = null;
        forcedMateIn = 0;
        done = false;
        bKey = false;
        id = inP.getId();
    }

    public boolean isKey()
    {
        return bKey;
    }

    public void setKey(boolean inKey)
    {
        bKey = inKey;
    }

    public String toString()
    {
        return stMove;
    }

    public boolean sameMove(Move inMove)
    {
        if (this.piece != inMove.piece) return false;

        if (this.from != inMove.from) return false;

        if (this.to != inMove.to) return false;

        if (this.promotee != inMove.promotee) return false;

        return true;
    }

    public boolean treeEquals(Move inMove)
    {
        if (this.equals(inMove) == true) {
            return true;
        } else {
            return false;
        }
    }

    public boolean equals(Move inMove)
    {
        if (this.piece != inMove.piece) return false;

        if (this.from != inMove.from) return false;

        if (this.to != inMove.to) return false;

        if (this.promotee != inMove.promotee) return false;

        //if (this.captures != inMove.captures) return false;
        if (this.check != inMove.check) return false;

        if (this.mate != inMove.mate) return false;

        if (this.forcedMateIn != inMove.forcedMateIn) return false;

        return true;
    }

    public boolean mateEquals(Move inMove)
    {
        if (this.piece != inMove.piece) return false;

        if (this.from != inMove.from) {
            if (this.id != inMove.id) return false;
        }

        if (this.to != inMove.to) return false;

        if (this.promotee != inMove.promotee) return false;

        //if (this.captures != inMove.captures) return false;
        if (this.check != inMove.check) return false;

        if (this.mate != inMove.mate) return false;

        if (this.forcedMateIn != inMove.forcedMateIn) return false;

        return true;
    }

    public boolean Blackequals(Move inMove)
    {
        if (this.piece != inMove.piece) return false;

        if (this.from != inMove.from) return false;

        if (this.to != inMove.to) return false;

        if (this.promotee != inMove.promotee) return false;

        //if (this.check != inMove.check) return false;

        return true;
    }

    public void setDone(boolean inDone)
    {
        done = inDone;
    }

    public boolean isDone()
    {
        return done;
    }

    public void setForcedMateIn(int inMateLength)
    {
        forcedMateIn = inMateLength;
    }

    public int getForcedMateIn()
    {
        return forcedMateIn;
    }

    public void setThreat(MoveList ml)
    {
        threat = ml;
    }

    public void setNext(MoveList ml)
    {
        next = ml;
    }

    public MoveList getThreat()
    {
        return threat;
    }

    public MoveList getNext()
    {
        return next;
    }

    public void setInspected(boolean flag)
    {
        inspected = flag;
    }

    public boolean getInspected()
    {
        return inspected;
    }

    public void setMate(boolean inMate)
    {
        StringBuffer sb;
        int i;
        mate = inMate;

        sb = new StringBuffer(stMove);
        i = sb.length();
        sb.deleteCharAt(i - 1);
        sb.append('#');
        stMove = sb.toString();
    }

    public boolean getMate()
    {
        return mate;
    }

    public void setStrings()
    {
        stFrom = Utils.square(from);
        stTo = Utils.square(to);

        switch (piece) {
        case 'P':
            stPiece = null;

            if (captures == true) {
                stFrom = stFrom.substring(0, 1);
            } else {
                stFrom = null;
            }

            break;

        case 'p':
            stPiece = null;

            if (captures == true) {
                stFrom = stFrom.substring(0, 1);
            } else {
                stFrom = null;
            }

            break;

        case 'Q':
            stPiece = new String("Q");
            break;

        case 'q':
            stPiece = new String("Q");
            break;

        case 'R':
            stPiece = new String("R");
            break;

        case 'r':
            stPiece = new String("R");
            break;

        case 'B':
            stPiece = new String("B");
            break;

        case 'b':
            stPiece = new String("B");
            break;

        case 'S':
            stPiece = new String("S");
            break;

        case 's':
            stPiece = new String("S");
            break;

        case 'K':
            stPiece = new String("K");

            if (from == 114) {
                if (to == 116) {
                    stTo = new String("0-0");
                    stPiece = null;
                }

                if (to == 112) {
                    stTo = new String("0-0-0");
                    stPiece = null;
                }
            }

            stFrom = null;
            break;

        case 'k':
            stPiece = new String("K");

            if (from == 30) {
                if (to == 32) {
                    stTo = new String("0-0");
                    stPiece = null;
                }

                if (to == 28) {
                    stTo = new String("0-0-0");
                    stPiece = null;
                }
            }

            stFrom = null;
            break;

        default:
            System.out.println("Internal error!");
            return;
        }
    }

    public void shorten()
    {
        stFrom = null;
    }

    public void readyForPrinting()
    {
        StringBuffer b;

        b = new StringBuffer();

        if (stPiece != null) {
            b.append(stPiece);
        }

        if (stFrom != null) {
            b.append(stFrom);
        }

        if (captures == true) {
            b.append('x');
        }

        b.append(stTo);

        switch (promotee) {
        case 'Q':
            b.append("=Q");
            break;

        case 'q':
            b.append("=Q");
            break;

        case 'R':
            b.append("=R");
            break;

        case 'r':
            b.append("=R");
            break;

        case 'B':
            b.append("=B");
            break;

        case 'b':
            b.append("=B");
            break;

        case 'S':
            b.append("=S");
            break;

        case 's':
            b.append("=S");
            break;

        case ' ':
            break;

        default:
            System.out.println("Internal error!");
            return;
        }

        if (mate == true) {
            b.append('#');
        } else if (check == true) {
            b.append('+');
        }

        stMove = b.toString();
    }

    public String getStMove()
    {
        return stMove;
    }

    public int getTo()
    {
        return to;
    }

    public int getFrom()
    {
        return from;
    }

    public void setSaveTo(int inTo)
    {
        saveTo = inTo;
    }

    public void setSaveFrom(int inFrom)
    {
        saveFrom = inFrom;
    }

    public int getSaveTo()
    {
        return saveTo;
    }

    public int getSaveFrom()
    {
        return saveFrom;
    }

    public void setCheck(boolean inFlag)
    {
        check = inFlag;
    }

    public boolean getCheck()
    {
        return check;
    }

    public void setCaptures(boolean inFlag)
    {
        captures = inFlag;
    }

    public boolean getCaptures()
    {
        return captures;
    }

    /**
     *
     */

    public char getPiece()
    {
        return piece;
    }

    public void setPromotee(char inProm)
    {
        promotee = inProm;
    }

    public char getPromotee()
    {
        return promotee;
    }

    public void setStFrom(String inFrom)
    {
        stFrom = inFrom;
    }

    public String getStFrom()
    {
        return stFrom;
    }

    public String getStTo()
    {
        return stTo;
    }

    public void fromTo()
    {
        System.out.println(Utils.square(from) + "-" + Utils.square(to));
    }
}
