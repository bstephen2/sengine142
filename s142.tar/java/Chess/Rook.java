package uk.me.bstephen.Chess;

/**
 * This class represents a rook.
 *
 * @author Brian Stephenson
 * @version 1.0
 */

public class Rook extends Rider
{
   /**
    *
    */
   
   static int[] moves = { -1, -12, 1, 12};
   
   /**
    *
    */
   
   public Rook(int inColour)
   {
      super(inColour);
      letter = (inColour == WHITE)? 'R': 'r';
   }
   
   /**
    *
    */
   
   public static int[] getMoves()
   {
      return moves;
   }
   
   public int[] getDisplacements()
   {
      return moves;
   }
}