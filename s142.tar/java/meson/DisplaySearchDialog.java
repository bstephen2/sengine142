package uk.me.bstephen.Meson;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import java.sql.*;
import java.util.*;

public class DisplaySearchDialog extends TaskDialog {
    private static String sql = "SELECT COUNT(*) as total FROM problem WHERE stip = '#2'";
    private ArrayList data;
    private StaticFeatureList sfl;

    public DisplaySearchDialog(Meson inParent, ArrayList inData, StaticFeatureList inList) {
        super(inParent, "Searching features ...");
        data = inData;
        sfl = inList;
        this.process();
    }

    public int getTarget() {
        Connection conn;
        PreparedStatement pstmt;
        ResultSet rs;
        int temp = 0;

        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/meson", "bstephen", "rice37");
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            rs.next();
            temp = rs.getInt("total");

            rs.close();
            pstmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }

        return temp;
    }

    public void runBackgroundProcess() {
        task = new SearchTask(data, sfl);
        task.start();
        timer.start();
    }

    public void tidyUp() {
        myParent.displayFeaturedProblems();
    }
}
