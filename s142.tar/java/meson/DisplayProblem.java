package uk.me.bstephen.Meson;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import javax.swing.table.*;
import javax.swing.tree.*;
import java.sql.*;
import java.io.*;
import java.util.zip.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import org.w3c.dom.*;
import uk.me.bstephen.Chess.*;

public class DisplayProblem extends JDialog {
    private static final String querySQL01 =	"SELECT a.pid, a.years, a.kings, a.gbr, a.position, a.stip, " +
            "a.date, a.version, a.eid, a.hide, a.ep, a.cast, a.sols, b.name, c.name " +
            "FROM problem as a, source as b, award as c " +
            "WHERE " +
            "( a.pid = ? ) " +
            "AND (a.sid = b.sid) " +
            "AND (a.aid = c.aid)";

    private static final String querySQL02 = 	"SELECT c.name " +
            "FROM composer as c, problemcomposer as a " +
            "WHERE " +
            "(a.pid = ?) " +
            "AND (a.cid = c.cid) " +
            "ORDER BY c.name";

    private static final String querySQL03 =	"SELECT a.sid, b.name, a.years " +
            "FROM problemsource as a, source as b " +
            "WHERE " +
            "(a.pid = ? ) " +
            "AND (a.sid = b.sid) " +
            "ORDER BY a.years, b.name";

    private static final String querySQL04 =  "SELECT UNCOMPRESS(sol), UNCOMPRESS(class) " +
            "FROM classol " +
            "WHERE (pid = ? )";

    private static final String updateSQL01 =	"UPDATE classol " +
            "SET class = COMPRESS(?), sol = COMPRESS(?) " +
            "WHERE pid = ?";

    private static final String insertSQL01 = "INSERT INTO classol " +
            "(pid, sol, class) " +
            "VALUES (COMPRESS(?), COMPRESS(?), COMPRESS(?))";

    private Point p;
    private Integer pid;
    private Container cPane;
    private DefaultListModel compListModel;
    private Font boldArial14;
    private ProblemSourceModel sourceListModel;
    private GridBagConstraints gbc;

    private String years;
    private String position;
    private String stip;
    private String pubDate;
    private String version;
    private int origID;
    private InputStream classStream;
    private InputStream solStream;
    private DefaultTreeModel classModel;
    private DefaultTreeModel solModel;
    private String source;
    private String award;
    private String kings;
    private String gbr;
    private String hide;
    private String ep;
    private String cast;
    private final Meson mesonParent;
    private JButton matchesButton;

    private boolean match;
    private String sols;

    public DisplayProblem(Meson inParent, Integer inPid, boolean in_match) {
        super(inParent, "Display Problem", true);
        mesonParent = inParent;
        match = in_match;
        p = inParent.getLocationOnScreen();

        this.setBounds(p.x + 20, p.y + 60, 1000, 630);
        Container cPane = this.getContentPane();
        cPane.setLayout(new GridBagLayout());
        this.setResizable(false);

        pid = inPid;

        boldArial14 = new Font("Arial", Font.BOLD, 14);

        this.GetProblemData();
        gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.NONE;
        gbc.weightx = 0;
        gbc.weighty = 0;
        gbc.ipadx = 0;
        gbc.ipady = 0;
        gbc.insets = new Insets(4, 4, 4, 4);


        DO_SECTION_1: {
            this.DisplayComposers(cPane);
            this.DisplayClassification(cPane);
        }

        DO_SECTION_2: {
            JPanel lhBox = new JPanel();
            lhBox.setLayout(new GridBagLayout());
            GridBagConstraints gb = new GridBagConstraints();
            gb.fill = GridBagConstraints.NONE;
            gb.weightx = 0;
            gb.weighty = 0;
            gb.ipadx = 0;
            gb.ipady = 0;
            gb.insets = new Insets(2, 2, 2, 2);

            this.DisplayCaption(lhBox, gb);
            this.DisplayDiagram(lhBox, gb);
            this.DisplayStipulation(lhBox, gb);

            gbc.gridx = 0;
            gbc.gridy = 1;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;
            gbc.anchor = GridBagConstraints.FIRST_LINE_START;

            cPane.add(lhBox, gbc);

            this.DisplayVersioning(cPane);

            this.DisplaySolution(cPane);
        }

        DO_SECTION_3: {
            this.DisplaySources(cPane);
            this.DisplayButtons(cPane);
        }

        this.pack();
        this.setVisible(true);
    }

    private void GetProblemData() {
        Connection conn;
        ResultSet probRs;
        ResultSet sourceRs;

        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/meson", "bstephen", "rice37");

            PROBLEM: {
                PreparedStatement pstmt;
                ResultSet rs;

                pstmt = conn.prepareStatement(querySQL01);
                pstmt.setString(1, pid.toString());
                rs = pstmt.executeQuery();

                if (rs.next() == true) {
                    stip = rs.getString("a.stip");
                    award = rs.getString("c.name");
                    source = rs.getString("b.name");
                    years = rs.getString("a.years");
                    pubDate = rs.getString("a.date");
                    position = rs.getString("a.position");
                    gbr = rs.getString("a.gbr");
                    kings = rs.getString("a.kings");
                    version = rs.getString("a.version");
                    origID = rs.getInt("a.eid");
                    hide = rs.getString("a.hide");
                    ep = rs.getString("a.ep");
                    cast = rs.getString("a.cast");
                    sols = rs.getString("a.sols");
                } else {
                    System.exit(1);
                }

                rs.close();
                pstmt.close();
            }

            SOLUTION_AND_CLASSIFICATION: {
                PreparedStatement pstmt;
                ResultSet rs;

                if ((stip.compareTo("#2") == 0) || (stip.compareTo("#3") == 0))
                {
                    pstmt = conn.prepareStatement(querySQL04);
                    pstmt.setString(1, pid.toString());
                    rs = pstmt.executeQuery();

                    if (rs.next() == true) {
                        classStream = rs.getBinaryStream("UNCOMPRESS(class)");
                        solStream = rs.getBinaryStream("UNCOMPRESS(sol)");
                    } else {
                        classStream =  null;
                        solStream = null;
                    }

                    rs.close();
                    pstmt.close();

                }
                else
                {
                    classStream =  null;
                    solStream = null;
                }

            }

            COMPOSER: {
                PreparedStatement pstmt;
                ResultSet rs;

                compListModel = new DefaultListModel();
                pstmt = conn.prepareStatement(querySQL02);
                pstmt.setString(1, pid.toString());
                rs = pstmt.executeQuery();

                while (rs.next() == true) {
                    compListModel.addElement(rs.getString("c.name"));
                }

                rs.close();
                pstmt.close();
            }

            SOURCE: {
                PreparedStatement pstmt;
                ResultSet rs;
                int sid;
                String name;
                String years;

                sourceListModel = new ProblemSourceModel();
                pstmt = conn.prepareStatement(querySQL03);
                pstmt.setString(1, pid.toString());
                rs = pstmt.executeQuery();

                while (rs.next() == true) {
                    sid = rs.getInt("a.sid");
                    name = rs.getString("b.name");
                    years = rs.getString("a.years");
                    sourceListModel.addElement(sid, name, years);
                }

                rs.close();
                pstmt.close();
            }

            conn.close();
        } catch (SQLException ae) {
            ae.printStackTrace();
            System.exit(1);
        }
    }

    private void DisplayVersioning(Container parent) {
        Box versionBox = Box.createVerticalBox();
        JButton origButton = new JButton("Original");
        origButton.setFont(boldArial14);
        ButtonGroup radioGroup = new ButtonGroup();
        JRadioButton noneB = new JRadioButton("None");
        noneB.setFont(boldArial14);
        JRadioButton versionB = new JRadioButton("Version");
        versionB.setFont(boldArial14);
        JRadioButton afterB = new JRadioButton("After");
        afterB.setFont(boldArial14);

        if (version.compareTo("none") == 0) {
            noneB.setSelected(true);
            origButton.setEnabled(false);
        } else if (version.compareTo("version") == 0) {
            versionB.setSelected(true);
        } else if (version.compareTo("after") == 0) {
            afterB.setSelected(true);
        }

        radioGroup.add(noneB);
        radioGroup.add(versionB);
        radioGroup.add(afterB);

        versionBox.add(noneB);
        versionBox.add(versionB);
        versionBox.add(afterB);

        origButton.addActionListener
        (
        new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                JOptionPane.showMessageDialog(cPane,
                                              "This facility not yet written!",
                                              "Meson",
                                              JOptionPane.WARNING_MESSAGE);
            }
        }
        );

        versionBox.add(origButton);
        JCheckBox hideCB = new JCheckBox("Hide");

        if (hide.compareTo("1") == 0) {
            hideCB.setSelected(true);
        } else {
            hideCB.setSelected(false);
        }

        hideCB.setEnabled(true);
        hideCB.setFont(boldArial14);

        versionBox.add(hideCB);

        EP_CAST: {
            JPanel epCast = new JPanel(new GridBagLayout());
            GridBagConstraints epGBC = new GridBagConstraints();
            epGBC.fill = GridBagConstraints.NONE;
            epGBC.weightx = 0;
            epGBC.weighty = 0;
            epGBC.ipadx = 0;
            epGBC.ipady = 0;
            epGBC.insets = new Insets(1, 1, 1, 1);

            JLabel epLab = new JLabel("EP:", SwingConstants.RIGHT);
            epLab.setFont(boldArial14);
            epGBC.gridx = 0;
            epGBC.gridy = 0;
            epGBC.gridwidth = 1;
            epGBC.gridheight = 1;
            epGBC.anchor = GridBagConstraints.PAGE_END;

            epCast.add(epLab, epGBC);

            JTextField epText = new JTextField(2);
            epText.setText(ep);
            epText.setEditable(false);
            epText.setFont(boldArial14);

            epGBC.gridx = 1;
            epGBC.gridy = 0;
            epGBC.gridwidth = 1;
            epGBC.gridheight = 1;
            epGBC.anchor = GridBagConstraints.PAGE_START;
            epCast.add(epText, epGBC);

            JLabel castLab = new JLabel("Castling:", SwingConstants.RIGHT);
            castLab.setFont(boldArial14);
            epGBC.gridx = 0;
            epGBC.gridy = 1;
            epGBC.gridwidth = 1;
            epGBC.gridheight = 1;
            epGBC.anchor = GridBagConstraints.PAGE_END;

            epCast.add(castLab, epGBC);

            JTextField castText = new JTextField(4);
            castText.setText(cast);
            castText.setEditable(false);
            castText.setFont(boldArial14);

            epGBC.gridx = 1;
            epGBC.gridy = 1;
            epGBC.gridwidth = 1;
            epGBC.gridheight = 1;
            epGBC.anchor = GridBagConstraints.PAGE_START;
            epCast.add(castText, epGBC);

            JLabel solLab = new JLabel("Sols:", SwingConstants.RIGHT);
            solLab.setFont(boldArial14);
            epGBC.gridx = 0;
            epGBC.gridy = 2;
            epGBC.gridwidth = 1;
            epGBC.gridheight = 1;
            epGBC.anchor = GridBagConstraints.PAGE_END;

            epCast.add(solLab, epGBC);

            JTextField solText = new JTextField(4);
            solText.setText(sols);
            solText.setEditable(false);
            solText.setFont(boldArial14);

            epGBC.gridx = 1;
            epGBC.gridy = 2;
            epGBC.gridwidth = 1;
            epGBC.gridheight = 1;
            epGBC.anchor = GridBagConstraints.PAGE_START;
            epCast.add(solText, epGBC);

            versionBox.add(epCast);
        }

        PUBLICATION_DATE: {
            JTextField dateText = new JTextField(10);
            dateText.setText(pubDate);
            dateText.setEditable(false);
            dateText.setFont(boldArial14);
            versionBox.add(dateText);
        }

        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.anchor = GridBagConstraints.FIRST_LINE_START;

        parent.add(versionBox, gbc);
    }

    private void DisplayButtons(Container parent) {
        Box buttons = new Box(BoxLayout.Y_AXIS);

        JButton solveClassifyButton = new JButton("Solve/Classify");
        solveClassifyButton.setFont(boldArial14);

        if (match == true) {
            solveClassifyButton.setEnabled(false);
        }

        if ((stip.compareTo("#2") != 0) && (stip.compareTo("#3") != 0)) {
            solveClassifyButton.setEnabled(false);
        }

        solveClassifyButton.addActionListener
        (
        new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                Problem prb;
                Document solDoc;
                Document classDoc;
                ByteArrayOutputStream solBytes = null;
                ByteArrayOutputStream classBytes = null;
                int uc;

                try {
                    if (stip.compareTo("#2") == 0) {
                        prb = new TwoMover();
                    } else {
                        prb = new ThreeMover();
                    }

                    prb.setPosition(kings, gbr, position, ep, cast);
                    prb.setThreats(true);
                    prb.solve(true);
                    prb.classify(true);

                    solDoc = prb.enXMLSolution();
                    classDoc = prb.enXMLClassification();
                    MoveNode solRoot = solXML2Root(solDoc);
                    solModel.setRoot(solRoot);
                    MoveNode classRoot = classXML2Root(classDoc);
                    classModel.setRoot(classRoot);

                    solBytes = new ByteArrayOutputStream();
                    TransformerFactory tf = TransformerFactory.newInstance();
                    Transformer transformer = tf.newTransformer();
                    DOMSource source = new DOMSource(solDoc);
                    StreamResult result = new StreamResult(solBytes);
                    transformer.transform(source, result);
                    solBytes.close();

                    classBytes = new ByteArrayOutputStream();
                    tf = TransformerFactory.newInstance();
                    transformer = tf.newTransformer();
                    source = new DOMSource(classDoc);
                    result = new StreamResult(classBytes);
                    transformer.transform(source, result);
                    classBytes.close();

                    if (stip.compareTo("#2") == 0) {
                        matchesButton.setEnabled(true);
                    }

                    Connection conn;
                    conn = DriverManager.getConnection("jdbc:mysql://localhost/meson", "bstephen", "rice37");
                    PreparedStatement pstmt = conn.prepareStatement(updateSQL01);

                    pstmt.setBytes(1, classBytes.toByteArray());
                    pstmt.setBytes(2, solBytes.toByteArray());
                    pstmt.setString(3, pid.toString());
                    uc = pstmt.executeUpdate();

                    if (uc != 1) {
                        pstmt = conn.prepareStatement(insertSQL01);
                        pstmt.setString(1, pid.toString());
                        pstmt.setBytes(2, solBytes.toByteArray());
                        pstmt.setBytes(3, classBytes.toByteArray());
                        uc = pstmt.executeUpdate();
                    }

                    conn.close();

                    DISPLAY_SOLVE_TIME: {
                        long t = prb.getRunTime();
                        JOptionPane.showMessageDialog(cPane,
                                                      "Solving time = " + t + " milliseconds",
                                                      "Meson",
                                                      JOptionPane.INFORMATION_MESSAGE);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    System.exit(1);
                }
            }
        }
        );

        JButton enlargeButton = new JButton("Enlarge Solution");
        enlargeButton.setFont(boldArial14);

        enlargeButton.addActionListener
        (
        new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                EnlargeSolutionDialog esd = new EnlargeSolutionDialog(DisplayProblem.this, classModel, solModel);
            }
        }
        );

        JButton kaluluButton = new JButton("->Kalulu");
        kaluluButton.setFont(boldArial14);
        kaluluButton.addActionListener
        (
        new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                Connection conn;

                try {
                    conn = DriverManager.getConnection("jdbc:mysql://localhost/meson", "bstephen", "rice37");
                    KaluluOut ko = new KaluluOut(conn, pid);
                    ko.produceKaluluFile(1);
                    conn.close();
                } catch (Exception e) {
                    e.printStackTrace();
                    System.exit(1);
                }
            }
        }
        );

        matchesButton = new JButton("Match");
        matchesButton.setFont(boldArial14);

        if (match == true) {
            matchesButton.setEnabled(false);
        }

        if (classStream == null) {
            matchesButton.setEnabled(false);
        }

        matchesButton.addActionListener
        (
        new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                if (stip.trim().compareTo("#2") == 0) {
                    DisplayProblem.this.setVisible(false);
                    mesonParent.matchSelectedProblem();
                    DisplayProblem.this.dispose();
                }
            }
        }
        );

        JButton editButton = new JButton("Edit");
        editButton.setFont(boldArial14);

        if (match == true) {
            editButton.setEnabled(false);
        }

        editButton.addActionListener
        (
        new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                JOptionPane.showMessageDialog(cPane,
                                              "This facility not yet written!",
                                              "Meson",
                                              JOptionPane.WARNING_MESSAGE);
            }
        }
        );

        JButton closeButton = new JButton("Close");
        closeButton.setFont(boldArial14);
        closeButton.addActionListener
        (
        new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                DisplayProblem.this.setVisible(false);
                DisplayProblem.this.dispose();
            }
        }
        );

        buttons.add(solveClassifyButton);
        buttons.add(enlargeButton);
        buttons.add(kaluluButton);
        buttons.add(matchesButton);
        buttons.add(editButton);
        buttons.add(closeButton);

        gbc.gridx = 3;
        gbc.gridy = 2;
        gbc.gridheight = 1;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.LAST_LINE_END;

        parent.add(buttons, gbc);
    }

    private void DisplaySolution(Container parent) {
        MoveNode root;
        Document doc;

        try {
            if (solStream == null) {
                root = new MoveNode("Unsolved!");
                solModel = new DefaultTreeModel(root);
            } else {
                DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                DocumentBuilder builder = factory.newDocumentBuilder();
                doc = builder.parse(solStream);
                MoveNode solRoot = solXML2Root(doc);
                solModel = new DefaultTreeModel(solRoot);
            }

            JTree tree = new JTree(solModel);
            JScrollPane ls = new JScrollPane(tree);
            ls.setPreferredSize(new Dimension(350, 250));

            gbc.gridx = 2;
            gbc.gridy = 1;
            gbc.gridwidth = 2;
            gbc.gridheight = 1;
            gbc.anchor = GridBagConstraints.FIRST_LINE_END;

            parent.add(ls, gbc);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    private void DisplayClassification(Container parent) {
        TreeNode root;
        Document doc;

        try {
            if (classStream == null) {
                root = new MoveNode("Unclassified!");
                classModel = new DefaultTreeModel(root);
            } else {
                DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                DocumentBuilder builder = factory.newDocumentBuilder();
                doc = builder.parse(classStream);
                MoveNode classRoot = classXML2Root(doc);
                classModel = new DefaultTreeModel(classRoot);
            }

            JTree tree = new JTree(classModel);
            JScrollPane ls = new JScrollPane(tree);
            ls.setPreferredSize(new Dimension(350, 150));

            gbc.gridx = 2;
            gbc.gridy = 0;
            gbc.gridwidth = 2;
            gbc.gridheight = 1;
            gbc.anchor = GridBagConstraints.FIRST_LINE_END;

            parent.add(ls, gbc);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    private void DisplaySources(Container parent) {
        JTable sourceList = new JTable(sourceListModel);
        //sourceList.setPreferredScrollableViewportSize(new Dimension(540, 100));
        sourceList.setFont(boldArial14);
        JScrollPane ls = new JScrollPane(sourceList);
        ls.setPreferredSize(new Dimension(600, 100));

        TableColumn years = sourceList.getColumn("Years");
        TableColumn sid = sourceList.getColumn("SID");
        TableColumn name = sourceList.getColumn("Name");

        years.setPreferredWidth(80);
        sid.setPreferredWidth(60);
        name.setPreferredWidth(460);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.gridheight = 1;
        gbc.anchor = GridBagConstraints.LAST_LINE_START;

        parent.add(ls, gbc);
    }

    private void DisplayStipulation(Container parent, GridBagConstraints gb) {
        JTextField jText = new JTextField(stip.trim(), 10);
        jText.setFont(boldArial14);
        jText.setEditable(false);

        gb.gridx = 0;
        gb.gridy = 10;
        gb.gridwidth = 1;
        gb.gridheight = 1;
        gb.anchor = GridBagConstraints.FIRST_LINE_START;
        parent.add(jText, gb);
    }

    private void DisplayDiagram(Container parent, GridBagConstraints gb) {
        String posConst = "wdwdwdwddwdwdwdw";
        String pos = new String(posConst + posConst + posConst + posConst);
        StringBuffer sb;

        char[] par = new char[64];
        int i;
        int j;
        int l;
        int c;

        for (i = 0; i < 64; i++) {
            par[i] = pos.charAt(i);
        }

        //	wK

        j = MesonFunc.getElement(kings.substring(0, 2));
        par[j] = (par[j] == 'w') ? 'K' : 'I';

        //	bK

        j = MesonFunc.getElement(kings.substring(2));
        par[j] = (par[j] == 'w') ? 'k' : 'i';

        //	wQs

        l = 0;
        c = Integer.parseInt(gbr.substring(0, 1));

        while ((c % 3) != 0) {
            j = MesonFunc.getElement(position.substring(l, l + 2));
            par[j] = (par[j] == 'w') ? 'Q' : '!';
            c--;
            l += 2;
        }

        //	bQs

        while (c >= 3) {
            j = MesonFunc.getElement(position.substring(l, l + 2));
            par[j] = (par[j] == 'w') ? 'q' : '1';
            c -= 3;
            l += 2;
        }

        //	wRs

        c = Integer.parseInt(gbr.substring(1, 2));

        while ((c % 3) != 0) {
            j = MesonFunc.getElement(position.substring(l, l + 2));
            par[j] = (par[j] == 'w') ? 'R' : '$';
            c--;
            l += 2;
        }

        //	bRs

        while (c >= 3) {
            j = MesonFunc.getElement(position.substring(l, l + 2));
            par[j] = (par[j] == 'w') ? 'r' : '4';
            c -= 3;
            l += 2;
        }

        //	wBs

        c = Integer.parseInt(gbr.substring(2, 3));

        while ((c % 3) != 0) {
            j = MesonFunc.getElement(position.substring(l, l + 2));
            par[j] = (par[j] == 'w') ? 'B' : 'G';
            c--;
            l += 2;
        }

        //	bBs

        while (c >= 3) {
            j = MesonFunc.getElement(position.substring(l, l + 2));
            par[j] = (par[j] == 'w') ? 'b' : 'g';
            c -= 3;
            l += 2;
        }

        //	wSs

        c = Integer.parseInt(gbr.substring(3, 4));

        while ((c % 3) != 0) {
            j = MesonFunc.getElement(position.substring(l, l + 2));
            par[j] = (par[j] == 'w') ? 'N' : 'H';
            c--;
            l += 2;
        }

        //	bSs

        while (c >= 3) {
            j = MesonFunc.getElement(position.substring(l, l + 2));
            par[j] = (par[j] == 'w') ? 'n' : 'h';
            c -= 3;
            l += 2;
        }

        //	wPs

        c = Integer.parseInt(gbr.substring(5, 6));

        while (c > 0) {
            j = MesonFunc.getElement(position.substring(l, l + 2));
            par[j] = (par[j] == 'w') ? 'P' : ')';
            c--;
            l += 2;
        }

        //	bPs

        c = Integer.parseInt(gbr.substring(6, 7));

        while (c > 0) {
            j = MesonFunc.getElement(position.substring(l, l + 2));
            par[j] = (par[j] == 'w') ? 'p' : '0';
            c--;
            l += 2;
        }

        sb = new StringBuffer();

        for (i = 0; i < 64; i++) {
            sb.append(par[i]);

            if ((i != 0) && (i != 63) && ((i % 8) == 7)) {
                sb.append("\n");
            }
        }

        JTextArea diagram = new JTextArea(8, 8);
        diagram.setFont(new Font("LinaresDiagram", Font.PLAIN, 28));
        diagram.setText(sb.toString());
        diagram.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));

        gb.gridx = 0;
        gb.gridy = 2;
        gb.gridwidth = 1;
        gb.gridheight = 8;
        gb.anchor = GridBagConstraints.FIRST_LINE_START;
        parent.add(diagram, gb);
    }

    private void DisplayCaption(Container parent, GridBagConstraints gb) {
        JTextArea jSource = new JTextArea(2, 30);
        jSource.setFont(boldArial14);

        if (award.trim().compareTo("None") == 0) {
            jSource.setText(new String(source.trim() + ", " + years));
        } else {
            jSource.setText(new String(award.trim() + ", " + source.trim() + ", " + years));
        }

        jSource.setLineWrap(true);
        jSource.setWrapStyleWord(true);
        jSource.setEditable(false);

        gb.gridx = 0;
        gb.gridy = 0;
        gb.gridwidth = 1;
        gb.gridheight = 2;
        gb.anchor = GridBagConstraints.FIRST_LINE_START;
        parent.add(jSource, gb);
    }

    private void DisplayComposers(Container parent) {
        JList compList = new JList(compListModel);
        compList.setFont(boldArial14);
        JScrollPane ls = new JScrollPane(compList);
        ls.setPreferredSize(new Dimension(300, 150));

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.anchor = GridBagConstraints.FIRST_LINE_START;

        parent.add(ls, gbc);
    }

    private MoveNode solXML2Root(Document doc) {
        NamedNodeMap nnm;
        MoveNode root;

        Element rt = doc.getDocumentElement();
        nnm = rt.getAttributes();

        if (nnm.getLength() == 0) {
            root = new MoveNode(rt.getTagName());
        } else {
            root = new MoveNode(rt.getAttribute("text"));
        }

        this.doElement(rt, root);

        return root;
    }

    private MoveNode classXML2Root(Document doc) {
        Element rt = doc.getDocumentElement();
        MoveNode root = new MoveNode(rt.getAttribute("text"));
        this.doElement(rt, root);

        return root;

    }

    private void doElement(Element el, MoveNode mn) {
        int i;
        int l;
        NamedNodeMap nnm;
        MoveNode nn;

        NodeList nl = el.getChildNodes();

        l = nl.getLength();

        for (i = 0; i < l; i++) {
            Element nel = (Element) nl.item(i);
            nnm = nel.getAttributes();

            if (nnm.getLength() == 0) {
                nn = new MoveNode(nel.getTagName());
            } else {
                nn = new MoveNode(nel.getAttribute("text"));
            }

            mn.add(nn);
            this.doElement(nel, nn);
        }
    }
}