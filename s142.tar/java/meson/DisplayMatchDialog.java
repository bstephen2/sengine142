package uk.me.bstephen.Meson;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import java.sql.*;

public class DisplayMatchDialog extends TaskDialog {
    private static String sql = "SELECT COUNT(*) as total FROM problem WHERE stip = '#2'";
    private Integer selectedProblem;
    private boolean set;
    private boolean tries;

    public DisplayMatchDialog(Meson inParent, Integer inSelProb, boolean inSet, boolean inTries) {
        super(inParent, "Matching ...");
        selectedProblem = inSelProb;
        set = inSet;
        tries = inTries;
        this.process();
    }

    public int getTarget() {
        Connection conn;
        PreparedStatement pstmt;
        ResultSet rs;
        int temp = 0;

        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/meson", "bstephen", "rice37");
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            rs.next();
            temp = rs.getInt("total");

            rs.close();
            pstmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }

        return temp;
    }

    public void runBackgroundProcess() {
        task = new MatchTask(selectedProblem, set, tries);
        task.start();
        timer.start();
    }

    public void tidyUp() {
        myParent.displayMatches();
    }
}
