package uk.me.bstephen.Meson;

public class CountStipulationsQueryProcess extends QueryProcess {
    private String sql = "SELECT stip, COUNT(*) AS num_stip FROM problem GROUP BY stip ORDER BY stip";

    public CountStipulationsQueryProcess(Meson inParent) {
        super(inParent);
    }

    public void getInfo() {
    }

    public void getSQL() {
        try {
            pstmt = conn.prepareStatement(sql);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    public void showResult() {
        CountStipulationsQueryResult csqr = new CountStipulationsQueryResult(parent,
                rs,
                "Count by stipulation - results");
    }
}