package uk.me.bstephen.Meson;

public class OriginalLeagueQueryProcess extends QueryProcess {
    private String sql =	"SELECT b.name, a.sid, COUNT(*) AS num_origs " +
                            "FROM problem as a, source as b " +
                            "WHERE (a.sid = b.sid) " +
                            "GROUP BY a.sid " +
                            "ORDER BY num_origs DESC, b.name";

    public OriginalLeagueQueryProcess(Meson inParent) {
        super(inParent);
    }

    public void getInfo() {
    }

    public void getSQL() {
        try {
            pstmt = conn.prepareStatement(sql);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    public void showResult() {
        OriginalLeagueQueryResult olqr = new OriginalLeagueQueryResult(parent, rs, "Original League Query - results");
    }
}