package uk.me.bstephen.Meson;

import java.sql.*;
import java.io.*;
import java.util.*;
import java.text.*;

public class KaluluOut {
    private static final String querySQL01 =	"SELECT a.pid, a.years, a.kings, a.gbr, a.position, a.stip, " +
            "b.name, c.name " +
            "FROM problem as a, source as b, award as c " +
            "WHERE " +
            "( a.pid = ? ) " +
            "AND (a.sid = b.sid) " +
            "AND (a.aid = c.aid)";

    private static final String querySQL02 = 	"SELECT c.name " +
            "FROM composer as c, problemcomposer as a " +
            "WHERE " +
            "(a.pid = ?) " +
            "AND (a.cid = c.cid) " +
            "ORDER BY c.name";

    private static String kaldir = "c:\\Kalulu_0.1.6";
    private static String options = ",SP,AP,TP1,VT,ID";

    private Integer pid;
    private StringBuffer fy;
    private String stip;
    private String source;
    private String years;
    private String award;
    private String position;
    private String gbr;
    private String kings;
    private ArrayList composersAL;
    private Connection conn;

    public KaluluOut(Connection inConn, Integer inPid) {
        pid = inPid;
        conn = inConn;
        this.acquireProblemData();
    }

    public void acquireProblemData() {
        try {
            PROBLEM: {
                PreparedStatement pstmt;
                ResultSet rs;

                pstmt = conn.prepareStatement(querySQL01);
                pstmt.setString(1, pid.toString());
                rs = pstmt.executeQuery();

                if (rs.next() == true) {
                    stip = rs.getString("a.stip");
                    award = rs.getString("c.name");
                    source = rs.getString("b.name");
                    years = rs.getString("a.years");
                    position = rs.getString("a.position");
                    gbr = rs.getString("a.gbr");
                    kings = rs.getString("a.kings");
                } else {
                    System.exit(1);
                }

                rs.close();
                pstmt.close();
            }

            COMPOSERS: {
                PreparedStatement pstmt;
                ResultSet rs;

                composersAL = new ArrayList();
                pstmt = conn.prepareStatement(querySQL02);
                pstmt.setString(1, pid.toString());
                rs = pstmt.executeQuery();

                while (rs.next() == true) {
                    composersAL.add(rs.getString("c.name"));
                }

                rs.close();
                pstmt.close();
            }
        } catch (SQLException ae) {
            ae.printStackTrace();
            System.exit(1);
        }
    }

    public void produceKaluluFile(int ser) {
        StringBuffer sr;
        StringBuffer comps;
        NumberFormat nf;

        nf = NumberFormat.getIntegerInstance();
        nf.setMinimumIntegerDigits(7);
        nf.setGroupingUsed(false);

        File prb = new File(new String(kaldir + "\\m" + nf.format(ser) + ".prb"));

        char[] par = new char[64];
        int i;
        int j;
        int l;
        int c;
        int len;

        for (i = 0; i < 64; i++) {
            par[i] = '0';
        }

        //	wK

        j = MesonFunc.getElement(kings.substring(0, 2));
        par[j] = 'K';

        //	bK

        j = MesonFunc.getElement(kings.substring(2));
        par[j] = 'k';

        //	wQs

        l = 0;
        c = Integer.parseInt(gbr.substring(0, 1));

        while ((c % 3) != 0) {
            j = MesonFunc.getElement(position.substring(l, l + 2));
            par[j] = 'Q';
            c--;
            l += 2;
        }

        //	bQs

        while (c >= 3) {
            j = MesonFunc.getElement(position.substring(l, l + 2));
            par[j] = 'q';
            c -= 3;
            l += 2;
        }

        //	wRs

        c = Integer.parseInt(gbr.substring(1, 2));

        while ((c % 3) != 0) {
            j = MesonFunc.getElement(position.substring(l, l + 2));
            par[j] = 'R';
            c--;
            l += 2;
        }

        //	bRs

        while (c >= 3) {
            j = MesonFunc.getElement(position.substring(l, l + 2));
            par[j] = 'r';
            c -= 3;
            l += 2;
        }

        //	wBs

        c = Integer.parseInt(gbr.substring(2, 3));

        while ((c % 3) != 0) {
            j = MesonFunc.getElement(position.substring(l, l + 2));
            par[j] = 'B';
            c--;
            l += 2;
        }

        //	bBs

        while (c >= 3) {
            j = MesonFunc.getElement(position.substring(l, l + 2));
            par[j] = 'b';
            c -= 3;
            l += 2;
        }

        //	wSs

        c = Integer.parseInt(gbr.substring(3, 4));

        while ((c % 3) != 0) {
            j = MesonFunc.getElement(position.substring(l, l + 2));
            par[j] = 'S';
            c--;
            l += 2;
        }

        //	bSs

        while (c >= 3) {
            j = MesonFunc.getElement(position.substring(l, l + 2));
            par[j] = 's';
            c -= 3;
            l += 2;
        }

        //	wPs

        c = Integer.parseInt(gbr.substring(5, 6));

        while (c > 0) {
            j = MesonFunc.getElement(position.substring(l, l + 2));
            par[j] = 'P';
            c--;
            l += 2;
        }

        //	bPs

        c = Integer.parseInt(gbr.substring(6, 7));

        while (c > 0) {
            j = MesonFunc.getElement(position.substring(l, l + 2));
            par[j] = 'p';
            c--;
            l += 2;
        }

        fy = new StringBuffer();

        for (i = 0; i <= 56; i += 8) {
            j = i;

            while ((j <= (i + 7)) && (par[j] != '0')) {
                fy.append(par[j]);
                j++;
            }

            while (j <= (i + 7)) {
                c = 0;

                while ((j <= (i + 7)) && (par[j] == '0')) {
                    c++;
                    j++;
                }

                if (c != 0) {
                    fy.append(c);
                }

                while ((j <= (i + 7)) && (par[j] != '0')) {
                    fy.append(par[j]);
                    j++;
                }
            }

            if (i != 56) {
                fy.append('/');
            }
        }

        comps = new StringBuffer();
        len = composersAL.size();

        if (len > 0) {
            i = 0;

            while (i < (len - 1)) {
                comps.append((String) composersAL.get(i));
                comps.append(" & ");
                i++;
            }

            comps.append((String) composersAL.get(i));
        }

        sr = new StringBuffer();

        if (award.compareTo("None") != 0) {
            sr.append(new String(award + " , "));
        }

        sr.append(source);
        sr.append(", ");
        sr.append(years);

        try {
            PrintWriter out = new PrintWriter(new FileWriter(prb));
            out.println(fy.toString());
            out.println(new String(stip + options));
            out.println(new String("Meson " + pid.toString()));
            out.println(comps.toString());
            out.println(sr.toString());
            out.println("");
            out.println("");
            out.close();
        } catch (IOException ioe) {
            ioe.printStackTrace();
            System.exit(1);
        }
    }
}