package uk.me.bstephen.Meson;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import java.sql.*;

public class KaluluExportDialog extends TaskDialog {
    private ProblemTableModel myPTM;

    public KaluluExportDialog(Meson inParent, ProblemTableModel inPTM) {
        super(inParent, "Exporting to Kalulu files ...");
        myPTM = inPTM;
        this.process();
    }

    public int getTarget() {
        return myPTM.getRowCount();
    }

    public void runBackgroundProcess() {
        task = new KaluluExportTask(myPTM);
        task.start();
        timer.start();
    }

    public void tidyUp() {
    }
}
