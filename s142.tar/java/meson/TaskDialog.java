package uk.me.bstephen.Meson;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import java.sql.*;

public abstract class TaskDialog extends JDialog {
    public static final int ONE_SECOND = 1000;
    protected javax.swing.Timer timer;
    protected int target;
    protected Meson myParent;
    protected JProgressBar jpb;
    protected LongTask task;
    protected String myTitle;

    public TaskDialog(Meson inParent, String inTitle) {
        super(inParent, inTitle, false);
        myTitle = inTitle;
        myParent = inParent;
    }

    protected void process() {
        target = this.getTarget();
        this.paintScreen();
        this.runBackgroundProcess();
    }

    protected void paintScreen() {
        Point p = myParent.getLocationOnScreen();
        Font boldArial14 = new Font("Arial", Font.BOLD, 14);

        this.setBounds(p.x + 20, p.y + 60, 200, 400);
        Container cPane = this.getContentPane();
        cPane.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        this.setResizable(false);

        LABEL: {
            JLabel mLab = new JLabel(myTitle);
            mLab.setFont(boldArial14);
            cPane.add(mLab);
        }

        PROGRESS_BAR: {
            jpb = new JProgressBar(0, target);
            jpb.setFont(boldArial14);
            jpb.setStringPainted(true);

            cPane.add(jpb);
        }

        TIMER: {
            timer = new javax.swing.Timer(ONE_SECOND, new ActionListener() {
                public void actionPerformed(ActionEvent evt) {
                    jpb.setValue(task.getCount());

                    if (task.isFinished() == true) {
                        Toolkit.getDefaultToolkit().beep();
                        timer.stop();

                        try {
                            task.join();
                        } catch (Exception e) {
                            e.printStackTrace();
                            System.exit(1);
                        }

                        TaskDialog.this.dePaintScreen();
                        TaskDialog.this.tidyUp();
                    }
                }
            });
        }

        this.pack();
        this.setVisible(true);
    }

    protected void dePaintScreen() {
        this.setVisible(false);
        this.dispose();
    }

    public abstract int getTarget();

    public abstract void runBackgroundProcess();

    public abstract void tidyUp();
}
