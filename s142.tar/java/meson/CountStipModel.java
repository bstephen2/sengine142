package uk.me.bstephen.Meson;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
import java.sql.*;
import java.util.*;
import java.text.*;

public class CountStipModel extends AbstractTableModel {
    private ArrayList data;
    private ResultSet rs;

    private Class[] columnClasses = new Class[] { String.class, String.class };
    private String[] columnNames = new String[] { "stip", "num_stip" };

    public CountStipModel(ResultSet inRs) {
        super();
        rs = inRs;
    }

    public Object getValueAt(int row, int col) {
        StipRow s = (StipRow) data.get(row);

        switch (col) {
        case 0	:
            return s.getStip();

        case 1	:
            return s.getNumStip();

        default	:
            return null;
        }
    }

    public int getColumnCount() {
        return 2;
    }

    public int getRowCount() {
        return data.size();
    }

    public String getColumnName(int col) {
        return columnNames[col];
    }

    public Class getColumnClass(int col) {
        return columnClasses[col];
    }

    public void loadTableData() {
        StipRow sr;

        data = new ArrayList();

        try {
            while (rs.next()) {
                sr = new StipRow(rs.getString("stip"), rs.getInt("num_stip"));
                data.add(sr);
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
}

class StipRow {
    String stip;
    String num_stip;

    public StipRow(String in_stip, int in_total) {
        StringBuffer sb;
        char ch;
        int i;
        boolean leading;

        stip = new String(in_stip);

        NumberFormat nf = NumberFormat.getIntegerInstance();
        nf.setMinimumIntegerDigits(7);
        nf.setGroupingUsed(true);

        sb = new StringBuffer(nf.format(in_total));
        i = 0;
        ch = sb.charAt(i);
        leading = true;

        while (leading == true) {
            switch (ch) {
            case '0':
            case ',':
                sb.setCharAt(i, ' ');
                break;

            default :
                leading = false;
            }

            i++;

            if (i >= sb.length()) {
                leading = false;
            } else {
                ch = sb.charAt(i);
            }
        }

        num_stip = sb.toString();
    }

    public String getNumStip() {
        return num_stip;
    }

    public String getStip() {
        return stip;
    }
}