package uk.me.bstephen.Meson;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import javax.swing.table.*;
import javax.swing.tree.*;
import java.sql.*;
import java.io.*;
import java.util.zip.*;
import uk.me.bstephen.Chess.*;

public class EnlargeSolutionDialog extends JDialog {
    private DisplayProblem myParent;
    private DefaultTreeModel classModel;
    private DefaultTreeModel solModel;

    public EnlargeSolutionDialog(DisplayProblem inParent, DefaultTreeModel inClass, DefaultTreeModel inSol) {
        super(inParent, "Big Solution/Classification ...", false);
        myParent = inParent;
        classModel = inClass;
        solModel = inSol;
        this.paintScreen();
    }

    private void paintScreen() {
        Point p = myParent.getLocationOnScreen();
        Font boldArial14 = new Font("Arial", Font.BOLD, 14);

        this.setBounds(p.x + 250, p.y + 20, 200, 400);
        Container cPane = this.getContentPane();
        cPane.setLayout(new GridBagLayout());
        this.setResizable(false);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.NONE;
        gbc.weightx = 0;
        gbc.weighty = 0;
        gbc.ipadx = 0;
        gbc.ipady = 0;
        gbc.insets = new Insets(4, 4, 4, 4);

        SOLUTION: {
            JTree tree = new JTree(solModel);
            JScrollPane jsp = new JScrollPane(tree);
            jsp.setPreferredSize(new Dimension(350, 550));

            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.gridwidth = 1;
            gbc.gridheight = 10;
            gbc.anchor = GridBagConstraints.FIRST_LINE_END;

            cPane.add(jsp, gbc);
        }

        CLASSIFICATION: {
            JTree tree = new JTree(classModel);
            JScrollPane jsp = new JScrollPane(tree);
            jsp.setPreferredSize(new Dimension(350, 550));

            gbc.gridx = 1;
            gbc.gridy = 0;
            gbc.gridwidth = 1;
            gbc.gridheight = 10;
            gbc.anchor = GridBagConstraints.FIRST_LINE_END;

            cPane.add(jsp, gbc);
        }

        BUTTONS: {
            JButton closeButton = new JButton("Close");
            closeButton.setFont(boldArial14);
            closeButton.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    EnlargeSolutionDialog.this.setVisible(false);
                    EnlargeSolutionDialog.this.dispose();
                }
            }
            );

            gbc.gridx = 0;
            gbc.gridy = 10;
            gbc.gridheight = 1;
            gbc.gridwidth = 2;
            gbc.anchor = GridBagConstraints.LAST_LINE_END;

            cPane.add(closeButton, gbc);
        }

        this.pack();
        this.setVisible(true);
    }

}
