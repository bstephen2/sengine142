package uk.me.bstephen.Meson;

public class QuotationQueryProcess extends QueryProcess {
    private String quotationPattern;

    private String sql =	"SELECT b.name, a.sid, COUNT(*) AS num_quotes " +
                            "FROM problemsource as a, source as b " +
                            "WHERE (a.sid = b.sid) AND (b.name REGEXP ?) " +
                            "GROUP BY a.sid " +
                            "ORDER BY num_quotes DESC, b.name";

    public QuotationQueryProcess(Meson inParent) {
        super(inParent);
    }

    public void getInfo() {
        QuotationFilterDialog qfd = new QuotationFilterDialog(parent);
        quotationPattern = qfd.getQuotationPattern();
    }

    public void getSQL() {
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, quotationPattern);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    public void showResult() {
        QuotationLeagueQueryResult qlqr = new QuotationLeagueQueryResult(parent, rs, "Quotation Query - results");
    }

}