package uk.me.bstephen.Meson;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import java.sql.*;
import java.text.*;

public class ComposerLeagueQueryResult extends QueryResult {
    public ComposerLeagueQueryResult(Meson inParent, ResultSet rs, String title) {
        super(inParent, rs, title);
    }

    public void paintResult() {
        ComposerLeagueModel clm = new ComposerLeagueModel(rs);
        clm.loadTableData();

        JTable CLTable = new JTable(clm);
        CLTable.setPreferredScrollableViewportSize(new Dimension(500, 400));
        CLTable.setFont(boldCourier14);
        CLTable.setRowSelectionAllowed(false);

        TableColumn total = CLTable.getColumn("num_comp");
        total.setMaxWidth(120);
        total.setMinWidth(120);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.gridheight = 5;
        gbc.anchor = GridBagConstraints.CENTER;

        cPane.add(new JScrollPane(CLTable), gbc);
    }
}