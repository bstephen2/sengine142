package uk.me.bstephen.Meson;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import java.sql.*;
import java.util.*;

public class Meson extends JFrame {
    private static final String querySQL01 = 	"SELECT c.name " +
            "FROM composer as c, problemcomposer as a " +
            "WHERE " +
            "(a.pid = ?) " +
            "AND (a.cid = c.cid) " +
            "ORDER BY c.name";

    private static final String querySQL02 =	"SELECT pid, kings, gbr, position, ep, cast " +
            "FROM problem " +
            "WHERE (stip = '#2')";

    private static final String querySQL03 =	"SELECT a.pid, a.kings, a.gbr, a.position, a.ep, a.cast " +
            "FROM problem AS a, classol AS b " +
            "WHERE (a.stip = '#2') AND (a.pid = b.pid) " +
            "AND (b.sol IS NULL)";

    private static final String querySQL06 =	"SELECT a.pid, a.kings, a.gbr, a.position, a.ep, a.cast " +
            "FROM problem AS a, classol AS b " +
            "WHERE (a.stip = '#3') AND (a.pid = b.pid) " +
            "AND (b.sol IS NULL)";

    private static final String countSQL02 =	"SELECT COUNT(*) as total " +
            "FROM problem " +
            "WHERE (stip = '#2')";

    private static final String countSQL03 =	"SELECT COUNT(*) as total " +
            "FROM classol AS a, problem AS b " +
            "WHERE (b.stip = '#2') AND (a.pid = b.pid) " +
            "AND (a.sol IS NULL)";

    private static final String countSQL06 =	"SELECT COUNT(*) as total " +
            "FROM classol AS a, problem AS b " +
            "WHERE (b.stip = '#3') AND (a.pid = b.pid) " +
            "AND (a.sol IS NULL)";

    private static final String querySQL04 =	"SELECT snapid FROM snap";

    private static final String querySQL05 =	"SELECT pid, kings, gbr, position, ep, cast " +
            "FROM problem " +
            "WHERE (stip = '#3')";

    //private static final String querySQL06 =	"SELECT pid, kings, gbr, position " +
    //"FROM problem " +
    //"WHERE (stip = '#3') " +
    //"AND (sol IS NULL)";

    private static final String querySQL07 =	"SELECT pid, kings, gbr, position " +
            "FROM problem " +
            "WHERE (stip = '#4')";

    private static final String querySQL08 =	"SELECT pid, kings, gbr, position " +
            "FROM problem " +
            "WHERE (stip = '#4') " +
            "AND (sol IS NULL)";

    private static final String countSQL05 =	"SELECT COUNT(*) as total " +
            "FROM problem " +
            "WHERE (stip = '#3')";

    // private static final String countSQL06 =	"SELECT COUNT(*) as total " +
    //"FROM problem " +
    //"WHERE (stip = '#3') " +
    // "AND (sol IS NULL)";

    private static final String countSQL07 =	"SELECT COUNT(*) as total " +
            "FROM problem " +
            "WHERE (stip = '#4')";

    private static final String countSQL08 =	"SELECT COUNT(*) as total " +
            "FROM problem " +
            "WHERE (stip = '#4') " +
            "AND (sol IS NULL)";
    private Connection conn;
    private Font boldArial14;
    private Font boldArial16;
    private Integer selectedProblem;
    private Integer selectedSnap;
    private Integer selectedMatch;

    private JTabbedPane topTabs;

    private JPanel abstracted;
    private JPanel problems;
    private JPanel composers;
    private JPanel sources;
    private JPanel awards;
    private JPanel snaps;
    private JPanel standardQueries;
    private JPanel matches;

    private JTable abstractedTable;
    private JTable sourceTable;
    private JTable awardTable;
    private JTable composerTable;
    private JTable problemTable;
    private JTable snapTable;
    private JTable matchTable;
    private JList compList;
    private JList snapList;
    private JList matchList;
    private JList sqList;

    private SourceTableModel sourceModel;
    private AbstractedTableModel abstractedModel;
    private AwardTableModel awardModel;
    private ComposerTableModel composerModel;
    private ProblemTableModel problemModel;
    private DefaultListModel probCompModel;
    private DefaultListModel matchCompModel;
    private DefaultListModel snapModel;
    private SnapTableModel snapTableModel;
    private MatchTableModel matchModel;

    private JMenuBar menuBar;

    private JMenu solveMenu;
    private JMenuItem all2s;
    private JMenuItem u2s;
    private JMenuItem all3s;
    private JMenuItem u3s;
    private JMenuItem all4s;
    private JMenuItem u4s;

    private JMenu searchMenu;
    private JMenuItem find2Features;

    private JMenu importMenu;

    private JMenu exportMenu;
    private JMenuItem exportKalulu;

    static Meson application;

    public static void main(String args[]) {

        MesonFunc.init();
        //System.out.println("MesonFunc.init");
        application = new Meson();
        //System.out.println("new Meson");
        application.ConnectToDB();
        //System.out.println("connect");
        application.PaintScreen();
        //System.out.println("paint");

        application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public Meson() {
        super("Meson");
    }

    public void ConnectToDB() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            //UIManager.setLookAndFeel("com.sun.java.swing.plaf.gtk.GTKLookAndFeel");
            //UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
            //UIManager.setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");
            //UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
            Class.forName("com.mysql.jdbc.Driver").newInstance();
        } catch (Exception e) {
            System.out.println(e);
            System.exit(1);
        }
    }

    public void matchSelectedProblem() {
        MatchDialog md = new MatchDialog(application);
        boolean set = md.getSet();
        boolean tries = md.getTries();

        if (md.getCancelled() == false) {
            DisplayMatchDialog dmd = new DisplayMatchDialog(application, selectedProblem, set, tries);
        }

        md.dispose();
    }

    public void displayMatches() {
        matchModel.loadTableData();
        matchModel.fireTableDataChanged();
        topTabs.setSelectedIndex(2);
    }

    public void displayFeaturedProblems() {
        problemModel.fireTableDataChanged();
    }

    public void PaintScreen() {
        //System.out.println("In PaintScreen");
        boldArial14 = new Font("Arial", Font.BOLD, 14);
        boldArial16 = new Font("Arial", Font.BOLD, 16);
        //setBounds(15, 20, 1000, 700);

        menuBar = new JMenuBar();
        setJMenuBar(menuBar);
        solveMenu = new JMenu("Solve");

        all2s = new JMenuItem("All #2s");

        all2s.addActionListener
        (
        new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                SolvingDialog sa = new SolvingDialog(application, "#2", querySQL02, countSQL02);
            }
        }
        );

        solveMenu.add(all2s);
        u2s = new JMenuItem("Unsolved #2s");

        u2s.addActionListener
        (
        new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                SolvingDialog sa = new SolvingDialog(application, "#2", querySQL03, countSQL03);
            }
        }
        );

        solveMenu.add(u2s);

        all3s = new JMenuItem("All #3s");

        all3s.addActionListener
        (
        new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                SolvingDialog sa = new SolvingDialog(application, "#3", querySQL05, countSQL05);
            }
        }
        );

        solveMenu.add(all3s);

        u3s = new JMenuItem("Unsolved #3s");

        u3s.addActionListener
        (
        new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                SolvingDialog sa = new SolvingDialog(application, "#3", querySQL06, countSQL06);
            }
        }
        );

        solveMenu.add(u3s);

        all4s = new JMenuItem("All #4s");
        all4s.setEnabled(false);

        all4s.addActionListener
        (
        new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                SolvingDialog sa = new SolvingDialog(application, "#4", querySQL07, countSQL07);
            }
        }
        );

        solveMenu.add(all4s);

        u4s = new JMenuItem("Unsolved #4s");
        u4s.setEnabled(false);

        u4s.addActionListener
        (
        new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                SolvingDialog sa = new SolvingDialog(application, "#4", querySQL08, countSQL08);
            }
        }
        );

        solveMenu.add(u4s);

        searchMenu = new JMenu("Search");
        find2Features = new JMenuItem("Find #2 features");

        find2Features.addActionListener
        (
        new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                FeatureFilterDialog ffd = new FeatureFilterDialog(application, problemModel);
            }
        }
        );

        searchMenu.add(find2Features);

        importMenu = new JMenu("Import");

        exportMenu = new JMenu("Export");
        exportKalulu = new JMenuItem("-> Kalulu");

        exportKalulu.addActionListener
        (
        new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                KaluluExportDialog ked = new KaluluExportDialog(application, problemModel);
            }
        }
        );

        exportMenu.add(exportKalulu);

        menuBar.add(solveMenu);
        menuBar.add(searchMenu);
        menuBar.add(importMenu);
        menuBar.add(exportMenu);

        //System.out.println("Menus done");

        topTabs = new JTabbedPane();
        abstracted = new JPanel();
        problems = new JPanel();
        //composers = new JPanel();
        //sources = new JPanel();
        //awards = new JPanel();
        snaps = new JPanel();
        standardQueries = new JPanel();
        matches = new JPanel();

        topTabs.addTab("Problems", problems);
        topTabs.addTab("Standard Queries", standardQueries);
        topTabs.addTab("Matches", matches);
        topTabs.addTab("Snaps", snaps);
        //topTabs.addTab("Composers", composers);
        //topTabs.addTab("Sources", sources);
        //topTabs.addTab("Awards", awards);
        topTabs.addTab("Abstracted", abstracted);

        //System.out.println("Tabs created");
        this.PaintProblems();
        //System.out.println("Problems done");
        this.PaintStandardQueries();
        //System.out.println("StandardQueries done");
        this.PaintMatches();
        //System.out.println("Matches done");
        this.PaintSnaps();
        //System.out.println("Snaps done");
        //this.PaintComposers();
        //System.out.println("Composers done");
        //this.PaintSources();
        //System.out.println("Sources done");
        //this.PaintAwards();
        //System.out.println("Awards done");
        this.PaintAbstracted();
        //System.out.println("Abtracted done");

        this.getContentPane().add(topTabs);
        pack();
        setVisible(true);
    }

    private void PaintStandardQueries() {

        //System.out.println("PaintStandardQueries");
        JButton runButton;
        Vector sQueries;

        GridBagConstraints sqGbc = new GridBagConstraints();
        Insets in = new Insets(5, 5, 5, 5);
        sqGbc.insets = in;

        standardQueries.setLayout(new GridBagLayout());

        LIST_BOX: {
            sQueries = new Vector();
            sQueries.addElement("Count problems");
            sQueries.addElement("Count by stipulation");
            sQueries.addElement("Quotation");
            sQueries.addElement("Composer");
            sQueries.addElement("Original");
            sQueries.addElement("Award");
            sQueries.addElement("Quotation league");
            sQueries.addElement("Composer league");
            sQueries.addElement("Original league");
            sQueries.addElement("Award league");

            sqList = new JList(sQueries);
            sqList.setFont(boldArial14);
            sqList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            sqList.setSelectedIndex(0);

            sqGbc.gridx = 0;
            sqGbc.gridy = 0;
            sqGbc.gridwidth = 1;
            sqGbc.gridheight = 5;
            sqGbc.fill = GridBagConstraints.NONE;
            sqGbc.anchor = GridBagConstraints.CENTER;

            standardQueries.add(sqList, sqGbc);
        }

        BUTTON: {
            runButton = new JButton("Run");
            runButton.setFont(boldArial14);

            runButton.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    QueryProcess qp;
                    int sel;

                    sel = sqList.getSelectedIndex();

                    switch (sel) {
                    case (0):
                        qp = new CountProblemsQueryProcess(application);
                        qp.run();
                        break;

                    case (1):
                        qp = new CountStipulationsQueryProcess(application);
                        qp.run();
                        break;

                    case (2):
                        qp = new QuotationQueryProcess(application);
                        qp.getInfo();
                        qp.run();
                        break;

                    case (3):
                        qp = new ComposerQueryProcess(application);
                        qp.getInfo();
                        qp.run();
                        break;

                    case (4):
                        qp = new OriginalQueryProcess(application);
                        qp.getInfo();
                        qp.run();
                        break;

                    case (5):
                        qp = new AwardQueryProcess(application);
                        qp.getInfo();
                        qp.run();
                        break;

                    case (6):
                        qp = new QuotationLeagueQueryProcess(application);
                        qp.run();
                        break;

                    case (7):
                        qp = new ComposerLeagueQueryProcess(application);
                        qp.run();
                        break;

                    case (8):
                        qp = new OriginalLeagueQueryProcess(application);
                        qp.run();
                        break;

                    case (9):
                        qp = new AwardLeagueQueryProcess(application);
                        qp.run();
                        break;

                    default:
                        break;
                    }
                }
            }
            );

            sqGbc.gridx = 0;
            sqGbc.gridy = 5;
            sqGbc.gridwidth = 1;
            sqGbc.gridheight = 1;
            sqGbc.fill = GridBagConstraints.NONE;
            sqGbc.anchor = GridBagConstraints.CENTER;

            standardQueries.add(runButton, sqGbc);
        }
    }

    private void PaintMatches() {
        //System.out.println("PrintMatches");
        JButton displayButton;
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        matches.setLayout(new GridBagLayout());

        MATCH_TABLE: {
            matchModel = new MatchTableModel();
            matchModel.loadTableData();
            matchTable = new JTable(matchModel);
            matchTable.setPreferredScrollableViewportSize(new Dimension(900, 400));
            matchTable.setFont(boldArial14);
            matchTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

            ListSelectionModel rowSM = matchTable.getSelectionModel();

            rowSM.addListSelectionListener(new ListSelectionListener() {
                public void valueChanged(ListSelectionEvent e) {
                    if (e.getValueIsAdjusting()) {
                        return;
                    }

                    ListSelectionModel lsm = (ListSelectionModel) e.getSource();

                    if (lsm.isSelectionEmpty() == true) {
                        matchCompModel.removeAllElements();
                    } else {
                        matchCompModel.removeAllElements();
                        int sr = lsm.getMinSelectionIndex();
                        selectedMatch = (Integer) matchModel.getValueAt(sr, 1);

                        try {
                            PreparedStatement pstmt;
                            ResultSet rs;
                            Connection conn;

                            conn = DriverManager.getConnection("jdbc:mysql://localhost/meson", "bstephen", "rice37");
                            pstmt = conn.prepareStatement(querySQL01);
                            pstmt.setString(1, selectedMatch.toString());
                            rs = pstmt.executeQuery();

                            while (rs.next() == true) {
                                matchCompModel.addElement(rs.getString("c.name"));
                            }

                            rs.close();
                            pstmt.close();
                            conn.close();

                        } catch (Exception ae) {
                            ae.printStackTrace();
                            System.exit(1);
                        }
                    }
                }
            });


            TableColumn years = matchTable.getColumn("Years");
            TableColumn kings = matchTable.getColumn("Kings");
            TableColumn gbr = matchTable.getColumn("GBR");
            TableColumn stip = matchTable.getColumn("Stip.");
            TableColumn award = matchTable.getColumn("Award");
            TableColumn pid = matchTable.getColumn("PID");
            TableColumn mch = matchTable.getColumn("MATCH");

            pid.setMaxWidth(60);
            years.setMaxWidth(80);
            kings.setMaxWidth(40);
            gbr.setMaxWidth(60);
            stip.setMaxWidth(60);
            award.setMaxWidth(200);
            mch.setMaxWidth(60);

            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.gridwidth = 1;
            gbc.gridheight = 3;
            gbc.fill = GridBagConstraints.BOTH;
            gbc.anchor = GridBagConstraints.CENTER;
            matches.add(new JScrollPane(matchTable), gbc);
        }

        MATCH_COMPOSERS: {
            JScrollPane ls;
            matchCompModel = new DefaultListModel();
            matchList = new JList(matchCompModel);
            matchList.setFont(boldArial14);

            gbc.gridx = 0;
            gbc.gridy = 3;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;
            gbc.fill = GridBagConstraints.NONE;
            gbc.anchor = GridBagConstraints.CENTER;

            ls = new JScrollPane(matchList);
            ls.setPreferredSize(new Dimension(300, 100));
            matches.add(ls, gbc);
        }

        MATCH_BUTTONS: {
            JPanel buttons = new JPanel();

            displayButton = new JButton("Display");
            displayButton.setFont(boldArial14);

            displayButton.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    DisplayProblem dmp = new DisplayProblem(application, selectedMatch, true);
                }
            }
            );


            buttons.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 15));

            buttons.add(displayButton);

            gbc.gridx = 0;
            gbc.gridy = 4;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;
            gbc.fill = GridBagConstraints.NONE;
            matches.add(buttons, gbc);
        }

    }

    private void PaintSnaps() {
        //System.out.println("PaintSnaps");
        JButton snapRefreshButton;
        JButton snapWeedButton;
        JButton snapDisplayButton;

        GridBagConstraints snapGbc = new GridBagConstraints();
        Insets in = new Insets(5, 5, 5, 5);
        snapGbc.insets = in;

        snaps.setLayout(new GridBagLayout());

        SNAP_TABLE: {
            JScrollPane ls;
            snapModel = new DefaultListModel();
            snapList = new JList(snapModel);
            this.loadSnapList();
            snapList.setFont(boldArial14);


            snapGbc.gridx = 0;
            snapGbc.gridy = 0;
            snapGbc.gridwidth = 1;
            snapGbc.gridheight = 1;
            snapGbc.fill = GridBagConstraints.NONE;
            snapGbc.anchor = GridBagConstraints.CENTER;

            ls = new JScrollPane(snapList);
            ls.setPreferredSize(new Dimension(100, 100));
            snaps.add(ls, snapGbc);
        }

        SNAPPROBLEM_TABLE: {
            JScrollPane jsp;
            snapTableModel = new SnapTableModel();
            snapTableModel.loadTableData(0);
            snapTable = new JTable(snapTableModel);
            snapTable.setFont(boldArial14);
            snapTable.setPreferredScrollableViewportSize(new Dimension(900, 200));

            snapList.addListSelectionListener(new ListSelectionListener() {
                public void valueChanged(ListSelectionEvent e) {
                    int pos;
                    Integer id;

                    if (e.getValueIsAdjusting() == false) {
                        pos = snapList.getSelectedIndex();

                        if (pos != -1) {
                            id = (Integer) snapList.getSelectedValue();
                            snapTableModel.loadTableData(id.intValue());
                        } else {
                            snapTableModel.loadTableData(0);
                        }
                    }
                }
            });

            ListSelectionModel rowSM = snapTable.getSelectionModel();

            rowSM.addListSelectionListener(new ListSelectionListener() {
                public void valueChanged(ListSelectionEvent e) {
                    if (e.getValueIsAdjusting()) {
                        return;
                    }

                    ListSelectionModel lsm = (ListSelectionModel) e.getSource();

                    if (lsm.isSelectionEmpty() == true) {
                        selectedSnap = null;
                    } else {
                        int sr = lsm.getMinSelectionIndex();
                        selectedSnap = (Integer) snapTableModel.getValueAt(sr, 0);
                    }
                }
            });

            TableColumn years = snapTable.getColumn("Years");
            TableColumn kings = snapTable.getColumn("Kings");
            TableColumn gbr = snapTable.getColumn("GBR");
            TableColumn stip = snapTable.getColumn("Stip.");
            TableColumn award = snapTable.getColumn("Award");
            TableColumn pid = snapTable.getColumn("PID");

            pid.setMaxWidth(60);
            years.setMaxWidth(80);
            kings.setMaxWidth(40);
            gbr.setMaxWidth(60);
            stip.setMaxWidth(60);
            award.setMaxWidth(150);

            snapGbc.gridx = 0;
            snapGbc.gridy = 1;
            snapGbc.gridwidth = 1;
            snapGbc.gridheight = 1;
            snapGbc.fill = GridBagConstraints.NONE;
            snapGbc.anchor = GridBagConstraints.CENTER;

            jsp = new JScrollPane(snapTable);
            snaps.add(jsp, snapGbc);
        }

        BUTTONS: {
            JPanel snapButtons = new JPanel();

            snapRefreshButton = new JButton("Refresh");
            snapRefreshButton.setFont(boldArial14);

            snapRefreshButton.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    try {
                        Runtime rt = Runtime.getRuntime();
                        //Process p = rt.exec("Perl -w c:\\\\Snap.pl");
                        //Process p = rt.exec("perl -w c:\\bin\\Snap.pl");
                        Process p = rt.exec("perl  c:\\bin\\Snapv1.pl 2> c:\\MesonError.txt");
                        p.waitFor();
                    } catch (Exception e) {
                        e.printStackTrace();
                        System.exit(1);
                    }

                    Meson.this.loadSnapList();
                }
            }
            );

            snapWeedButton = new JButton("Weed");
            snapWeedButton.setFont(boldArial14);

            snapWeedButton.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    try {
                        Runtime rt = Runtime.getRuntime();
                        Process p = rt.exec("perl -w c:\\bin\\Weed.pl");
                        p.waitFor();
                    } catch (Exception e) {
                        e.printStackTrace();
                        System.exit(1);
                    }

                    Meson.this.loadSnapList();
                }
            }
            );

            snapDisplayButton = new JButton("Display");
            snapDisplayButton.setFont(boldArial14);

            snapDisplayButton.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    if (selectedSnap != null) {
                        DisplayProblem dp = new DisplayProblem(application, selectedSnap, false);
                    }
                }
            }
            );

            snapButtons.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 15));

            snapButtons.add(snapRefreshButton);
            snapButtons.add(snapWeedButton);
            snapButtons.add(snapDisplayButton);

            snapGbc.gridx = 0;
            snapGbc.gridy = 2;
            snapGbc.gridwidth = 1;
            snapGbc.gridheight = 1;
            snapGbc.fill = GridBagConstraints.NONE;
            snaps.add(snapButtons, snapGbc);
        }
    }

    private void PaintProblems() {
        //System.out.println("Entered PaintProblems");
        JButton problemInsertButton;
        JButton problemDeleteButton;
        JButton problemFilterButton;
        JButton problemDisplayButton;

        GridBagConstraints gbc = new GridBagConstraints();
        Insets in = new Insets(5, 5, 5, 5);
        gbc.insets = in;

        problems.setLayout(new GridBagLayout());

        PROBLEM_TABLE: {
            problemModel = new ProblemTableModel();
            //System.out.println("Calling problemModel.loadTableData()");
            problemModel.loadTableData();
            //System.out.println("Return from problemModel.loadTableData()");

            problemTable = new JTable(problemModel);
            problemTable.setPreferredScrollableViewportSize(new Dimension(1000, 400));
            problemTable.setFont(boldArial16);
            problemTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            TableColumn colgbr = problemTable.getColumnModel().getColumn(3);
            colgbr.setMinWidth(80);
            TableColumn colkings = problemTable.getColumnModel().getColumn(2);
            colkings.setMinWidth(60);
            TableColumn colpid = problemTable.getColumnModel().getColumn(0);
            colpid.setMinWidth(80);
            TableColumn colyears = problemTable.getColumnModel().getColumn(1);
            colyears.setMinWidth(100);

            // Deal with selections

            ListSelectionModel rowSM = problemTable.getSelectionModel();

            rowSM.addListSelectionListener(new ListSelectionListener() {
                public void valueChanged(ListSelectionEvent e) {
                    if (e.getValueIsAdjusting()) {
                        return;
                    }

                    ListSelectionModel lsm = (ListSelectionModel) e.getSource();

                    if (lsm.isSelectionEmpty() == true) {
                        // Empty compList
                        probCompModel.removeAllElements();
                    } else {
                        // Refill compList
                        probCompModel.removeAllElements();
                        int sr = lsm.getMinSelectionIndex();
                        selectedProblem = (Integer) problemModel.getValueAt(sr, 0);

                        try {
                            PreparedStatement pstmt;
                            ResultSet rs;
                            Connection conn;

                            conn = DriverManager.getConnection("jdbc:mysql://localhost/meson", "bstephen", "rice37");
                            pstmt = conn.prepareStatement(querySQL01);
                            pstmt.setString(1, selectedProblem.toString());
                            rs = pstmt.executeQuery();

                            while (rs.next() == true) {
                                probCompModel.addElement(rs.getString("c.name"));
                            }

                            rs.close();
                            pstmt.close();
                            conn.close();
                        } catch (Exception ae) {
                            ae.printStackTrace();
                            System.exit(1);
                        }
                    }
                }
            });

            TableColumn years = problemTable.getColumn("Years");
            TableColumn kings = problemTable.getColumn("Kings");
            TableColumn gbr = problemTable.getColumn("GBR");
            TableColumn stip = problemTable.getColumn("Stip.");
            TableColumn award = problemTable.getColumn("Award");
            TableColumn pid = problemTable.getColumn("PID");

            pid.setMaxWidth(60);

            years.setMinWidth(90);
            years.setMaxWidth(90);

            kings.setMaxWidth(40);

            gbr.setMaxWidth(60);

            stip.setMinWidth(40);
            stip.setMaxWidth(40);

            award.setMinWidth(100);
            award.setMaxWidth(100);

            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.gridwidth = 1;
            gbc.gridheight = 3;
            gbc.fill = GridBagConstraints.BOTH;
            gbc.anchor = GridBagConstraints.CENTER;
            problems.add(new JScrollPane(problemTable), gbc);
        }

        COMPOSER_TABLE: {
            JScrollPane ls;
            probCompModel = new DefaultListModel();
            compList = new JList(probCompModel);
            compList.setFont(boldArial14);

            gbc.gridx = 0;
            gbc.gridy = 3;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;
            gbc.fill = GridBagConstraints.NONE;
            gbc.anchor = GridBagConstraints.CENTER;

            ls = new JScrollPane(compList);
            ls.setPreferredSize(new Dimension(300, 100));
            problems.add(ls, gbc);
        }

        BUTTONS: {
            JPanel buttons = new JPanel();

            problemDisplayButton = new JButton("Display");
            problemDisplayButton.setFont(boldArial14);

            problemDisplayButton.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    DisplayProblem dp = new DisplayProblem(application, selectedProblem, false);
                }
            }
            );

            problemInsertButton = new JButton("Insert");
            problemInsertButton.setFont(boldArial14);

            problemInsertButton.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    InsertProblem ip = new InsertProblem(application);
                }
            }
            );

            problemDeleteButton = new JButton("Delete");
            problemDeleteButton.setFont(boldArial14);

            problemDeleteButton.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    JOptionPane.showMessageDialog(problems,
                                                  "This facility not yet written!",
                                                  "Meson",
                                                  JOptionPane.WARNING_MESSAGE);
                }
            }
            );

            problemFilterButton = new JButton("Filter");
            problemFilterButton.setFont(boldArial14);

            problemFilterButton.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    ProblemFilterDialog pfd = new ProblemFilterDialog(application, problemModel);
                }
            }
            );

            buttons.setLayout(new FlowLayout(FlowLayout.RIGHT, 15, 15));

            buttons.add(problemDisplayButton);
            buttons.add(problemInsertButton);
            buttons.add(problemDeleteButton);
            buttons.add(problemFilterButton);

            gbc.gridx = 0;
            gbc.gridy = 4;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;
            gbc.fill = GridBagConstraints.NONE;
            gbc.anchor = GridBagConstraints.EAST;
            problems.add(buttons, gbc);
        }
    }

    private void PaintComposers() {
        //System.out.println("PaintComposers");
        JButton composerInsertButton;
        JButton composerDeleteButton;

        GridBagConstraints gbc = new GridBagConstraints();
        Insets in = new Insets(5, 5, 5, 5);
        gbc.insets = in;

        composers.setLayout(new GridBagLayout());

        COMPOSER_TABLE: {
            composerModel = new ComposerTableModel();
            composerModel.loadTableData();

            composerTable = new JTable(composerModel);
            composerTable.setPreferredScrollableViewportSize(new Dimension(700, 511));
            composerTable.setFont(boldArial14);
            composerTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

            TableColumn yob = composerTable.getColumn("YOB");
            TableColumn yod = composerTable.getColumn("YOD");
            TableColumn dob = composerTable.getColumn("DOB");
            TableColumn dod = composerTable.getColumn("DOD");

            yob.setMaxWidth(50);
            yob.setMinWidth(50);
            yod.setMaxWidth(50);
            yod.setMinWidth(50);
            dob.setMaxWidth(80);
            dob.setMinWidth(80);
            dod.setMinWidth(80);
            dod.setMaxWidth(80);

            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.gridwidth = 1;
            gbc.gridheight = 4;
            gbc.fill = GridBagConstraints.BOTH;
            gbc.anchor = GridBagConstraints.CENTER;

            composers.add(new JScrollPane(composerTable), gbc);
        }

        BUTTONS: {
            JPanel buttons = new JPanel();

            composerInsertButton = new JButton("Insert");
            composerInsertButton.setFont(boldArial14);

            composerInsertButton.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    JOptionPane.showMessageDialog(composers,
                                                  "This facility not yet written!",
                                                  "Meson",
                                                  JOptionPane.WARNING_MESSAGE);
                }
            }
            );

            composerDeleteButton = new JButton("Delete");
            composerDeleteButton.setFont(boldArial14);

            composerDeleteButton.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    JOptionPane.showMessageDialog(composers,
                                                  "This facility not yet written!",
                                                  "Meson",
                                                  JOptionPane.WARNING_MESSAGE);
                }
            }
            );

            buttons.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 15));

            buttons.add(composerInsertButton);
            buttons.add(composerDeleteButton);

            gbc.gridx = 0;
            gbc.gridy = 4;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;
            gbc.fill = GridBagConstraints.NONE;
            composers.add(buttons, gbc);
        }
    }

    private void PaintSources() {
        //System.out.println("PaintSources");
        JButton sourceInsertButton;
        JButton sourceDeleteButton;

        GridBagConstraints gbc = new GridBagConstraints();
        Insets in = new Insets(5, 5, 5, 5);
        gbc.insets = in;

        sources.setLayout(new GridBagLayout());

        SOURCE_TABLE: {
            sourceModel = new SourceTableModel();
            sourceModel.loadTableData();

            sourceTable = new JTable(sourceModel);
            sourceTable.setPreferredScrollableViewportSize(new Dimension(700, 511));
            sourceTable.setFont(boldArial14);
            sourceTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.gridwidth = 1;
            gbc.gridheight = 4;
            gbc.fill = GridBagConstraints.BOTH;
            gbc.anchor = GridBagConstraints.CENTER;

            sources.add(new JScrollPane(sourceTable), gbc);
        }

        BUTTONS: {
            JPanel buttons = new JPanel();
            sourceInsertButton = new JButton("Insert");
            sourceInsertButton.setFont(boldArial14);

            sourceInsertButton.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    JOptionPane.showMessageDialog(sources,
                                                  "This facility not yet written!",
                                                  "Meson",
                                                  JOptionPane.WARNING_MESSAGE);
                }
            }
            );

            sourceDeleteButton = new JButton("Delete");
            sourceDeleteButton.setFont(boldArial14);

            sourceDeleteButton.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    JOptionPane.showMessageDialog(sources,
                                                  "This facility not yet written!",
                                                  "Meson",
                                                  JOptionPane.WARNING_MESSAGE);
                }
            }
            );

            buttons.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 15));

            buttons.add(sourceInsertButton);
            buttons.add(sourceDeleteButton);

            gbc.gridx = 0;
            gbc.gridy = 4;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;
            gbc.fill = GridBagConstraints.NONE;

            sources.add(buttons, gbc);
        }
    }

    private void PaintAwards() {
        //System.out.println("PaintAwards");
        JButton awardInsertButton;
        JButton awardDeleteButton;

        GridBagConstraints gbc = new GridBagConstraints();
        Insets in = new Insets(5, 5, 5, 5);
        gbc.insets = in;

        awards.setLayout(new GridBagLayout());

        AWARD_TABLE: {
            awardModel = new AwardTableModel();
            awardModel.loadTableData();

            awardTable = new JTable(awardModel);
            awardTable.setPreferredScrollableViewportSize(new Dimension(500, 511));
            awardTable.setFont(boldArial14);
            awardTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.gridwidth = 1;
            gbc.gridheight = 4;
            gbc.fill = GridBagConstraints.BOTH;
            gbc.anchor = GridBagConstraints.CENTER;

            awards.add(new JScrollPane(awardTable), gbc);
        }

        BUTTONS: {
            JPanel buttons = new JPanel();

            awardInsertButton = new JButton("Insert");
            awardInsertButton.setFont(boldArial14);

            awardInsertButton.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    JOptionPane.showMessageDialog(awards,
                                                  "This facility not yet written!",
                                                  "Meson",
                                                  JOptionPane.WARNING_MESSAGE);
                }
            }
            );

            awardDeleteButton = new JButton("Delete");
            awardDeleteButton.setFont(boldArial14);

            awardDeleteButton.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    JOptionPane.showMessageDialog(awards,
                                                  "This facility not yet written!",
                                                  "Meson",
                                                  JOptionPane.WARNING_MESSAGE);
                }
            }
            );

            buttons.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 15));

            buttons.add(awardInsertButton);
            buttons.add(awardDeleteButton);

            gbc.gridx = 0;
            gbc.gridy = 4;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;
            gbc.fill = GridBagConstraints.NONE;

            awards.add(buttons, gbc);
        }
    }

    private void PaintAbstracted() {
        //System.out.println("PainAbstracted");
        JButton abstractInsertButton;
        JButton abstractDeleteButton;

        GridBagConstraints gbc = new GridBagConstraints();
        Insets in = new Insets(5, 5, 5, 5);
        gbc.insets = in;

        abstracted.setLayout(new GridBagLayout());

        ABSTRACTED_TABLE: {
            abstractedModel = new AbstractedTableModel();
            abstractedModel.loadTableData();

            abstractedTable = new JTable(abstractedModel);
            abstractedTable.setPreferredScrollableViewportSize(new Dimension(900, 511));
            abstractedTable.setFont(boldArial14);
            abstractedTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

            TableColumn year = abstractedTable.getColumn("Year");
            TableColumn done = abstractedTable.getColumn("Done?");
            TableColumn hague = abstractedTable.getColumn("Hague");
            TableColumn next = abstractedTable.getColumn("Next");

            year.setMaxWidth(80);
            year.setMinWidth(80);
            done.setMaxWidth(40);
            done.setMinWidth(40);
            hague.setMaxWidth(150);
            hague.setMinWidth(150);
            next.setMaxWidth(150);
            next.setMinWidth(150);

            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.gridwidth = 1;
            gbc.gridheight = 4;
            gbc.fill = GridBagConstraints.BOTH;
            gbc.anchor = GridBagConstraints.CENTER;

            abstracted.add(new JScrollPane(abstractedTable), gbc);
        }

        BUTTONS: {
            JPanel buttons = new JPanel();

            abstractInsertButton = new JButton("Insert");
            abstractInsertButton.setFont(boldArial14);

            abstractInsertButton.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    JOptionPane.showMessageDialog(abstracted,
                                                  "This facility not yet written!",
                                                  "Meson",
                                                  JOptionPane.WARNING_MESSAGE);
                }
            }
            );

            abstractDeleteButton = new JButton("Delete");
            abstractDeleteButton.setFont(boldArial14);

            abstractDeleteButton.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    JOptionPane.showMessageDialog(abstracted,
                                                  "This facility not yet written!",
                                                  "Meson",
                                                  JOptionPane.WARNING_MESSAGE);
                }
            }
            );

            buttons.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 15));

            buttons.add(abstractInsertButton);
            buttons.add(abstractDeleteButton);

            gbc.gridx = 0;
            gbc.gridy = 4;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;
            gbc.fill = GridBagConstraints.NONE;

            abstracted.add(buttons, gbc);
        }
    }

    private void loadSnapList() {
        Connection conn;
        Statement stmt;
        ResultSet rs;
        Integer snapid;

        try {
            snapModel.clear();
            conn = DriverManager.getConnection("jdbc:mysql://localhost/meson", "bstephen", "rice37");
            stmt = conn.createStatement();
            rs = stmt.executeQuery(querySQL04);

            while (rs.next()) {
                snapid = new Integer(rs.getInt("snapid"));
                snapModel.addElement(snapid);
            }

            conn.close();
            snapModel.trimToSize();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
}
