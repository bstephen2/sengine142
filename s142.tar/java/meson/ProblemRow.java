/*
 * ProblemRow.java
 *
 * Created on 29 July 2007, 13:51
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package uk.me.bstephen.Meson;

class ProblemRow {
    Integer pid;
    String years;
    String kings;
    String gbr;
    String stip;
    String award;
    String source;

    public ProblemRow(int in_pid, String in_years, String in_kings, String in_gbr, String in_stip, String in_award, String in_source) {
        pid = new Integer(in_pid);
        years = new String(in_years);
        kings = new String(in_kings);
        gbr = new String(in_gbr);
        stip = new String(in_stip);
        award = new String(in_award);
        source = new String(in_source);
    }

    public Integer getPID() {
        return pid;
    }

    public String getYears() {
        return years;
    }

    public String getKings() {
        return kings;
    }

    public String getGBR() {
        return gbr;
    }

    public String getStip() {
        return stip;
    }

    public String getAward() {
        return award;
    }

    public String getSource() {
        return source;
    }
}
