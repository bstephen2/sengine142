package uk.me.bstephen.Meson;

import java.sql.*;

public abstract class QueryProcess {
    protected Connection conn;
    protected PreparedStatement pstmt;
    protected ResultSet rs;
    protected Meson parent;

    public QueryProcess(Meson inParent) {
        parent = inParent;
    }

    protected void run() {
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/meson", "bstephen", "rice37");
            this.getSQL();
            rs = pstmt.executeQuery();
            this.showResult();

            rs.close();
            pstmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    public abstract void getInfo();

    public abstract void getSQL();

    public abstract void showResult();

}