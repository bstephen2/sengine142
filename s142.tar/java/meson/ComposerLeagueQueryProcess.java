package uk.me.bstephen.Meson;

public class ComposerLeagueQueryProcess extends QueryProcess {
    private String sql =	"SELECT b.name, a.cid, COUNT(*) AS num_comp " +
                            "FROM problemcomposer as a, composer as b " +
                            "WHERE (a.cid = b.cid) " +
                            "GROUP BY a.cid " +
                            "ORDER BY num_comp DESC, b.name";

    public ComposerLeagueQueryProcess(Meson inParent) {
        super(inParent);
    }

    public void getInfo() {
    }

    public void getSQL() {
        try {
            pstmt = conn.prepareStatement(sql);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    public void showResult() {
        ComposerLeagueQueryResult clqr = new ComposerLeagueQueryResult(parent, rs, "Composer League Query - results");
    }
}