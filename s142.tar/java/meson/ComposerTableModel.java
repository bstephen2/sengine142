package uk.me.bstephen.Meson;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
import java.sql.*;
import java.util.*;

public class ComposerTableModel extends AbstractTableModel {
    private static final String selectSQL = new String("SELECT name, yob, yod, dob, dod " +
            "FROM composer ORDER BY name");

    ArrayList data;

    private Class[] columnClasses = new Class[] { String.class, String.class, String.class, String.class, String.class };
    private String[] columnNames = new String[] { "Name", "YOB", "YOD", "DOB", "DOD" };

    public Object getValueAt(int row, int col) {
        ComposerRow s = (ComposerRow) data.get(row);

        switch (col) {
        case 0	:
            return s.getName();

        case 1	:
            return s.getYOB();

        case 2	:
            return s.getYOD();

        case 3	:
            return s.getDOB();

        case 4	:
            return s.getDOD();

        default	:
            return null;
        }
    }

    public int getColumnCount() {
        return 5;
    }

    public int getRowCount() {
        return data.size();
    }

    public String getColumnName(int col) {
        return columnNames[col];
    }

    public Class getColumnClass(int col) {
        return columnClasses[col];
    }

    public void loadTableData() {
        Connection conn;
        Statement stmt;
        ResultSet rs;
        ComposerRow sr;

        data = new ArrayList(5500);

        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/meson", "bstephen", "rice37");
            stmt = conn.createStatement();
            rs = stmt.executeQuery(selectSQL);

            while (rs.next()) {
                sr = new ComposerRow(	rs.getString("name"),
                                        rs.getString("yob"),
                                        rs.getString("yod"),
                                        rs.getDate("dob"),
                                        rs.getDate("dod"));
                data.add(sr);
            }

            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
}

class ComposerRow {
    String name;
    String yob;
    String yod;
    String dob;
    String dod;

    public ComposerRow(String in_name, String in_yob, String in_yod, java.sql.Date in_dob, java.sql.Date in_dod) {
        name = new String(in_name);
        yob = (in_yob == null) ? null : new String(in_yob);
        yod = (in_yod == null) ? null : new String(in_yod);
        dob = (in_dob == null) ? null : in_dob.toString();
        dod = (in_dod == null) ? null : in_dod.toString();
    }

    public String getName() {
        return name;
    }

    public String getYOB() {
        return yob;
    }

    public String getYOD() {
        return yod;
    }

    public String getDOB() {
        return dob;
    }

    public String getDOD() {
        return dod;
    }
}