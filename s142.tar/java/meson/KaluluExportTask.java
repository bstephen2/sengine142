package uk.me.bstephen.Meson;

import java.sql.*;

public class KaluluExportTask extends LongTask {
    private ProblemTableModel myPTM;

    public KaluluExportTask(ProblemTableModel inPTM) {
        myPTM = inPTM;
        finished = false;
        count = 0;
    }

    public void run() {
        int total;
        int i;
        Integer pid;
        KaluluOut ko;
        Connection conn;

        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/meson", "bstephen", "rice37");
            total = myPTM.getRowCount();

            for (i = 0; i < total; i++) {
                pid = (Integer) myPTM.getValueAt(i, 0);
                ko = new KaluluOut(conn, pid);
                ko.produceKaluluFile(i + 1);
                count++;
            }

            conn.close();
            finished = true;
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
}
