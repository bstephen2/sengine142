package uk.me.bstephen.Meson;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class MultiKeySelection implements JComboBox.KeySelectionManager, ActionListener {
    public static final int MAX_SEARCH_STRING = 16;
    protected String searchString = "";
    protected int searchStringSize;
    protected Timer searchTimer;
    protected static final int SEARCH_DELAY = 3000;

    public MultiKeySelection() {
        searchTimer = new Timer(SEARCH_DELAY, this);
        searchTimer.setRepeats(false);
    }

    public void actionPerformed(ActionEvent evt) {
        searchStringSize = 0;
        searchString = "";
    }

    public int selectionForKey(char iKey, ComboBoxModel model) {
        int selectedIndex = 0;
        int modelSize = model.getSize();

        if (searchStringSize == MAX_SEARCH_STRING) {
            return -1;
        }

        if (iKey == KeyEvent.CHAR_UNDEFINED) {
            searchStringSize = 0;
            searchString = "";
            Toolkit.getDefaultToolkit().beep();
            return -1;
        }

        searchTimer.stop();

        char realKey = ("" + iKey).toLowerCase().charAt(0);
        searchString += realKey;
        searchStringSize++;

        Object selectedItem = model.getSelectedItem();

        if (selectedItem != null) {
            String searchString = selectedItem.toString();

            for (int i = 0; i < modelSize; i++) {
                if (searchString.equals(model.getElementAt(i).toString())) {
                    selectedIndex = i;
                    break;
                }
            }
        }

        boolean found = false;

        for (int i = 0; i < modelSize; i++) {
            String entry = ((String)model.getElementAt(selectedIndex)).toLowerCase();

            if (entry.length() >= searchStringSize) {
                if (entry.startsWith(searchString)) {
                    found = true;
                    break;
                }
            }

            if (++selectedIndex == modelSize) {
                selectedIndex = 0;
            }
        }

        searchTimer.start();
        return found == true ? selectedIndex : -1;
    }
}