package uk.me.bstephen.Meson;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import java.sql.*;
import java.text.*;

public abstract class QueryResult extends JDialog {
    protected Point p;
    protected Container cPane;
    protected Font boldArial14;
    protected Font boldCourier14;
    protected Meson parent;
    protected ResultSet rs;
    protected GridBagConstraints gbc;

    public QueryResult(Meson inParent, ResultSet inRs, String title) {
        super(inParent, title, true);

        rs = inRs;
        parent = inParent;

        p = parent.getLocationOnScreen();

        this.setBounds(p.x + 20, p.y + 60, 960, 630);
        cPane = this.getContentPane();
        cPane.setLayout(new GridBagLayout());
        this.setResizable(false);

        boldArial14 = new Font("Arial", Font.BOLD, 14);
        boldCourier14 = new Font("Courier New", Font.BOLD, 14);

        gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.NONE;
        gbc.weightx = 0;
        gbc.weighty = 0;
        gbc.ipadx = 0;
        gbc.ipady = 0;
        gbc.insets = new Insets(5, 5, 5, 5);

        this.paintResult();

        JButton closeButton = new JButton("Close");
        closeButton.setFont(boldArial14);
        closeButton.addActionListener
        (
        new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                QueryResult.this.setVisible(false);
                QueryResult.this.dispose();
            }
        }
        );

        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.anchor = GridBagConstraints.CENTER;

        cPane.add(closeButton, gbc);

        this.setVisible(true);
    }

    public abstract void paintResult();
}
