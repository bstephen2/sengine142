package uk.me.bstephen.Meson;

import java.util.*;
import java.io.*;
import java.util.zip.*;
import java.util.regex.*;
import javax.swing.tree.*;
import uk.me.bstephen.Chess.*;

public class StaticFeatureList {
    private ArrayList features;
    private ArrayList setPatterns;
    private ArrayList virtualPatterns;
    private ArrayList actualPatterns;
    private ArrayList anyPatterns;
    private ArrayList localAnyPatterns;

    public StaticFeatureList() {
        features = new ArrayList();
        setPatterns = new ArrayList();
        virtualPatterns = new ArrayList();
        actualPatterns = new ArrayList();
        anyPatterns = new ArrayList();
    }

    public void addFeature(String inFeat) {
        features.add(inFeat);
    }

    public void addPattern(String phase, String pattern) {
        Pattern pat = Pattern.compile(pattern);

        if (phase.compareTo("Any") == 0) {
            anyPatterns.add(pat);
        } else if (phase.compareTo("Set") == 0) {
            setPatterns.add(pat);
        } else if (phase.compareTo("Virtual") == 0) {
            virtualPatterns.add(pat);
        } else { // actual
            actualPatterns.add(pat);
        }
    }

    public boolean isAHit(InputStream inClass) {
        if (inClass == null) {
            return false;
        } else {
            DefaultTreeModel classModel;
            MoveNode root;
            MoveNode mn;
            MoveNode general;
            MoveNode set;
            ArrayList virtualNodes;
            MoveNode virtual;
            MoveNode actual;
            int count;
            int i;
            Enumeration topLevels;
            Enumeration generalLines;
            ArrayList classes;
            Enumeration setLines;
            ArrayList setStrings;
            Enumeration actualLines;
            ArrayList actualStrings;
            Enumeration virtualLines;
            ArrayList virtualStrings;
            Iterator it;

            try {
                GZIPInputStream zClass = new GZIPInputStream(inClass);
                ObjectInputStream classSerial = new ObjectInputStream(zClass);
                classModel = (DefaultTreeModel) classSerial.readObject();
                classSerial.close();
                classes = new ArrayList();
                root = (MoveNode) classModel.getRoot();
                topLevels = root.children();
                general = (MoveNode) topLevels.nextElement();
                set = (MoveNode) topLevels.nextElement();
                virtual = (MoveNode) topLevels.nextElement();
                actual = (MoveNode) topLevels.nextElement();
                virtualNodes = new ArrayList();

                generalLines = general.children();

                while (generalLines.hasMoreElements() == true) {
                    mn = (MoveNode) generalLines.nextElement();
                    classes.add((String) mn.getUserObject());
                }

                it = features.iterator();

                LOOP1:

                while (it.hasNext() == true) {
                    if (classes.contains((String) it.next()) == false) {
                        return false;
                    }
                }

                localAnyPatterns = new ArrayList(anyPatterns);

                if ((localAnyPatterns.size() > 0) || (setPatterns.size() > 0)) {
                    ArrayList cl = new ArrayList();
                    setLines = set.children();

                    while (setLines.hasMoreElements() == true) {
                        mn = (MoveNode) setLines.nextElement();
                        cl.add((String) mn.getUserObject());
                    }

                    if ((localAnyPatterns.size() > 0) && (cl.size() > 0)) {
                        it = localAnyPatterns.iterator();

                        while (it.hasNext() == true) {
                            Pattern p = (Pattern) it.next();
                            Matcher m = p.matcher("A");
                            Iterator c = cl.iterator();
                            CLOOP1:

                            while (c.hasNext() == true) {
                                m.reset((CharSequence) c.next());

                                if (m.find() == true) {
                                    it.remove();
                                    break CLOOP1;
                                }
                            }
                        }
                    }

                    if (setPatterns.size() > 0) {
                        if (cl.size() == 0) {
                            return false;
                        }

                        boolean found = false;
                        it = setPatterns.iterator();
                        CLOOP3:

                        while (it.hasNext() == true) {
                            Pattern p = (Pattern) it.next();
                            Matcher m = p.matcher("A");
                            Iterator c = cl.iterator();
                            found = false;
                            CLOOP2:

                            while (c.hasNext() == true) {
                                m.reset((CharSequence) c.next());

                                if (m.find() == true) {
                                    found = true;
                                    break CLOOP2;
                                }
                            }

                            if (found == false) {
                                break CLOOP3;
                            }
                        }

                        if (found == false) {
                            return false;
                        }
                    }
                }

                if ((localAnyPatterns.size() > 0) || (virtualPatterns.size() > 0)) {
                    ArrayList cl = new ArrayList();
                    virtualLines = virtual.children();

                    while (virtualLines.hasMoreElements() == true) {
                        MoveNode bds = (MoveNode) virtualLines.nextElement();
                        Enumeration e = bds.children();

                        while (e.hasMoreElements() == true) {
                            mn = (MoveNode) e.nextElement();
                            cl.add((String) mn.getUserObject());
                        }

                    }

                    if ((localAnyPatterns.size() > 0) && (cl.size() > 0)) {
                        it = localAnyPatterns.iterator();

                        while (it.hasNext() == true) {
                            Pattern p = (Pattern) it.next();
                            Matcher m = p.matcher("A");
                            Iterator c = cl.iterator();
                            CLOOP11:

                            while (c.hasNext() == true) {
                                m.reset((CharSequence) c.next());

                                if (m.find() == true) {
                                    it.remove();
                                    break CLOOP11;
                                }
                            }
                        }
                    }

                    if (virtualPatterns.size() > 0) {
                        if (cl.size() == 0) {
                            return false;
                        }

                        boolean found = false;
                        it = virtualPatterns.iterator();
                        CLOOP31:

                        while (it.hasNext() == true) {
                            Pattern p = (Pattern) it.next();
                            Matcher m = p.matcher("A");
                            Iterator c = cl.iterator();
                            found = false;
                            CLOOP21:

                            while (c.hasNext() == true) {
                                m.reset((CharSequence) c.next());

                                if (m.find() == true) {
                                    found = true;
                                    break CLOOP21;
                                }
                            }

                            if (found == false) {
                                break CLOOP31;
                            }
                        }

                        if (found == false) {
                            return false;
                        }
                    }
                }

                if ((localAnyPatterns.size() > 0) || (actualPatterns.size() > 0)) {
                    ArrayList cl = new ArrayList();
                    actualLines = actual.children();

                    while (actualLines.hasMoreElements() == true) {
                        mn = (MoveNode) actualLines.nextElement();
                        cl.add((String) mn.getUserObject());
                    }

                    if ((localAnyPatterns.size() > 0) && (cl.size() > 0)) {
                        it = localAnyPatterns.iterator();
                        boolean found = false;

                        while (it.hasNext() == true) {
                            Pattern p = (Pattern) it.next();
                            Matcher m = p.matcher("A");
                            Iterator c = cl.iterator();
                            found = false;
                            CLOOP13:

                            while (c.hasNext() == true) {
                                m.reset((CharSequence) c.next());

                                if (m.find() == true) {
                                    it.remove();
                                    found = true;
                                    break CLOOP13;
                                }
                            }

                            if (found == false) {
                                return false;
                            }
                        }
                    }

                    if (actualPatterns.size() > 0) {
                        if (cl.size() == 0) {
                            return false;
                        }

                        boolean found = false;
                        it = actualPatterns.iterator();
                        CLOOP32:

                        while (it.hasNext() == true) {
                            Pattern p = (Pattern) it.next();
                            Matcher m = p.matcher("A");
                            Iterator c = cl.iterator();
                            found = false;
                            CLOOP22:

                            while (c.hasNext() == true) {
                                m.reset((CharSequence) c.next());

                                if (m.find() == true) {
                                    found = true;
                                    break CLOOP22;
                                }
                            }

                            if (found == false) {
                                break CLOOP32;
                            }
                        }

                        if (found == false) {
                            return false;
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                System.exit(1);
            }

            return true;
        }
    }
}