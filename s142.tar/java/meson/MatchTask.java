package uk.me.bstephen.Meson;

import java.sql.*;
import java.io.*;

public class MatchTask extends LongTask {
    private static String targetSQL = "SELECT class FROM classol WHERE pid = ?";
    private static String restSQL =  "SELECT a.pid, a.class " +
                                     "FROM classol AS a, problem AS b " +
                                     "WHERE (a.pid >= ?) AND " +
                                     "(a.pid <= ?) AND " +
                                     "(a.pid != ?) AND " +
                                     "(a.pid = b.pid) AND " +
                                     "(b.stip = '#2') AND " +
                                     "(a.class IS NOT NULL)";
    private static String updateSQL = "UPDATE problem SET mch = ? WHERE pid = ?";
    private static String countSQL = "SELECT MAX(pid) AS mpid FROM problem";
    private Integer toMatch;
    private FeatureCollection fc;
    private boolean set;
    private boolean tries;
    private Runtime rt;

    public MatchTask(Integer inMatch, boolean inSet, boolean inTries) {
        toMatch = inMatch;
        set = inSet;
        tries = inTries;
        finished = false;
        count = 0;
        rt = Runtime.getRuntime();
        rt.gc();
    }

    public void run() {
        this.processTarget();
        this.processRest();
        finished = true;
    }

    private void processTarget() {
        Connection conn;
        InputStream classStream;

        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/meson", "bstephen", "rice37");

            PreparedStatement pstmt;
            PreparedStatement ustmt;
            ResultSet rs;

            pstmt = conn.prepareStatement(targetSQL);
            pstmt.setString(1, toMatch.toString());
            rs = pstmt.executeQuery();

            if (rs.next() == true) {
                classStream = rs.getBinaryStream("class");
                fc = new FeatureCollection(classStream, set, tries);
                ustmt = conn.prepareStatement(updateSQL);
                ustmt.setString(1, "0");
                ustmt.setString(2, toMatch.toString());
                ustmt.execute();
            } else {
                System.exit(1);
            }

            rs.close();
            pstmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }

        count = 1;
    }

    private void processRest() {
        FeatureCollection fColl;
        Connection conn;
        InputStream classStream;
        PreparedStatement pstmt;
        PreparedStatement ustmt;
        ResultSet rs;
        int pid;
        Float mch;
        int maxPid;
        int i;

        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/meson", "bstephen", "rice37");

            pstmt = conn.prepareStatement(countSQL);
            rs = pstmt.executeQuery();
            rs.next();
            maxPid = rs.getInt("mpid");
            rs.close();
            pstmt.close();

            i = 0;

            while (i <= maxPid) {
                rt.gc();
                pstmt = conn.prepareStatement(restSQL);
                pstmt.setString(1, String.valueOf(i));
                pstmt.setString(2, String.valueOf(i + 499));
                pstmt.setString(3, toMatch.toString());
                rs = pstmt.executeQuery();

                while (rs.next() == true) {
                    pid = rs.getInt("pid");
                    classStream = rs.getBinaryStream("class");
                    fColl = new FeatureCollection(classStream, set, tries);
                    mch = fc.match(fColl);
                    ustmt = conn.prepareStatement(updateSQL);
                    ustmt.setString(1, mch.toString());
                    ustmt.setInt(2, pid);
                    ustmt.execute();
                    count++;
                }

                rs.close();
                pstmt.close();
                i += 500;
            }

            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
}