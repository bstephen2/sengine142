package uk.me.bstephen.Meson;

import java.sql.*;
import java.util.*;

public class ProblemAdder {
    private static final String addProblemSQL =	"INSERT INTO problem " +
            "(years, kings, gbr, position, sid, aid, stip, date, version, eid) " +
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    private static final String getPIDSQL = "SELECT max(pid) AS maxpid FROM problem";

    private static final String addComposersSQL =	"INSERT INTO problemcomposer " +
            "(pid, cid) " +
            "VALUES (?, ?)";

    private static final String addSourcesSQL =	"INSERT INTO problemsource " +
            "(pid, sid, years) " +
            "VALUES (?, ?, ?)";

    private static final String addClassSolSQL = "INSERT INTO classol " +
            "(pid) " +
            "VALUES (?)";
    // Problem

    private int pid;

    private String years;
    private String kings;
    private String gbr;
    private String position;
    private String stip;
    private Long sid;
    private Long aid;
    private java.sql.Date date;
    private String version;
    private Long eid;

    // ProblemComposer

    private ArrayList cid;	// of Longs

    // ProblemSource

    private Long problemSid;
    private String sourceYears;

    //private

    public ProblemAdder() {
        super();
    }

    public void setSourceYears(String inYears) {
        sourceYears = inYears;
    }

    public void setProblemSid(Long inSid) {
        problemSid = inSid;
    }

    public void setCids(ArrayList inCid) {
        cid = inCid;
    }

    public void setYears(String inYears) {
        years = inYears;
    }

    public void setKings(String inKings) {
        kings = inKings;
    }

    public void setGbr(String inGbr) {
        gbr = inGbr;
    }

    public void setPosition(String inPosition) {
        position = inPosition;
    }

    public void setStip(String inStip) {
        stip = inStip;
    }

    public void setSid(Long inSid) {
        sid = inSid;
    }

    public void setAid(Long inAid) {
        aid = inAid;
    }

    public void setDate(java.sql.Date inDate) {
        date = inDate;
    }

    public void setVersion(String inVersion) {
        version = inVersion;
    }

    public void setEid(Long inEid) {
        eid = new Long(inEid.longValue());
    }

    public void addProblem() {
        // Don't forget to increment totals in composer and source.
        Connection conn;
        PreparedStatement addProblemPstmt;
        PreparedStatement addComposerPstmt;
        PreparedStatement addQuotePstmt;
        PreparedStatement addClassSolPstmt;
        Statement enquirePID;
        ResultSet rs;
        long pid = 0L;
        Iterator i;
        long tempCid;

        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/meson", "bstephen", "rice37");
            addProblemPstmt = conn.prepareStatement(addProblemSQL);
            addProblemPstmt.setString(1, years);
            addProblemPstmt.setString(2, kings);
            addProblemPstmt.setString(3, gbr);
            addProblemPstmt.setString(4, position);
            addProblemPstmt.setLong(5, sid.longValue());
            addProblemPstmt.setLong(6, aid.longValue());
            addProblemPstmt.setString(7, stip);
            addProblemPstmt.setDate(8, date);
            addProblemPstmt.setString(9, version);
            addProblemPstmt.setLong(10, eid.longValue());
            //System.out.println(addProblemPstmt.toString());
            addProblemPstmt.executeUpdate();
            addProblemPstmt.close();

            enquirePID = conn.createStatement();
            rs = enquirePID.executeQuery(getPIDSQL);

            if (rs.next() == true) {
                pid = rs.getLong("maxpid");
            } else {
                System.exit(1);
            }

            rs.close();
            enquirePID.close();

            i = cid.iterator();

            while (i.hasNext() == true) {
                tempCid = ((Long) i.next()).longValue();
                addComposerPstmt = conn.prepareStatement(addComposersSQL);
                addComposerPstmt.setLong(1, pid);
                addComposerPstmt.setLong(2, tempCid);
                addComposerPstmt.executeUpdate();
                addComposerPstmt.close();
            }

            if (problemSid != null) {
                addQuotePstmt = conn.prepareStatement(addSourcesSQL);
                addQuotePstmt.setLong(1, pid);
                addQuotePstmt.setLong(2, problemSid.longValue());
                addQuotePstmt.setString(3, sourceYears);
                addQuotePstmt.executeUpdate();
                addQuotePstmt.close();
            }

            addClassSolPstmt = conn.prepareStatement(addClassSolSQL);
            addClassSolPstmt.setLong(1, pid);
            addClassSolPstmt.executeUpdate();
            addClassSolPstmt.close();

            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
}