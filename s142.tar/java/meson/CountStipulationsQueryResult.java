package uk.me.bstephen.Meson;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import java.sql.*;
import java.text.*;

public class CountStipulationsQueryResult extends QueryResult {
    public CountStipulationsQueryResult(Meson inParent, ResultSet rs, String title) {
        super(inParent, rs, title);
    }

    public void paintResult() {
        CountStipModel csm = new CountStipModel(rs);
        csm.loadTableData();

        JTable stipTable = new JTable(csm);
        stipTable.setPreferredScrollableViewportSize(new Dimension(200, 290));
        stipTable.setFont(boldCourier14);
        stipTable.setRowSelectionAllowed(false);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.gridheight = 5;
        gbc.anchor = GridBagConstraints.CENTER;

        cPane.add(new JScrollPane(stipTable), gbc);
    }
}