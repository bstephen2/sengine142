package uk.me.bstephen.Meson;

public class OriginalQueryProcess extends QueryProcess {
    private String originalPattern;

    private String sql =	"SELECT b.name, a.sid, COUNT(*) AS num_origs " +
                            "FROM problem as a, source as b " +
                            "WHERE (a.sid = b.sid) AND (b.name REGEXP ?) " +
                            "GROUP BY a.sid " +
                            "ORDER BY num_origs DESC, b.name";

    public OriginalQueryProcess(Meson inParent) {
        super(inParent);
    }

    public void getInfo() {
        OriginalFilterDialog ofd = new OriginalFilterDialog(parent);
        originalPattern = ofd.getOriginalPattern();
    }

    public void getSQL() {
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, originalPattern);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    public void showResult() {
        OriginalLeagueQueryResult olqr = new OriginalLeagueQueryResult(parent, rs, "Original Query - results");
    }
}