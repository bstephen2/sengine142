package uk.me.bstephen.Meson;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;

public class ProblemFilterDialog extends JDialog {
    private static final String select = new String("SELECT a.pid, a.years, a.kings, a.gbr, a.stip, c.name, b.name " +
            "FROM problem as a, ");

    private static final String compFroms = new String("problemcomposer as d, composer as e, ");
    private static final String quotFroms = new String("problemsource as f, source as g, ");
    private static final String classFroms = new String("classol as h, ");
    private static final String froms = new String("source as b, award as c ");
    private static final String order = new String("ORDER BY a.years, a.kings, a.gbr");

    private Font boldArial14;
    private Point p;
    private GridBagConstraints gbc;

    private JTextField compText;
    private JTextField pidText;
    private JTextField yearsText;
    private JTextField kingsText;
    private JTextField gbrText;
    private JTextField stipText;
    private JTextField awardText;
    private JTextField srcText;
    private JTextField quotText;
    private JTextField classText;

    private final ProblemTableModel model;

    public ProblemFilterDialog(Meson inParent, ProblemTableModel inModel) {
        super(inParent, "Filter Problems", true);
        p = inParent.getLocationOnScreen();
        model = inModel;

        this.setBounds(p.x + 20, p.y + 60, 200, 400);
        Container cPane = this.getContentPane();
        cPane.setLayout(new GridBagLayout());
        this.setResizable(false);

        boldArial14 = new Font("Arial", Font.BOLD, 14);

        gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.NONE;
        gbc.weightx = 0;
        gbc.weighty = 0;
        gbc.ipadx = 0;
        gbc.ipady = 0;
        gbc.insets = new Insets(4, 4, 4, 4);

        COMPOSER: {
            JLabel compLab = new JLabel("Composer:", SwingConstants.RIGHT);
            compLab.setFont(boldArial14);

            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;
            gbc.anchor = GridBagConstraints.PAGE_END;

            cPane.add(compLab, gbc);

            compText = new JTextField(20);
            compText.setFont(boldArial14);

            gbc.gridx = 1;
            gbc.gridy = 0;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;
            gbc.anchor = GridBagConstraints.PAGE_START;

            cPane.add(compText, gbc);
        }

        PID: {
            JLabel pidLab = new JLabel("PID:", SwingConstants.RIGHT);
            pidLab.setFont(boldArial14);

            gbc.gridx = 0;
            gbc.gridy = 1;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;
            gbc.anchor = GridBagConstraints.PAGE_END;

            cPane.add(pidLab, gbc);

            pidText = new JTextField(20);
            pidText.setFont(boldArial14);

            gbc.gridx = 1;
            gbc.gridy = 1;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;
            gbc.anchor = GridBagConstraints.PAGE_START;

            cPane.add(pidText, gbc);
        }

        YEARS: {
            JLabel yearsLab = new JLabel("Years:", SwingConstants.RIGHT);
            yearsLab.setFont(boldArial14);

            gbc.gridx = 0;
            gbc.gridy = 2;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;
            gbc.anchor = GridBagConstraints.PAGE_END;

            cPane.add(yearsLab, gbc);

            yearsText = new JTextField(20);
            yearsText.setFont(boldArial14);

            gbc.gridx = 1;
            gbc.gridy = 2;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;
            gbc.anchor = GridBagConstraints.PAGE_START;

            cPane.add(yearsText, gbc);
        }

        KINGS: {
            JLabel kingsLab = new JLabel("Kings:", SwingConstants.RIGHT);
            kingsLab.setFont(boldArial14);

            gbc.gridx = 0;
            gbc.gridy = 3;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;
            gbc.anchor = GridBagConstraints.PAGE_END;

            cPane.add(kingsLab, gbc);

            kingsText = new JTextField(20);
            kingsText.setFont(boldArial14);

            gbc.gridx = 1;
            gbc.gridy = 3;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;
            gbc.anchor = GridBagConstraints.PAGE_START;

            cPane.add(kingsText, gbc);
        }

        GBR: {
            JLabel gbrLab = new JLabel("GBR:", SwingConstants.RIGHT);
            gbrLab.setFont(boldArial14);

            gbc.gridx = 0;
            gbc.gridy = 4;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;
            gbc.anchor = GridBagConstraints.PAGE_END;

            cPane.add(gbrLab, gbc);

            gbrText = new JTextField(20);
            gbrText.setFont(boldArial14);

            gbc.gridx = 1;
            gbc.gridy = 4;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;
            gbc.anchor = GridBagConstraints.PAGE_START;

            cPane.add(gbrText, gbc);
        }

        STIP: {
            JLabel stipLab = new JLabel("Stip:", SwingConstants.RIGHT);
            stipLab.setFont(boldArial14);

            gbc.gridx = 0;
            gbc.gridy = 5;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;
            gbc.anchor = GridBagConstraints.PAGE_END;

            cPane.add(stipLab, gbc);

            stipText = new JTextField(20);
            stipText.setFont(boldArial14);

            gbc.gridx = 1;
            gbc.gridy = 5;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;
            gbc.anchor = GridBagConstraints.PAGE_START;

            cPane.add(stipText, gbc);
        }

        AWARD: {
            JLabel awardLab = new JLabel("Award:", SwingConstants.RIGHT);
            awardLab.setFont(boldArial14);

            gbc.gridx = 0;
            gbc.gridy = 6;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;
            gbc.anchor = GridBagConstraints.PAGE_END;

            cPane.add(awardLab, gbc);

            awardText = new JTextField(20);
            awardText.setFont(boldArial14);

            gbc.gridx = 1;
            gbc.gridy = 6;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;
            gbc.anchor = GridBagConstraints.PAGE_START;

            cPane.add(awardText, gbc);
        }

        SOURCE: {
            JLabel srcLab = new JLabel("Source:", SwingConstants.RIGHT);
            srcLab.setFont(boldArial14);

            gbc.gridx = 0;
            gbc.gridy = 7;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;
            gbc.anchor = GridBagConstraints.PAGE_END;

            cPane.add(srcLab, gbc);

            srcText = new JTextField(20);
            srcText.setFont(boldArial14);

            gbc.gridx = 1;
            gbc.gridy = 7;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;
            gbc.anchor = GridBagConstraints.PAGE_START;

            cPane.add(srcText, gbc);
        }

        QUOTATION: {
            JLabel quotLab = new JLabel("Quotation:", SwingConstants.RIGHT);
            quotLab.setFont(boldArial14);

            gbc.gridx = 0;
            gbc.gridy = 8;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;
            gbc.anchor = GridBagConstraints.PAGE_END;

            cPane.add(quotLab, gbc);

            quotText = new JTextField(20);
            quotText.setFont(boldArial14);

            gbc.gridx = 1;
            gbc.gridy = 8;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;
            gbc.anchor = GridBagConstraints.PAGE_START;

            cPane.add(quotText, gbc);
        }

        CLASS: {
            JLabel classLab = new JLabel("Classification:", SwingConstants.RIGHT);
            classLab.setFont(boldArial14);

            gbc.gridx = 0;
            gbc.gridy = 9;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;
            gbc.anchor = GridBagConstraints.PAGE_END;

            cPane.add(classLab, gbc);

            classText = new JTextField(20);
            classText.setFont(boldArial14);

            gbc.gridx = 1;
            gbc.gridy = 9;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;
            gbc.anchor = GridBagConstraints.PAGE_START;

            cPane.add(classText, gbc);
        }

        BUTTONS: {
            JPanel buttons = new JPanel();
            buttons.setLayout(new FlowLayout(FlowLayout.RIGHT, 4, 4));
            JButton okButton = new JButton("OK");
            okButton.setFont(boldArial14);

            okButton.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    StringBuffer conds = new StringBuffer();
                    String comp = compText.getText().trim();
                    String pid = pidText.getText().trim();
                    String years = yearsText.getText().trim();
                    String kings = kingsText.getText().trim();
                    String gbr = gbrText.getText().trim();
                    String stip = stipText.getText().trim();
                    String award = awardText.getText().trim();
                    String source = srcText.getText().trim();
                    String quot = quotText.getText().trim();
                    String cl = classText.getText().trim();

                    conds.append(select);

                    if (comp.length() != 0) {
                        conds.append(compFroms);
                    }

                    if (quot.length() != 0) {
                        conds.append(quotFroms);
                    }

                    if (cl.length() != 0) {
                        conds.append(classFroms);
                    }

                    conds.append(froms);
                    conds.append("WHERE ");

                    if (comp.length() != 0) {
                        conds.append("(a.pid = d.pid) ");
                        conds.append("AND (d.cid = e.cid) ");
                        conds.append("AND (e.name REGEXP '");
                        conds.append(comp);
                        conds.append("') AND ");
                    }

                    if (quot.length() != 0) {
                        conds.append("(a.pid = f.pid) ");
                        conds.append("AND (f.sid = g.sid) ");
                        conds.append("AND (g.name REGEXP '");
                        conds.append(quot);
                        conds.append("') AND ");
                    }

                    if (cl.length() != 0) {
                        conds.append("(a.pid = h.pid) AND ");
                        conds.append("( UNCOMPRESS(h.class) REGEXP '");
                        conds.append(cl);
                        conds.append("') AND ");
                    }

                    conds.append("(a.sid = b.sid) ");
                    conds.append("AND (a.aid = c.aid) ");

                    if (pid.length() != 0) {
                        conds.append("AND (a.pid = ");
                        conds.append(pid);
                        conds.append(") ");
                    }

                    if (years.length() != 0) {
                        conds.append("AND (a.years REGEXP '");
                        conds.append(years);
                        conds.append("') ");
                    }

                    if (kings.length() != 0) {
                        conds.append("AND (a.kings REGEXP '");
                        conds.append(kings);
                        conds.append("') ");
                    }

                    if (gbr.length() != 0) {
                        conds.append("AND (a.gbr REGEXP '");
                        conds.append(gbr);
                        conds.append("') ");
                    }

                    if (stip.length() != 0) {
                        conds.append("AND (a.stip REGEXP '");
                        conds.append(stip);
                        conds.append("') ");
                    }

                    if (award.length() != 0) {
                        conds.append("AND (c.name REGEXP '");
                        conds.append(award);
                        conds.append("') ");
                    }

                    if (source.length() != 0) {
                        conds.append("AND (b.name REGEXP '");
                        conds.append(source);
                        conds.append("') ");
                    }

                    conds.append(order);

                    model.loadFilteredTableData(conds.toString());
                    ProblemFilterDialog.this.setVisible(false);
                }
            }
            );

            JButton cancelButton = new JButton("Cancel");
            cancelButton.setFont(boldArial14);

            cancelButton.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    ProblemFilterDialog.this.setVisible(false);
                }
            }
            );

            buttons.add(okButton);
            buttons.add(cancelButton);

            gbc.gridx = 1;
            gbc.gridy = 10;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;
            gbc.anchor = GridBagConstraints.LAST_LINE_END;

            cPane.add(buttons, gbc);
        }

        this.pack();
        this.setVisible(true);
    }
}
