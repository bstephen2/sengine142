package uk.me.bstephen.Meson;

public class AwardQueryProcess extends QueryProcess {
    private String awardPattern;

    private String sql =	"SELECT b.name, a.aid, COUNT(*) AS num_award " +
                            "FROM problem as a, award as b " +
                            "WHERE (a.aid = b.aid) AND (b.name REGEXP ?) " +
                            "GROUP BY a.aid " +
                            "ORDER BY num_award DESC, b.name";

    public AwardQueryProcess(Meson inParent) {
        super(inParent);
    }

    public void getInfo() {
        AwardFilterDialog afd = new AwardFilterDialog(parent);
        awardPattern = afd.getAwardPattern();
    }

    public void getSQL() {
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, awardPattern);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    public void showResult() {
        AwardLeagueQueryResult alqr = new AwardLeagueQueryResult(parent, rs, "Award Query - results");
    }

}