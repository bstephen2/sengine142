package uk.me.bstephen.Meson;

public class CountProblemsQueryProcess extends QueryProcess {
    private String sql = "SELECT COUNT(*) as total FROM problem";

    public CountProblemsQueryProcess(Meson inParent) {
        super(inParent);
    }

    public void getInfo() {
    }

    public void getSQL() {
        try {
            pstmt = conn.prepareStatement(sql);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    public void showResult() {
        CountProblemsQueryResult cpqr = new CountProblemsQueryResult(parent, rs, "Count problems - results");
    }
}