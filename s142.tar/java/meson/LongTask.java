package uk.me.bstephen.Meson;

public abstract class LongTask extends Thread {
    protected boolean finished;
    protected int count;

    public boolean isFinished() {
        return finished;
    }

    public int getCount() {
        return count;
    }
}
