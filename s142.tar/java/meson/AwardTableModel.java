package uk.me.bstephen.Meson;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
import java.sql.*;
import java.util.*;

public class AwardTableModel extends AbstractTableModel {
    private static final String selectSQL = new String("SELECT name FROM award ORDER BY name");

    ArrayList data;

    private Class[] columnClasses = new Class[] { String.class };
    private String[] columnNames = new String[] { "Name" };

    public Object getValueAt(int row, int col) {
        AwardRow s = (AwardRow) data.get(row);

        switch (col) {
        case 0	:
            return s.getName();

        default	:
            return null;
        }
    }

    public int getColumnCount() {
        return 1;
    }

    public int getRowCount() {
        return data.size();
    }

    public String getColumnName(int col) {
        return columnNames[col];
    }

    public Class getColumnClass(int col) {
        return columnClasses[col];
    }

    public void loadTableData() {
        Connection conn;
        Statement stmt;
        ResultSet rs;
        AwardRow sr;

        data = new ArrayList(300);

        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/meson", "bstephen", "rice37");
            stmt = conn.createStatement();
            rs = stmt.executeQuery(selectSQL);

            while (rs.next()) {
                sr = new AwardRow(rs.getString("name"));
                data.add(sr);
            }

            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
}

class AwardRow {
    String name;

    public AwardRow(String in_name) {
        name = new String(in_name);
    }

    public String getName() {
        return name;
    }
}