package uk.me.bstephen.Meson;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;

public class ComposerFilterDialog extends JDialog {
    private Font boldArial14;
    private Point p;
    private GridBagConstraints gbc;
    private JTextField compText;
    private String composerPattern;

    public ComposerFilterDialog(Meson inParent) {
        super(inParent, "Enter composer pattern", true);
        p = inParent.getLocationOnScreen();

        this.setBounds(p.x + 20, p.y + 60, 200, 400);
        Container cPane = this.getContentPane();
        cPane.setLayout(new GridBagLayout());
        this.setResizable(false);

        boldArial14 = new Font("Arial", Font.BOLD, 14);

        gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.NONE;
        gbc.weightx = 0;
        gbc.weighty = 0;
        gbc.ipadx = 0;
        gbc.ipady = 0;
        gbc.insets = new Insets(5, 5, 5, 5);

        COMPOSER: {
            compText = new JTextField(50);
            compText.setFont(boldArial14);

            gbc.gridx = 1;
            gbc.gridy = 0;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;
            gbc.anchor = GridBagConstraints.PAGE_START;

            cPane.add(compText, gbc);
        }

        BUTTONS: {
            JButton okButton = new JButton("OK");
            okButton.setFont(boldArial14);

            okButton.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    composerPattern = compText.getText();
                    ComposerFilterDialog.this.setVisible(false);
                }
            }
            );

            gbc.gridx = 1;
            gbc.gridy = 2;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;

            cPane.add(okButton, gbc);
        }

        this.pack();
        this.setVisible(true);
    }

    public String getComposerPattern() {
        return composerPattern;
    }
}
