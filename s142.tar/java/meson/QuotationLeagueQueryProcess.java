package uk.me.bstephen.Meson;

public class QuotationLeagueQueryProcess extends QueryProcess {
    private String sql =	"SELECT b.name, a.sid, COUNT(*) AS num_quotes " +
                            "FROM problemsource as a, source as b " +
                            "WHERE (a.sid = b.sid) " +
                            "GROUP BY a.sid " +
                            "ORDER BY num_quotes DESC, b.name";

    public QuotationLeagueQueryProcess(Meson inParent) {
        super(inParent);
    }

    public void getInfo() {
    }

    public void getSQL() {
        try {
            pstmt = conn.prepareStatement(sql);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    public void showResult() {
        QuotationLeagueQueryResult qlqr = new QuotationLeagueQueryResult(parent, rs, "Quotation League Query - results");
    }
}