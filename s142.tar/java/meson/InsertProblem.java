package uk.me.bstephen.Meson;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import javax.swing.table.*;
import javax.swing.tree.*;
import java.sql.*;
import java.io.*;
import java.util.*;
import uk.me.bstephen.Chess.*;

public class InsertProblem extends JDialog {
    private static final String[] stips = { "#2", "#3", "#4", "#5", "#6", "H#2", "H#3", "H#4", "H#5", "H#6", "S#2", "S#3", "S#4", "S#5", "S#6", "R#2", "R#3" };
    private static final String[] days = { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10",
                                           "11", "12", "13", "14", "15", "16", "17", "18", "19", "20",
                                           "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"
                                         };

    private static final String[] months = {	"Jan", "Feb", "Mar", "Apr", "May", "Jun",
                                                "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
                                           };

    private static final String awardSQL = "SELECT aid, name FROM award ORDER BY name";
    private static final String sourceSQL = "SELECT sid, name FROM source ORDER BY name";
    private static final String composerSQL = "SELECT cid, name FROM composer ORDER BY name";
    private static final String sqNames =	"a8b8c8d8e8f8g8h8" +
                                            "a7b7c7d7e7f7g7h7" +
                                            "a6b6c6d6e6f6g6h6" +
                                            "a5b5c5d5e5f5g5h5" +
                                            "a4b4c4d4e4f4g4h4" +
                                            "a3b3c3d3e3f3g3h3" +
                                            "a2b2c2d2e2f2g2h2" +
                                            "a1b1c1d1e1f1g1h1" ;

    private static final String colours =	"wdwdwdwddwdwdwdw" +
                                            "wdwdwdwddwdwdwdw" +
                                            "wdwdwdwddwdwdwdw" +
                                            "wdwdwdwddwdwdwdw";

    private Point p;
    private Font boldArial14;
    private Font LinaresDiagram33;
    private GridBagConstraints gbc;
    private Container cPane;
    private JComboBox stip;
    private JComboBox dayCombo;
    private JComboBox monthCombo;
    private JTextField yearText;
    private JComboBox award;
    private JComboBox source;
    private JComboBox quote;
    private DisplaySquare[] sqs;
    private JTextField origID;
    private JTextField years;
    private JTextField qYears;
    private DefaultListModel listModel;
    private CurrentPiece cp;

    private String chosenVersion;

    private Vector awardIDs;
    private Vector awardNames;

    private Vector sourceIDs;
    //private Vector sourceNames;
    private DefaultComboBoxModel sourceNames;
    private DefaultComboBoxModel quoteNames;

    private Vector compIDs;
    private Vector compNames;

    private JComboBox composer;

    public InsertProblem(Meson inParent) {
        super(inParent, "Insert Problem", true);
        p = inParent.getLocationOnScreen();

        this.setBounds(p.x + 20, p.y + 60, 960, 630);
        cPane = this.getContentPane();
        cPane.setLayout(new GridBagLayout());
        this.setResizable(false);

        boldArial14 = new Font("Arial", Font.BOLD, 14);
        LinaresDiagram33 = new Font("LinaresDiagram", Font.PLAIN, 33);

        cp = new CurrentPiece();

        gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.NONE;
        gbc.weightx = 0;
        gbc.weighty = 0;
        gbc.ipadx = 0;
        gbc.ipady = 0;
        gbc.insets = new Insets(4, 4, 4, 4);

        BOARD_AND_PIECES: {
            this.DisplayBoardAndPieces(cPane);
        }

        STIPULATION: {
            this.DisplayStipulation(cPane);
        }

        COMPOSERS: {
            this.DisplayComposers(cPane);
        }

        VERSIONING: {
            this.DisplayVersioning(cPane);
        }

        AWARD_SOURCE_AND_YEARS: {
            this.DisplayAwardSourceAndYears(cPane);
        }

        QUOTATION_AND_YEARS: {
            this.DisplayQuotationAndYears(cPane);
        }

        BUTTONS: {
            this.DisplayButtons(cPane);
        }

        this.pack();
        this.setVisible(true);
        //composer.showPopup();
    }

    private void DisplayBoardAndPieces(Container parent) {
        BOARD: {
            int i;
            int j;
            JPanel board = new JPanel(new GridLayout(8, 8, 0, 0));
            board.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED));

            sqs = new DisplaySquare[64];

            for (i = 0; i < 64; i++) {
                j = (i * 2);
                sqs[i] = new DisplaySquare(colours.substring(i, i + 1), sqNames.substring(j, j + 2), cp);
                board.add(sqs[i]);
            }

            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.gridheight = 4;
            gbc.gridwidth = 1;
            gbc.anchor = GridBagConstraints.FIRST_LINE_START;

            parent.add(board, gbc);
        }

        PIECES: {
            JPanel pieces = new JPanel(new GridLayout(6, 2, 5, 5));
            pieces.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED));
            JButton wKing = new JButton("K");
            wKing.setFont(LinaresDiagram33);

            wKing.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    cp.setPiece("K");
                }
            }
            );

            JButton bKing = new JButton("k");
            bKing.setFont(LinaresDiagram33);

            bKing.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    cp.setPiece("k");
                }
            }
            );

            JButton wQueen = new JButton("Q");
            wQueen.setFont(LinaresDiagram33);

            wQueen.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    cp.setPiece("Q");
                }
            }
            );

            JButton bQueen = new JButton("q");
            bQueen.setFont(LinaresDiagram33);

            bQueen.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    cp.setPiece("q");
                }
            }
            );

            JButton wRook = new JButton("R");
            wRook.setFont(LinaresDiagram33);

            wRook.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    cp.setPiece("R");
                }
            }
            );

            JButton bRook = new JButton("r");
            bRook.setFont(LinaresDiagram33);

            bRook.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    cp.setPiece("r");
                }
            }
            );

            JButton wBishop = new JButton("B");
            wBishop.setFont(LinaresDiagram33);

            wBishop.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    cp.setPiece("B");
                }
            }
            );

            JButton bBishop = new JButton("b");
            bBishop.setFont(LinaresDiagram33);

            bBishop.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    cp.setPiece("b");
                }
            }
            );

            JButton wKnight = new JButton("N");
            wKnight.setFont(LinaresDiagram33);

            wKnight.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    cp.setPiece("N");
                }
            }
            );

            JButton bKnight = new JButton("n");
            bKnight.setFont(LinaresDiagram33);

            bKnight.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    cp.setPiece("n");
                }
            }
            );

            JButton wPawn = new JButton("P");
            wPawn.setFont(LinaresDiagram33);

            wPawn.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    cp.setPiece("P");
                }
            }
            );

            JButton bPawn = new JButton("p");
            bPawn.setFont(LinaresDiagram33);

            bPawn.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    cp.setPiece("p");
                }
            }
            );

            pieces.add(wKing);
            pieces.add(bKing);
            pieces.add(wQueen);
            pieces.add(bQueen);
            pieces.add(wRook);
            pieces.add(bRook);
            pieces.add(wBishop);
            pieces.add(bBishop);
            pieces.add(wKnight);
            pieces.add(bKnight);
            pieces.add(wPawn);
            pieces.add(bPawn);

            gbc.gridx = 1;
            gbc.gridy = 0;
            gbc.gridheight = 4;
            gbc.gridwidth = 1;
            gbc.anchor = GridBagConstraints.FIRST_LINE_START;

            parent.add(pieces, gbc);
        }
    }

    private void DisplayVersioning(Container parent) {
        Box versionBox = new Box(BoxLayout.PAGE_AXIS);
        Box buttonBox = new Box(BoxLayout.PAGE_AXIS);
        buttonBox.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED));
        versionBox.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED));

        ButtonGroup vGroup = new ButtonGroup();
        JRadioButton noneB = new JRadioButton("None");
        noneB.setSelected(true);
        chosenVersion = "none";

        noneB.addActionListener
        (
        new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                chosenVersion = "none";
                origID.setEnabled(false);
            }
        }
        );

        JRadioButton versionB = new JRadioButton("Version");

        versionB.addActionListener
        (
        new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                chosenVersion = "version";
                origID.setEnabled(true);
            }
        }
        );
        JRadioButton afterB = new JRadioButton("After");

        afterB.addActionListener
        (
        new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                chosenVersion = "after";
                origID.setEnabled(true);
            }
        }
        );

        vGroup.add(noneB);
        vGroup.add(versionB);
        vGroup.add(afterB);
        buttonBox.add(noneB);
        buttonBox.add(versionB);
        buttonBox.add(afterB);
        versionBox.add(Box.createRigidArea(new Dimension(0, 5)));
        versionBox.add(buttonBox);
        versionBox.add(Box.createRigidArea(new Dimension(0, 5)));

        origID = new JTextField();
        origID.setEnabled(false);
        origID.setFont(boldArial14);

        versionBox.add(origID);
        versionBox.add(Box.createRigidArea(new Dimension(0, 5)));

        gbc.gridx = 2;
        gbc.gridy = 5;
        gbc.gridheight = 2;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.FIRST_LINE_START;

        parent.add(versionBox, gbc);
    }

    private void DisplayStipulation(Container parent) {
        stip = new JComboBox(stips);
        stip.setFont(boldArial14);

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridheight = 1;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.FIRST_LINE_START;

        parent.add(stip, gbc);
    }

    private void DisplayComposers(Container parent) {
        Box compBox = new Box(BoxLayout.PAGE_AXIS);
        JLabel compLab = new JLabel("Composer(s)");
        compLab.setAlignmentX(Component.LEFT_ALIGNMENT);
        compIDs = new Vector(6000);
        compNames = new Vector(6000);

        Connection conn;
        Statement stmt;
        ResultSet rs;

        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/meson", "bstephen", "rice37");

            stmt = conn.createStatement();
            rs = stmt.executeQuery(composerSQL);

            while (rs.next()) {
                compIDs.addElement(new Long((long) rs.getInt("cid")));
                compNames.addElement(rs.getString("name"));
            }

            rs.close();
            stmt.close();
            conn.close();

            composer = new JComboBox(compNames);
            composer.setAlignmentX(Component.LEFT_ALIGNMENT);
            composer.setFont(boldArial14);
            composer.setKeySelectionManager(new MultiKeySelection());

            gbc.gridx = 0;
            gbc.gridy = 5;
            gbc.gridheight = 1;
            gbc.gridwidth = 1;
            gbc.anchor = GridBagConstraints.FIRST_LINE_START;

            compBox.add(compLab);
            compBox.add(composer);
            JLabel origDateLab = new JLabel("Date of publication");
            origDateLab.setAlignmentX(Component.LEFT_ALIGNMENT);
            compBox.add(Box.createRigidArea(new Dimension(0, 10)));
            compBox.add(origDateLab);

            Box dateBox = new Box(BoxLayout.LINE_AXIS);
            dayCombo = new JComboBox(days);
            dayCombo.setFont(boldArial14);
            dayCombo.setSelectedIndex(-1);
            monthCombo = new JComboBox(months);
            monthCombo.setFont(boldArial14);
            monthCombo.setSelectedIndex(-1);
            yearText = new JTextField(4);
            yearText.setFont(boldArial14);
            dateBox.add(dayCombo);
            dateBox.add(Box.createRigidArea(new Dimension(5, 0)));
            dateBox.add(monthCombo);
            dateBox.add(Box.createRigidArea(new Dimension(5, 0)));
            dateBox.add(yearText);
            dateBox.add(Box.createRigidArea(new Dimension(250, 0)));
            dateBox.setAlignmentX(Component.LEFT_ALIGNMENT);

            compBox.add(dateBox);

            parent.add(compBox, gbc);

            Box addedBox = new Box(BoxLayout.LINE_AXIS);
            JButton arrow = new JButton(">>>");
            arrow.setFont(boldArial14);

            arrow.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    String item = (String) composer.getSelectedItem();

                    if (item != null) {
                        listModel.addElement(item);
                    }
                }
            }
            );

            listModel = new DefaultListModel();
            final JList comps = new JList(listModel);
            comps.setFont(boldArial14);

            comps.addKeyListener
            (
            new KeyListener() {
                public void keyReleased(KeyEvent ke) {
                    if (ke.getKeyCode() == KeyEvent.VK_DELETE) {
                        int index = comps.getSelectedIndex();
                        listModel.remove(index);
                    }
                }

                public void keyTyped(KeyEvent ke) {
                }

                public void keyPressed(KeyEvent ke) {
                }
            }
            );

            JScrollPane jsp = new JScrollPane(comps);

            addedBox.add(arrow);
            addedBox.add(Box.createRigidArea(new Dimension(5, 0)));
            addedBox.add(jsp);

            gbc.gridx = 1;
            gbc.gridy = 5;
            gbc.gridheight = 2;
            gbc.gridwidth = 1;
            gbc.anchor = GridBagConstraints.FIRST_LINE_START;

            parent.add(addedBox, gbc);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    private void DisplayAwardSourceAndYears(Container parent) {
        Box awardBox = new Box(BoxLayout.PAGE_AXIS);
        Box sourceBox = new Box(BoxLayout.PAGE_AXIS);
        Box yearsBox = new Box(BoxLayout.PAGE_AXIS);

        awardIDs = new Vector(300);
        awardNames = new Vector(300);

        sourceIDs = new Vector(6000);
        //sourceNames = new Vector(6000);
        sourceNames = new DefaultComboBoxModel();
        quoteNames = new DefaultComboBoxModel();

        Connection conn;
        Statement stmt;
        ResultSet rs;

        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/meson", "bstephen", "rice37");

            //	Award

            stmt = conn.createStatement();
            rs = stmt.executeQuery(awardSQL);

            while (rs.next()) {
                awardIDs.addElement(new Long((long) rs.getInt("aid")));
                awardNames.addElement(rs.getString("name"));
            }

            rs.close();
            stmt.close();

            award = new JComboBox(awardNames);
            award.setSelectedIndex(-1);
            award.setFont(boldArial14);
            award.setKeySelectionManager(new MultiKeySelection());

            gbc.gridx = 0;
            gbc.gridy = 7;
            gbc.gridheight = 1;
            gbc.gridwidth = 1;
            gbc.anchor = GridBagConstraints.FIRST_LINE_START;

            JLabel awardLab = new JLabel("Award");
            awardLab.setAlignmentX(Component.LEFT_ALIGNMENT);
            award.setAlignmentX(Component.LEFT_ALIGNMENT);
            awardBox.add(awardLab);
            awardBox.add(award);

            parent.add(awardBox, gbc);

            // Source

            stmt = conn.createStatement();
            rs = stmt.executeQuery(sourceSQL);

            while (rs.next()) {
                sourceIDs.addElement(new Long((long) rs.getInt("sid")));
                sourceNames.addElement(rs.getString("name"));
                quoteNames.addElement(rs.getString("name"));
            }

            rs.close();
            stmt.close();
            conn.close();

            source = new JComboBox(sourceNames);
            source.setFont(boldArial14);
            source.setKeySelectionManager(new MultiKeySelection());
            source.setPreferredSize(new Dimension(350, 22));

            gbc.gridx = 1;
            gbc.gridy = 7;
            gbc.gridheight = 1;
            gbc.gridwidth = 1;
            gbc.anchor = GridBagConstraints.FIRST_LINE_START;

            JLabel sourceLab = new JLabel("Source");
            sourceLab.setAlignmentX(Component.LEFT_ALIGNMENT);
            source.setAlignmentX(Component.LEFT_ALIGNMENT);
            sourceBox.add(sourceLab);
            sourceBox.add(source);
            parent.add(sourceBox, gbc);

            // Source Years

            JLabel yearLab = new JLabel("Years");
            years = new JTextField(9);
            years.setFont(boldArial14);

            yearLab.setAlignmentX(Component.LEFT_ALIGNMENT);
            years.setAlignmentX(Component.LEFT_ALIGNMENT);
            yearsBox.add(yearLab);
            yearsBox.add(years);

            gbc.gridx = 2;
            gbc.gridy = 7;
            gbc.gridheight = 1;
            gbc.gridwidth = 1;
            gbc.anchor = GridBagConstraints.FIRST_LINE_START;

            parent.add(yearsBox, gbc);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    private void DisplayQuotationAndYears(Container parent) {
        Box quoteBox = new Box(BoxLayout.PAGE_AXIS);
        Box quoteYearBox = new Box(BoxLayout.PAGE_AXIS);

        JLabel quoteLab = new JLabel("Quoted in");
        quoteLab.setAlignmentX(Component.LEFT_ALIGNMENT);
        quote = new JComboBox(quoteNames);
        quote.setPreferredSize(new Dimension(350, 22));
        quote.setAlignmentX(Component.LEFT_ALIGNMENT);
        quote.setFont(boldArial14);
        quote.setKeySelectionManager(new MultiKeySelection());
        quote.setSelectedIndex(-1);
        quoteBox.add(quoteLab);
        quoteBox.add(quote);

        gbc.gridx = 0;
        gbc.gridy = 8;
        gbc.gridheight = 1;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.FIRST_LINE_START;

        parent.add(quoteBox, gbc);

        JLabel yearsLab = new JLabel("Years");
        yearsLab.setAlignmentX(Component.LEFT_ALIGNMENT);
        qYears = new JTextField(9);
        qYears.setAlignmentX(Component.LEFT_ALIGNMENT);
        qYears.setFont(boldArial14);
        quoteYearBox.add(yearsLab);
        quoteYearBox.add(qYears);

        gbc.gridx = 1;
        gbc.gridy = 8;
        gbc.gridheight = 1;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.FIRST_LINE_START;

        parent.add(quoteYearBox, gbc);
    }

    private void DisplayButtons(Container parent) {
        Box buttons = new Box(BoxLayout.X_AXIS);

        JButton cancelButton = new JButton("Cancel");
        cancelButton.setFont(boldArial14);

        cancelButton.addActionListener
        (
        new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                InsertProblem.this.setVisible(false);
                InsertProblem.this.dispose();
            }
        }
        );

        JButton addButton = new JButton("Add");
        addButton.setFont(boldArial14);

        addButton.addActionListener
        (
        new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                int i;
                String temp;
                ProblemAdder pa = new ProblemAdder();

                KINGS_GBR_POSITION: {
                    String kings;
                    String wk = null;
                    String bk = null;
                    StringBuffer gbr;
                    StringBuffer position;
                    StringBuffer wQueens = new StringBuffer();
                    StringBuffer bQueens = new StringBuffer();
                    StringBuffer wRooks = new StringBuffer();
                    StringBuffer bRooks = new StringBuffer();
                    StringBuffer wBishops = new StringBuffer();
                    StringBuffer bBishops = new StringBuffer();
                    StringBuffer wKnights = new StringBuffer();
                    StringBuffer bKnights = new StringBuffer();
                    StringBuffer wPawns = new StringBuffer();
                    StringBuffer bPawns = new StringBuffer();

                    int qCount = 0;
                    int rCount = 0;
                    int bCount = 0;
                    int sCount = 0;
                    int wpCount = 0;
                    int bpCount = 0;

                    for (i = 0; i < 64; i++) {
                        char ch = sqs[i].getText().charAt(0);

                        if ((ch != 'w') && (ch != 'd')) {
                            switch (ch) {
                            case 'K'	:
                            case 'I'	:
                                wk = sqs[i].getSquare();
                                break;

                            case 'k'	:
                            case 'i'	:
                                bk = sqs[i].getSquare();
                                break;

                            case 'Q'	:
                            case '!'	:
                                qCount++;
                                wQueens.append(sqs[i].getSquare());
                                break;

                            case 'q'	:
                            case '1'	:
                                qCount += 3;
                                bQueens.append(sqs[i].getSquare());
                                break;

                            case 'R'	:
                            case '$'	:
                                rCount++;
                                wRooks.append(sqs[i].getSquare());
                                break;

                            case 'r'	:
                            case '4'	:
                                rCount += 3;
                                bRooks.append(sqs[i].getSquare());
                                break;

                            case 'B'	:
                            case 'G'	:
                                bCount++;
                                wBishops.append(sqs[i].getSquare());
                                break;

                            case 'b'	:
                            case 'g'	:
                                bCount += 3;
                                bBishops.append(sqs[i].getSquare());
                                break;

                            case 'N'	:
                            case 'H'	:
                                sCount++;
                                wKnights.append(sqs[i].getSquare());
                                break;

                            case 'n'	:
                            case 'h'	:
                                sCount += 3;
                                bKnights.append(sqs[i].getSquare());
                                break;

                            case 'P'	:
                            case ')'	:
                                wpCount++;
                                wPawns.append(sqs[i].getSquare());
                                break;

                            case 'p'	:
                            case '0'	:
                                bpCount++;
                                bPawns.append(sqs[i].getSquare());
                                break;

                            default	:
                                System.exit(1);
                            }
                        }
                    }

                    kings = new String(wk + bk);
                    pa.setKings(kings);
                    position = new StringBuffer();
                    position.append(wQueens);
                    position.append(bQueens);
                    position.append(wRooks);
                    position.append(bRooks);
                    position.append(wBishops);
                    position.append(bBishops);
                    position.append(wKnights);
                    position.append(bKnights);
                    position.append(wPawns);
                    position.append(bPawns);

                    pa.setPosition(position.toString());

                    gbr = new StringBuffer();
                    gbr.append(Integer.toString(qCount));
                    gbr.append(Integer.toString(rCount));
                    gbr.append(Integer.toString(bCount));
                    gbr.append(Integer.toString(sCount));
                    gbr.append('.');
                    gbr.append(Integer.toString(wpCount));
                    gbr.append(Integer.toString(bpCount));
                    pa.setGbr(gbr.toString());
                }

                STIPULATION: {
                    pa.setStip((String) stip.getSelectedItem());
                }

                COMPOSERS: {
                    ArrayList comps = new ArrayList(10);
                    int j;

                    for (i = 0; i < listModel.getSize(); i++) {
                        temp = (String) listModel.get(i);
                        j = compNames.indexOf(temp);

                        if (j != -1) {
                            comps.add(compIDs.get(j));
                        } else {
                            System.exit(1);
                        }

                        pa.setCids(comps);
                    }
                }

                DATE_OF_PUBLICATION: {
                    Calendar cal = Calendar.getInstance();

                    if (	(yearText.getText().length() != 0) &&
                            (monthCombo.getSelectedIndex() != -1) &&
                            (dayCombo.getSelectedIndex() != -1)) {
                        cal.set(	Integer.parseInt(yearText.getText()),
                                    monthCombo.getSelectedIndex(),
                                    Integer.parseInt((String) dayCombo.getSelectedItem()));

                        java.sql.Date tempDate = new java.sql.Date(cal.getTime().getTime());
                        pa.setDate(tempDate);
                    } else {
                        pa.setDate(null);
                    }
                }

                VERSIONING_AND_ORIGINAL_PID: {
                    String tempOrig;

                    pa.setVersion(chosenVersion);

                    tempOrig = origID.getText();

                    if ((origID.isEnabled() == true) && (tempOrig.length() != 0)) {
                        pa.setEid(Long.decode(tempOrig));
                    } else {
                        pa.setEid(new Long(0L));
                    }
                }

                AWARD: {
                    int j = award.getSelectedIndex();

                    if (j != -1) {
                        pa.setAid((Long) awardIDs.get(j));
                    } else {
                        j = awardNames.indexOf("None");
                        pa.setAid((Long) awardIDs.get(j));
                    }
                }

                SOURCE: {
                    String src = (String) source.getSelectedItem();
                    int j = sourceNames.getIndexOf(src);
                    pa.setSid((Long) sourceIDs.get(j));
                }

                SOURCE_YEARS: {
                    String tempYears = years.getText();

                    if (tempYears.length() != 0) {
                        pa.setYears(tempYears);
                    } else {
                        pa.setYears("0000");
                    }
                }

                QUOTED_SOURCE: {
                    int j = quote.getSelectedIndex();

                    if (j != -1) {
                        pa.setProblemSid((Long) sourceIDs.get(j));
                    } else {
                        pa.setProblemSid(null);
                    }
                }

                QUOTED_YEARS: {
                    String tYears = qYears.getText();

                    if (tYears.length() != 0) {
                        pa.setSourceYears(tYears);
                    } else {
                        pa.setSourceYears("0000");
                    }
                }

                pa.addProblem();
                InsertProblem.this.setVisible(false);
                InsertProblem.this.dispose();
            }
        }
        );

        buttons.add(cancelButton);
        buttons.add(addButton);

        gbc.gridx = 2;
        gbc.gridy = 8;
        gbc.gridheight = 1;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.LAST_LINE_END;

        parent.add(buttons, gbc);
    }
}