package uk.me.bstephen.Meson;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import java.sql.*;
import java.text.*;

public class CountProblemsQueryResult extends QueryResult {
    private int totalProbs;

    public CountProblemsQueryResult(Meson inParent, ResultSet rs, String title) {
        super(inParent, rs, title);
        totalProbs = 0;
    }

    public void paintResult() {
        try {
            rs.next();
            totalProbs = rs.getInt("total");
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }

        JTextField totalField = new JTextField(10);
        totalField.setFont(boldArial14);
        totalField.setEditable(false);

        NumberFormat nf = NumberFormat.getIntegerInstance();
        nf.setMinimumIntegerDigits(1);
        nf.setGroupingUsed(true);

        totalField.setText(nf.format(totalProbs));

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.gridheight = 5;
        gbc.anchor = GridBagConstraints.CENTER;

        cPane.add(totalField, gbc);
    }
}