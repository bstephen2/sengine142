package uk.me.bstephen.Meson;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;

public class FeatureFilterDialog extends JDialog {
    private Font boldArial14;
    private Point p;
    private GridBagConstraints gbc;

    private static	String[] relations = { "=", "<", ">", "<=", ">=" , "!=" };
    private static	String[] totNumbers = { "N/A", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16",
                                            "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29",
                                            "30", "31", "32"
                                         };

    private static	String[] sideNumbers = {"N/A", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16" };

    private static	String[] flights = { "N/A", "0", "1", "2", "3", "4", "5", "6" };

    private static String[] phases = { "Any", "Set", "Virtual", "Actual" };

    private final ProblemTableModel model;
    private final Meson parent;

    private final JComboBox phase1 = new JComboBox(phases);
    private final JTextField pattern1 = new JTextField(30);
    private final JComboBox phase2 = new JComboBox(phases);
    private final JTextField pattern2 = new JTextField(30);
    private final JComboBox phase3 = new JComboBox(phases);
    private final JTextField pattern3 = new JTextField(30);

    private ButtonGroup selection;

    private final JCheckBox unsoundCheck = new JCheckBox("Unsound");

    private ButtonGroup type;
    private final JRadioButton threat = new JRadioButton("Threat");
    private final JRadioButton completeBlock = new JRadioButton("Complete Block");
    private final JRadioButton incompleteBlock = new JRadioButton("Incomplete Block");
    private final JRadioButton checkingKey = new JRadioButton("Checking Key");
    private final JRadioButton anyType = new JRadioButton("Any type");

    private ButtonGroup size;
    private final JRadioButton miniature = new JRadioButton("Miniature");
    private final JRadioButton meredith = new JRadioButton("Meredith");
    private final JRadioButton heavy = new JRadioButton("Heavy");
    private final JRadioButton anySize = new JRadioButton("Any size");

    private final JCheckBox blockThreatCheck = new JCheckBox("Block-threat");
    private final JCheckBox mutateCheck = new JCheckBox("Mutate");

    private final JComboBox wRel	= new JComboBox(relations);
    private final JComboBox bRel	= new JComboBox(relations);
    private final JComboBox tRel = new JComboBox(relations);
    private final JComboBox sRel = new JComboBox(relations);
    private final JComboBox uRel = new JComboBox(relations);

    private final JComboBox wNum = new JComboBox(sideNumbers);
    private final JComboBox bNum	= new JComboBox(sideNumbers);
    private final JComboBox tNum = new JComboBox(totNumbers);
    private final JComboBox sNum = new JComboBox(totNumbers);
    private final JComboBox uNum = new JComboBox(flights);

    public FeatureFilterDialog(Meson inParent, ProblemTableModel inModel) {
        super(inParent, "#2 Feature Filter", true);
        parent = inParent;
        p = inParent.getLocationOnScreen();
        model = inModel;

        this.setBounds(p.x + 20, p.y + 60, 200, 400);
        Container cPane = this.getContentPane();
        cPane.setLayout(new GridBagLayout());
        this.setResizable(false);

        boldArial14 = new Font("Arial", Font.BOLD, 14);

        gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.NONE;
        gbc.weightx = 0;
        gbc.weighty = 0;
        gbc.ipadx = 0;
        gbc.ipady = 0;
        gbc.insets = new Insets(4, 4, 4, 4);

        MAIN_PANEL: {

            JPanel mainPanel = new JPanel();
            mainPanel.setLayout(new GridBagLayout());

            JLabel white;
            JLabel black;
            JLabel total;
            JLabel set;
            JLabel unprovidedFlights;


            GridBagConstraints mpgbc = new GridBagConstraints();
            mpgbc.fill = GridBagConstraints.NONE;
            mpgbc.weightx = 0;
            mpgbc.weighty = 0;
            mpgbc.ipadx = 0;
            mpgbc.ipady = 0;
            mpgbc.insets = new Insets(4, 4, 4, 4);

            UNSOUND: {
                unsoundCheck.setSelected(false);
                unsoundCheck.setFont(boldArial14);

                unsoundCheck.addItemListener
                (
                new ItemListener() {
                    public void itemStateChanged(ItemEvent ie) {
                        if (ie.getStateChange() == ItemEvent.DESELECTED) {
                            wRel.setEnabled(true);
                            bRel.setEnabled(true);
                            tRel.setEnabled(true);
                            sRel.setEnabled(true);
                            uRel.setEnabled(true);
                            wNum.setEnabled(true);
                            bNum.setEnabled(true);
                            tNum.setEnabled(true);
                            sNum.setEnabled(true);
                            uNum.setEnabled(true);
                            miniature.setEnabled(true);
                            meredith.setEnabled(true);
                            heavy.setEnabled(true);
                            anySize.setEnabled(true);
                            threat.setEnabled(true);
                            completeBlock.setEnabled(true);
                            incompleteBlock.setEnabled(true);
                            checkingKey.setEnabled(true);
                            anyType.setEnabled(true);
                            phase1.setEnabled(true);
                            phase2.setEnabled(true);
                            phase3.setEnabled(true);
                            pattern1.setEnabled(true);
                            pattern2.setEnabled(true);
                            pattern3.setEnabled(true);

                            if (completeBlock.isSelected() == true) {
                                mutateCheck.setEnabled(true);
                            }

                            if (threat.isSelected() == true) {
                                blockThreatCheck.setEnabled(true);
                            }
                        } else {
                            wRel.setEnabled(false);
                            bRel.setEnabled(false);
                            tRel.setEnabled(false);
                            sRel.setEnabled(false);
                            uRel.setEnabled(false);
                            wNum.setEnabled(false);
                            bNum.setEnabled(false);
                            tNum.setEnabled(false);
                            sNum.setEnabled(false);
                            uNum.setEnabled(false);
                            miniature.setEnabled(false);
                            meredith.setEnabled(false);
                            heavy.setEnabled(false);
                            anySize.setEnabled(false);
                            threat.setEnabled(false);
                            completeBlock.setEnabled(false);
                            incompleteBlock.setEnabled(false);
                            checkingKey.setEnabled(false);
                            anyType.setEnabled(false);
                            phase1.setEnabled(false);
                            phase2.setEnabled(false);
                            phase3.setEnabled(false);
                            pattern1.setEnabled(false);
                            pattern2.setEnabled(false);
                            pattern3.setEnabled(false);
                            mutateCheck.setEnabled(false);
                            blockThreatCheck.setEnabled(false);
                        }
                    }
                }
                );

                mpgbc.gridx = 0;
                mpgbc.gridy = 2;
                mpgbc.gridwidth = 1;
                mpgbc.gridheight = 1;
                mpgbc.anchor = GridBagConstraints.LAST_LINE_START;

                mainPanel.add(unsoundCheck, mpgbc);
            }

            PATTERN1: {
                phase1.setFont(boldArial14);

                mpgbc.gridx = 4;
                mpgbc.gridy = 2;
                mpgbc.gridwidth = 1;
                mpgbc.gridheight = 1;
                mpgbc.anchor = GridBagConstraints.LAST_LINE_START;

                mainPanel.add(phase1, mpgbc);

                pattern1.setFont(boldArial14);

                mpgbc.gridx = 5;
                mpgbc.gridy = 2;
                mpgbc.gridwidth = 1;
                mpgbc.gridheight = 1;
                mpgbc.anchor = GridBagConstraints.LAST_LINE_START;

                mainPanel.add(pattern1, mpgbc);
            }

            PATTERN2: {
                phase2.setFont(boldArial14);

                mpgbc.gridx = 4;
                mpgbc.gridy = 3;
                mpgbc.gridwidth = 1;
                mpgbc.gridheight = 1;
                mpgbc.anchor = GridBagConstraints.LAST_LINE_START;

                mainPanel.add(phase2, mpgbc);

                pattern2.setFont(boldArial14);

                mpgbc.gridx = 5;
                mpgbc.gridy = 3;
                mpgbc.gridwidth = 1;
                mpgbc.gridheight = 1;
                mpgbc.anchor = GridBagConstraints.LAST_LINE_START;

                mainPanel.add(pattern2, mpgbc);
            }

            PATTERN3: {
                phase3.setFont(boldArial14);

                mpgbc.gridx = 4;
                mpgbc.gridy = 4;
                mpgbc.gridwidth = 1;
                mpgbc.gridheight = 1;
                mpgbc.anchor = GridBagConstraints.LAST_LINE_START;

                mainPanel.add(phase3, mpgbc);

                pattern3.setFont(boldArial14);

                mpgbc.gridx = 5;
                mpgbc.gridy = 4;
                mpgbc.gridwidth = 1;
                mpgbc.gridheight = 1;
                mpgbc.anchor = GridBagConstraints.LAST_LINE_START;

                mainPanel.add(pattern3, mpgbc);
            }

            WHITE: {
                white = new JLabel("White");
                white.setFont(boldArial14);

                mpgbc.gridx = 0;
                mpgbc.gridy = 3;
                mpgbc.gridwidth = 1;
                mpgbc.gridheight = 1;
                mpgbc.anchor = GridBagConstraints.LAST_LINE_END;

                mainPanel.add(white, mpgbc);

                wRel.setFont(boldArial14);

                mpgbc.gridx = 1;
                mpgbc.gridy = 3;
                mpgbc.gridwidth = 1;
                mpgbc.gridheight = 1;
                mpgbc.anchor = GridBagConstraints.LAST_LINE_END;

                mainPanel.add(wRel, mpgbc);

                wNum.setFont(boldArial14);

                mpgbc.gridx = 2;
                mpgbc.gridy = 3;
                mpgbc.gridwidth = 1;
                mpgbc.gridheight = 1;
                mpgbc.anchor = GridBagConstraints.LAST_LINE_END;

                mainPanel.add(wNum, mpgbc);
            }

            BLACK: {
                black = new JLabel("Black");
                black.setFont(boldArial14);

                mpgbc.gridx = 0;
                mpgbc.gridy = 4;
                mpgbc.gridwidth = 1;
                mpgbc.gridheight = 1;
                mpgbc.anchor = GridBagConstraints.LAST_LINE_END;

                mainPanel.add(black, mpgbc);

                bRel.setFont(boldArial14);

                mpgbc.gridx = 1;
                mpgbc.gridy = 4;
                mpgbc.gridwidth = 1;
                mpgbc.gridheight = 1;
                mpgbc.anchor = GridBagConstraints.LAST_LINE_END;

                mainPanel.add(bRel, mpgbc);

                bNum.setFont(boldArial14);

                mpgbc.gridx = 2;
                mpgbc.gridy = 4;
                mpgbc.gridwidth = 1;
                mpgbc.gridheight = 1;
                mpgbc.anchor = GridBagConstraints.LAST_LINE_END;

                mainPanel.add(bNum, mpgbc);
            }

            TOTAL: {
                total = new JLabel("Total");
                total.setFont(boldArial14);

                mpgbc.gridx = 0;
                mpgbc.gridy = 5;
                mpgbc.gridwidth = 1;
                mpgbc.gridheight = 1;
                mpgbc.anchor = GridBagConstraints.LAST_LINE_END;

                mainPanel.add(total, mpgbc);

                tRel.setFont(boldArial14);

                mpgbc.gridx = 1;
                mpgbc.gridy = 5;
                mpgbc.gridwidth = 1;
                mpgbc.gridheight = 1;
                mpgbc.anchor = GridBagConstraints.LAST_LINE_END;

                mainPanel.add(tRel, mpgbc);

                tNum.setFont(boldArial14);

                mpgbc.gridx = 2;
                mpgbc.gridy = 5;
                mpgbc.gridwidth = 1;
                mpgbc.gridheight = 1;
                mpgbc.anchor = GridBagConstraints.LAST_LINE_END;

                mainPanel.add(tNum, mpgbc);
            }

            SET: {
                set = new JLabel("Set");
                set.setFont(boldArial14);

                mpgbc.gridx = 0;
                mpgbc.gridy = 6;
                mpgbc.gridwidth = 1;
                mpgbc.gridheight = 1;
                mpgbc.anchor = GridBagConstraints.LAST_LINE_END;

                mainPanel.add(set, mpgbc);

                sRel.setFont(boldArial14);

                mpgbc.gridx = 1;
                mpgbc.gridy = 6;
                mpgbc.gridwidth = 1;
                mpgbc.gridheight = 1;
                mpgbc.anchor = GridBagConstraints.LAST_LINE_END;

                mainPanel.add(sRel, mpgbc);

                sNum.setFont(boldArial14);

                mpgbc.gridx = 2;
                mpgbc.gridy = 6;
                mpgbc.gridwidth = 1;
                mpgbc.gridheight = 1;
                mpgbc.anchor = GridBagConstraints.LAST_LINE_END;

                mainPanel.add(sNum, mpgbc);
            }

            UNPROVIDED_FLIGHTS: {
                unprovidedFlights = new JLabel("Unprovided flights");
                unprovidedFlights.setFont(boldArial14);

                mpgbc.gridx = 0;
                mpgbc.gridy = 7;
                mpgbc.gridwidth = 1;
                mpgbc.gridheight = 1;
                mpgbc.anchor = GridBagConstraints.LAST_LINE_END;

                mainPanel.add(unprovidedFlights, mpgbc);

                uRel.setFont(boldArial14);

                mpgbc.gridx = 1;
                mpgbc.gridy = 7;
                mpgbc.gridwidth = 1;
                mpgbc.gridheight = 1;
                mpgbc.anchor = GridBagConstraints.LAST_LINE_END;

                mainPanel.add(uRel, mpgbc);

                uNum.setFont(boldArial14);

                mpgbc.gridx = 2;
                mpgbc.gridy = 7;
                mpgbc.gridwidth = 1;
                mpgbc.gridheight = 1;
                mpgbc.anchor = GridBagConstraints.LAST_LINE_END;

                mainPanel.add(uNum, mpgbc);
            }

            TYPE: {
                type = new ButtonGroup();

                threat.setSelected(false);
                threat.setFont(boldArial14);

                threat.addActionListener
                (
                new ActionListener() {
                    public void actionPerformed(ActionEvent ae) {
                        if (threat.isSelected() == true) {
                            blockThreatCheck.setEnabled(true);
                            mutateCheck.setEnabled(false);
                        }
                    }
                }
                );

                completeBlock.setSelected(false);
                completeBlock.setFont(boldArial14);

                completeBlock.addActionListener
                (
                new ActionListener() {
                    public void actionPerformed(ActionEvent ae) {
                        if (completeBlock.isSelected() == true) {
                            mutateCheck.setEnabled(true);
                            blockThreatCheck.setEnabled(false);
                        }
                    }
                }
                );

                incompleteBlock.setSelected(false);
                incompleteBlock.setFont(boldArial14);

                incompleteBlock.addActionListener
                (
                new ActionListener() {
                    public void actionPerformed(ActionEvent ae) {
                        if (incompleteBlock.isSelected() == true) {
                            mutateCheck.setEnabled(false);
                            blockThreatCheck.setEnabled(false);
                        }
                    }
                }
                );

                checkingKey.setSelected(false);
                checkingKey.setFont(boldArial14);

                checkingKey.addActionListener
                (
                new ActionListener() {
                    public void actionPerformed(ActionEvent ae) {
                        if (checkingKey.isSelected() == true) {
                            mutateCheck.setEnabled(false);
                            blockThreatCheck.setEnabled(false);
                        }
                    }
                }
                );

                anyType.setSelected(true);
                anyType.setFont(boldArial14);

                anyType.addActionListener
                (
                new ActionListener() {
                    public void actionPerformed(ActionEvent ae) {
                        if (anyType.isSelected() == true) {
                            mutateCheck.setEnabled(false);
                            blockThreatCheck.setEnabled(false);
                        }
                    }
                }
                );

                mpgbc.gridx = 0;
                mpgbc.gridy = 8;
                mpgbc.gridwidth = 1;
                mpgbc.gridheight = 1;
                mpgbc.anchor = GridBagConstraints.LAST_LINE_START;

                mainPanel.add(threat, mpgbc);

                mpgbc.gridx = 0;
                mpgbc.gridy = 9;
                mpgbc.gridwidth = 1;
                mpgbc.gridheight = 1;
                mpgbc.anchor = GridBagConstraints.LAST_LINE_START;

                mainPanel.add(completeBlock, mpgbc);

                mpgbc.gridx = 0;
                mpgbc.gridy = 10;
                mpgbc.gridwidth = 1;
                mpgbc.gridheight = 1;
                mpgbc.anchor = GridBagConstraints.LAST_LINE_START;

                mainPanel.add(incompleteBlock, mpgbc);

                mpgbc.gridx = 0;
                mpgbc.gridy = 11;
                mpgbc.gridwidth = 1;
                mpgbc.gridheight = 1;
                mpgbc.anchor = GridBagConstraints.LAST_LINE_START;

                mainPanel.add(checkingKey, mpgbc);

                mpgbc.gridx = 0;
                mpgbc.gridy = 12;
                mpgbc.gridwidth = 1;
                mpgbc.gridheight = 1;
                mpgbc.anchor = GridBagConstraints.LAST_LINE_START;

                mainPanel.add(anyType, mpgbc);

                type.add(threat);
                type.add(completeBlock);
                type.add(incompleteBlock);
                type.add(checkingKey);
                type.add(anyType);
            }

            SIZE: {
                size = new ButtonGroup();

                miniature.setSelected(false);
                miniature.setFont(boldArial14);

                meredith.setSelected(false);
                meredith.setFont(boldArial14);

                heavy.setSelected(false);
                heavy.setFont(boldArial14);

                anySize.setSelected(true);
                anySize.setFont(boldArial14);

                mpgbc.gridx = 3;
                mpgbc.gridy = 2;
                mpgbc.gridwidth = 1;
                mpgbc.gridheight = 1;
                mpgbc.anchor = GridBagConstraints.LAST_LINE_START;

                mainPanel.add(miniature, mpgbc);

                mpgbc.gridx = 3;
                mpgbc.gridy = 3;
                mpgbc.gridwidth = 1;
                mpgbc.gridheight = 1;
                mpgbc.anchor = GridBagConstraints.LAST_LINE_START;

                mainPanel.add(meredith, mpgbc);

                mpgbc.gridx = 3;
                mpgbc.gridy = 4;
                mpgbc.gridwidth = 1;
                mpgbc.gridheight = 1;
                mpgbc.anchor = GridBagConstraints.LAST_LINE_START;

                mainPanel.add(heavy, mpgbc);

                mpgbc.gridx = 3;
                mpgbc.gridy = 5;
                mpgbc.gridwidth = 1;
                mpgbc.gridheight = 1;
                mpgbc.anchor = GridBagConstraints.LAST_LINE_START;

                mainPanel.add(anySize, mpgbc);

                size.add(miniature);
                size.add(meredith);
                size.add(heavy);
                size.add(anySize);
            }

            BLOCK_THREAT: {
                blockThreatCheck.setSelected(false);
                blockThreatCheck.setFont(boldArial14);
                blockThreatCheck.setEnabled(false);

                mpgbc.gridx = 3;
                mpgbc.gridy = 8;
                mpgbc.gridwidth = 1;
                mpgbc.gridheight = 1;
                mpgbc.anchor = GridBagConstraints.LAST_LINE_START;

                mainPanel.add(blockThreatCheck, mpgbc);
            }

            MUTATE: {
                mutateCheck.setSelected(false);
                mutateCheck.setFont(boldArial14);
                mutateCheck.setEnabled(false);

                mpgbc.gridx = 3;
                mpgbc.gridy = 9;
                mpgbc.gridwidth = 1;
                mpgbc.gridheight = 1;
                mpgbc.anchor = GridBagConstraints.LAST_LINE_START;

                mainPanel.add(mutateCheck, mpgbc);
            }

            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.gridwidth = 2;
            gbc.gridheight = 9;
            gbc.anchor = GridBagConstraints.FIRST_LINE_START;

            cPane.add(mainPanel, gbc);
        }

        BUTTONS: {
            JPanel buttons = new JPanel();
            buttons.setLayout(new FlowLayout(FlowLayout.RIGHT, 4, 4));

            JButton okButton = new JButton("OK");
            okButton.setFont(boldArial14);

            okButton.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    String cst;
                    StaticFeatureList sfl = new StaticFeatureList();

                    if (unsoundCheck.isSelected() == true) {
                        sfl.addFeature("UNSOUND");
                    }

                    if ((miniature.isEnabled() == true) && (miniature.isSelected() == true)) {
                        sfl.addFeature("MINIATURE");
                    }

                    if ((meredith.isEnabled() == true) && (meredith.isSelected() == true)) {
                        sfl.addFeature("MEREDITH");
                    }

                    if ((heavy.isEnabled() == true) && (heavy.isSelected() == true)) {
                        sfl.addFeature("HEAVY");
                    }

                    if ((threat.isEnabled() == true) && (threat.isSelected() == true)) {
                        sfl.addFeature("THREAT");
                    }

                    if ((completeBlock.isEnabled() == true) && (completeBlock.isSelected() == true)) {
                        sfl.addFeature("COMPLETE BLOCK");
                    }

                    if ((incompleteBlock.isEnabled() == true) && (incompleteBlock.isSelected() == true)) {
                        sfl.addFeature("INCOMPLETE BLOCK");
                    }

                    if ((checkingKey.isEnabled() == true) && (checkingKey.isSelected() == true)) {
                        sfl.addFeature("CHECKING KEY");
                    }

                    if ((blockThreatCheck.isEnabled() == true) && (blockThreatCheck.isSelected() == true)) {
                        sfl.addFeature("BLOCK-THREAT");
                    }

                    if ((mutateCheck.isEnabled() == true) && (mutateCheck.isSelected() == true)) {
                        sfl.addFeature("MUTATE");
                    }

                    if (wNum.isEnabled() == true) {
                        cst = (String) wNum.getSelectedItem();

                        if (cst.compareTo("N/A") != 0) {
                            sfl.addFeature("WHITE = " + cst);
                        }
                    }

                    if (bNum.isEnabled() == true) {
                        cst = (String) bNum.getSelectedItem();

                        if (cst.compareTo("N/A") != 0) {
                            sfl.addFeature("BLACK = " + cst);
                        }
                    }

                    if (tNum.isEnabled() == true) {
                        cst = (String) tNum.getSelectedItem();

                        if (cst.compareTo("N/A") != 0) {
                            sfl.addFeature("TOTAL = " + cst);
                        }
                    }

                    if (sNum.isEnabled() == true) {
                        cst = (String) sNum.getSelectedItem();

                        if (cst.compareTo("N/A") != 0) {
                            sfl.addFeature("SET = " + cst);
                        }
                    }

                    if (uNum.isEnabled() == true) {
                        cst = (String) uNum.getSelectedItem();

                        if (cst.compareTo("N/A") != 0) {
                            sfl.addFeature("UNPROVIDED_FLIGHTS(" + cst + ")");
                        }
                    }

                    if (pattern1.isEnabled() == true) {
                        String ph1;
                        String ph2;
                        String ph3;

                        String patt1 = pattern1.getText();
                        String patt2 = pattern2.getText();
                        String patt3 = pattern3.getText();

                        if (patt1.trim().length() > 0) {
                            sfl.addPattern((String) phase1.getSelectedItem(), patt1.trim());
                        }

                        if (patt2.trim().length() > 0) {
                            sfl.addPattern((String) phase2.getSelectedItem(), patt2.trim());
                        }

                        if (patt3.trim().length() > 0) {
                            sfl.addPattern((String) phase3.getSelectedItem(), patt3.trim());
                        }
                    }

                    FeatureFilterDialog.this.setVisible(false);
                    model.loadFeaturedTableData(parent, sfl);
                }
            }
            );

            JButton cancelButton = new JButton("Cancel");
            cancelButton.setFont(boldArial14);

            cancelButton.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    FeatureFilterDialog.this.setVisible(false);
                }
            }
            );

            buttons.add(okButton);
            buttons.add(cancelButton);

            gbc.gridx = 1;
            gbc.gridy = 9;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;
            gbc.anchor = GridBagConstraints.LAST_LINE_END;

            cPane.add(buttons, gbc);
        }

        this.pack();
        this.setVisible(true);
    }
}
