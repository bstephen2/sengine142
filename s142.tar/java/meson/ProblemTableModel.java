package uk.me.bstephen.Meson;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
import java.sql.*;
import java.util.*;
import java.io.*;

public class ProblemTableModel extends AbstractTableModel {
    private static final String selectSQL = new String("SELECT a.pid, a.years, a.kings, a.gbr, a.stip, c.name, b.name " +
            "FROM problem as a, source as b, award as c " +
            "WHERE (a.sid = b.sid) " +
            "AND (a.aid = c.aid) " +
            "ORDER BY a.years, a.kings, a.gbr " +
            "LIMIT 1000");

    ArrayList data;

    private Class[] columnClasses = new Class[] { String.class, String.class, String.class, String.class, String.class, String.class, String.class };
    private String[] columnNames = new String[] { "PID", "Years", "Kings", "GBR", "Stip.", "Award", "Source" };

    //private static String currentSQL;

    public Object getValueAt(int row, int col) {
        ProblemRow s = (ProblemRow) data.get(row);

        switch (col) {
        case 0	:
            return s.getPID();

        case 1	:
            return s.getYears();

        case 2	:
            return s.getKings();

        case 3	:
            return s.getGBR();

        case 4	:
            return s.getStip();

        case 5	:
            return s.getAward();

        case 6	:
            return s.getSource();

        default	:
            return null;
        }
    }

    public void loadFeaturedTableData(Meson inParent, StaticFeatureList inList) {
        data = new ArrayList(5500);
        DisplaySearchDialog dsm = new DisplaySearchDialog(inParent, data, inList);
    }

    public int getColumnCount() {
        return 7;
    }

    public int getRowCount() {
        return data.size();
    }

    public String getColumnName(int col) {
        return columnNames[col];
    }

    public Class getColumnClass(int col) {
        return columnClasses[col];
    }

    public void loadFilteredTableData(String inFilterSQL) {
        Connection conn;
        Statement stmt;
        ResultSet rs;
        ProblemRow sr;

        //currentSQL = inFilterSQL;
        data = new ArrayList(5500);
        this.fireTableDataChanged();

        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/meson", "bstephen", "rice37");
            stmt = conn.createStatement();
            rs = stmt.executeQuery(inFilterSQL);
            //System.out.println(inFilterSQL);
            int bds = 0;

            while (rs.next()) {
                sr = new ProblemRow(	rs.getInt("PID"),
                                        rs.getString("years"),
                                        rs.getString("kings"),
                                        rs.getString("gbr"),
                                        rs.getString("stip"),
                                        rs.getString("c.name"),
                                        rs.getString("b.name"));
                data.add(sr);
                bds++;
                //System.out.println(bds);
            }

            conn.close();
            //System.out.println("Before event fired");
            this.fireTableDataChanged();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    public void loadTableData() {
        Connection conn;
        Statement stmt;
        ResultSet rs;
        ProblemRow sr;

        //currentSQL = selectSQL;
        //System.out.println("Entered loadTableData()");
        data = new ArrayList(5500);

        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/meson", "bstephen", "rice37");
            stmt = conn.createStatement();
            rs = stmt.executeQuery(selectSQL);

            while (rs.next()) {
                sr = new ProblemRow(	rs.getInt("PID"),
                                        rs.getString("years"),
                                        rs.getString("kings"),
                                        rs.getString("gbr"),
                                        rs.getString("stip"),
                                        rs.getString("c.name"),
                                        rs.getString("b.name"));
                data.add(sr);
                //System.out.println(rs.getInt("PID"));
            }

            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }

        //System.out.println("Leaving loadTableData()");
    }
}
