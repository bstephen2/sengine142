package uk.me.bstephen.Meson;

public class CurrentPiece {
    private String piece;

    public CurrentPiece() {
        super();
        piece = null;
    }

    public String getPiece() {
        return piece;
    }

    public void setPiece(String inPiece) {
        piece = inPiece;
    }

    public char getCharPiece() {
        return piece.charAt(0);
    }
}