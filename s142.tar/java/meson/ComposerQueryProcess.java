package uk.me.bstephen.Meson;

public class ComposerQueryProcess extends QueryProcess {
    private String composerPattern;

    private String sql =	"SELECT b.name, a.cid, COUNT(*) AS num_comp " +
                            "FROM problemcomposer as a, composer as b " +
                            "WHERE (a.cid = b.cid) AND (b.name REGEXP ?) " +
                            "GROUP BY a.cid " +
                            "ORDER BY num_comp DESC, b.name";

    public ComposerQueryProcess(Meson inParent) {
        super(inParent);
    }

    public void getInfo() {
        ComposerFilterDialog cfd = new ComposerFilterDialog(parent);
        composerPattern = cfd.getComposerPattern();
    }

    public void getSQL() {
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, composerPattern);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    public void showResult() {
        ComposerLeagueQueryResult clqr = new ComposerLeagueQueryResult(parent, rs, "Composer Query - results");
    }

}