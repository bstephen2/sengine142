package uk.me.bstephen.Meson;

import java.util.*;

public abstract class MesonFunc {
    public static HashMap squares;

    public static void init() {
        squares = new HashMap(100);

        squares.put("a8", new Integer(0));
        squares.put("b8", new Integer(1));
        squares.put("c8", new Integer(2));
        squares.put("d8", new Integer(3));
        squares.put("e8", new Integer(4));
        squares.put("f8", new Integer(5));
        squares.put("g8", new Integer(6));
        squares.put("h8", new Integer(7));
        squares.put("a7", new Integer(8));
        squares.put("b7", new Integer(9));
        squares.put("c7", new Integer(10));
        squares.put("d7", new Integer(11));
        squares.put("e7", new Integer(12));
        squares.put("f7", new Integer(13));
        squares.put("g7", new Integer(14));
        squares.put("h7", new Integer(15));
        squares.put("a6", new Integer(16));
        squares.put("b6", new Integer(17));
        squares.put("c6", new Integer(18));
        squares.put("d6", new Integer(19));
        squares.put("e6", new Integer(20));
        squares.put("f6", new Integer(21));
        squares.put("g6", new Integer(22));
        squares.put("h6", new Integer(23));
        squares.put("a5", new Integer(24));
        squares.put("b5", new Integer(25));
        squares.put("c5", new Integer(26));
        squares.put("d5", new Integer(27));
        squares.put("e5", new Integer(28));
        squares.put("f5", new Integer(29));
        squares.put("g5", new Integer(30));
        squares.put("h5", new Integer(31));
        squares.put("a4", new Integer(32));
        squares.put("b4", new Integer(33));
        squares.put("c4", new Integer(34));
        squares.put("d4", new Integer(35));
        squares.put("e4", new Integer(36));
        squares.put("f4", new Integer(37));
        squares.put("g4", new Integer(38));
        squares.put("h4", new Integer(39));
        squares.put("a3", new Integer(40));
        squares.put("b3", new Integer(41));
        squares.put("c3", new Integer(42));
        squares.put("d3", new Integer(43));
        squares.put("e3", new Integer(44));
        squares.put("f3", new Integer(45));
        squares.put("g3", new Integer(46));
        squares.put("h3", new Integer(47));
        squares.put("a2", new Integer(48));
        squares.put("b2", new Integer(49));
        squares.put("c2", new Integer(50));
        squares.put("d2", new Integer(51));
        squares.put("e2", new Integer(52));
        squares.put("f2", new Integer(53));
        squares.put("g2", new Integer(54));
        squares.put("h2", new Integer(55));
        squares.put("a1", new Integer(56));
        squares.put("b1", new Integer(57));
        squares.put("c1", new Integer(58));
        squares.put("d1", new Integer(59));
        squares.put("e1", new Integer(60));
        squares.put("f1", new Integer(61));
        squares.put("g1", new Integer(62));
        squares.put("h1", new Integer(63));
    }

    public static int getElement(String inSq) {
        return ((Integer) squares.get(inSq)).intValue();
    }

}