package uk.me.bstephen.Meson;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
import java.sql.*;
import java.util.*;
import java.io.*;

public class MatchTableModel extends AbstractTableModel {
    private static final String selectSQL = new String("SELECT a.mch, a.pid, a.years, a.kings, a.gbr, a.stip, c.name, b.name " +
            "FROM problem as a, source as b, award as c " +
            "WHERE (a.mch > 50) " +
            "AND (a.sid = b.sid) " +
            "AND (a.aid = c.aid) " +
            "ORDER BY a.mch DESC, a.years, a.kings, a.gbr");

    ArrayList data;

    private Class[] columnClasses = new Class[] { Float.class, Integer.class, String.class, String.class, String.class, String.class, String.class, String.class };
    private String[] columnNames = new String[] { "MATCH", "PID", "Years", "Kings", "GBR", "Stip.", "Award", "Source" };

    public Object getValueAt(int row, int col) {
        MatchRow s = (MatchRow) data.get(row);

        switch (col) {
        case 0	:
            return s.getMch();

        case 1	:
            return s.getPID();

        case 2	:
            return s.getYears();

        case 3	:
            return s.getKings();

        case 4	:
            return s.getGBR();

        case 5	:
            return s.getStip();

        case 6	:
            return s.getAward();

        case 7	:
            return s.getSource();

        default	:
            return null;
        }
    }

    public int getColumnCount() {
        return 8;
    }

    public int getRowCount() {
        return data.size();
    }

    public String getColumnName(int col) {
        return columnNames[col];
    }

    public Class getColumnClass(int col) {
        return columnClasses[col];
    }

    public void loadTableData() {
        Connection conn;
        Statement stmt;
        ResultSet rs;
        MatchRow sr;

        data = new ArrayList(5500);

        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/meson", "bstephen", "rice37");
            stmt = conn.createStatement();
            rs = stmt.executeQuery(selectSQL);

            while (rs.next()) {
                sr = new MatchRow(	rs.getFloat("mch"),
                                    rs.getInt("PID"),
                                    rs.getString("years"),
                                    rs.getString("kings"),
                                    rs.getString("gbr"),
                                    rs.getString("stip"),
                                    rs.getString("c.name"),
                                    rs.getString("b.name"));
                data.add(sr);
            }

            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
}

class MatchRow {
    Float mch;
    Integer pid;
    String years;
    String kings;
    String gbr;
    String stip;
    String award;
    String source;

    public MatchRow(float in_mch, int in_pid, String in_years, String in_kings, String in_gbr, String in_stip, String in_award, String in_source) {
        mch = new Float(in_mch);
        pid = new Integer(in_pid);
        years = new String(in_years);
        kings = new String(in_kings);
        gbr = new String(in_gbr);
        stip = new String(in_stip);
        award = new String(in_award);
        source = new String(in_source);
    }

    public Float getMch() {
        return mch;
    }

    public Integer getPID() {
        return pid;
    }

    public String getYears() {
        return years;
    }

    public String getKings() {
        return kings;
    }

    public String getGBR() {
        return gbr;
    }

    public String getStip() {
        return stip;
    }

    public String getAward() {
        return award;
    }

    public String getSource() {
        return source;
    }
}