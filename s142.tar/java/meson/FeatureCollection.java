package uk.me.bstephen.Meson;

import java.io.*;
import java.util.zip.*;
import java.util.*;
import java.util.regex.*;
import javax.swing.tree.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import org.w3c.dom.*;
import uk.me.bstephen.Chess.*;

public class FeatureCollection {
    private InputStream is;
    private ArrayList generalPatterns;
    private ArrayList setPatterns;
    private ArrayList virtualNodes;
    private ArrayList actualPatterns;
    private DefaultTreeModel classModel;
    private int totalFeatures;
    private boolean setBool;
    private boolean triesBool;

    public FeatureCollection(InputStream inIs, boolean inSet, boolean inTries) {
        Document doc;
        is = inIs;
        setBool = inSet;
        triesBool = inTries;
        generalPatterns = new ArrayList();
        setPatterns = new ArrayList();
        virtualNodes = new ArrayList();
        actualPatterns = new ArrayList();
        MoveNode root;
        MoveNode general;
        MoveNode set;
        MoveNode virtual;
        MoveNode actual;
        MoveNode mn;
        Enumeration topLevels;
        Enumeration generalLines;
        Enumeration setLines;
        Enumeration actualLines;
        Enumeration virtualLines;
        totalFeatures = 0;
        Feature feat;

        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            doc = builder.parse(inIs);
            MoveNode classRoot = classXML2Root(doc);
            classModel = new DefaultTreeModel(classRoot);
            inIs.close();
            root = (MoveNode) classModel.getRoot();
            topLevels = root.children();
            general = (MoveNode) topLevels.nextElement();
            set = (MoveNode) topLevels.nextElement();
            virtual = (MoveNode) topLevels.nextElement();
            actual = (MoveNode) topLevels.nextElement();

            // general

            generalLines = general.children();

            while (generalLines.hasMoreElements() == true) {
                mn = (MoveNode) generalLines.nextElement();
                generalPatterns.add((String) mn.getUserObject());
            }

            totalFeatures += generalPatterns.size();

            //	set

            if (setBool == true) {
                setLines = set.children();

                while (setLines.hasMoreElements() == true) {
                    mn = (MoveNode) setLines.nextElement();
                    feat = new Feature((String) mn.getUserObject());
                    setPatterns.add(feat);
                    totalFeatures += (feat.getOccurs() * 2);
                }
            }

            //	virtual - do virtual later - it's difficult!! - but has to be done on a try/threat match.

            if (triesBool == true) {
            }

            //	actual

            actualLines = actual.children();

            while (actualLines.hasMoreElements() == true) {
                mn = (MoveNode) actualLines.nextElement();
                feat = new Feature((String) mn.getUserObject());
                actualPatterns.add(feat);
                totalFeatures += (feat.getOccurs() * 2);
            }

        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    private MoveNode classXML2Root(Document doc) {
        Element rt = doc.getDocumentElement();
        MoveNode root = new MoveNode(rt.getAttribute("text"));
        this.doElement(rt, root);

        return root;

    }

    private void doElement(Element el, MoveNode mn) {
        int i;
        int l;

        NodeList nl = el.getChildNodes();

        l = nl.getLength();

        for (i = 0; i < l; i++) {
            Element nel = (Element) nl.item(i);
            MoveNode nn = new MoveNode(nel.getAttribute("text"));
            mn.add(nn);
            this.doElement(nel, nn);
        }
    }

    public ArrayList getGeneralPatterns() {
        return generalPatterns;
    }

    public ArrayList getSetPatterns() {
        return setPatterns;
    }

    public ArrayList getActualPatterns() {
        return actualPatterns;
    }

    public Float match(FeatureCollection inTarget) {
        ArrayList hisGeneralPatterns = inTarget.getGeneralPatterns();
        ArrayList hisSetPatterns = inTarget.getSetPatterns();
        ArrayList hisActualPatterns = inTarget.getActualPatterns();
        int score = 0;
        float fScore;
        float fTotalFeatures = (float) totalFeatures;
        Iterator it = generalPatterns.iterator();
        Iterator hit;
        Feature myFeat;
        Feature hisFeat;
        int rs;

        // General
        while (it.hasNext() == true) {
            if (hisGeneralPatterns.contains((String) it.next())) {
                score++;
            }
        }

        // set

        if (setBool == true) {
            it = setPatterns.iterator();

            while (it.hasNext() == true) {
                myFeat = (Feature) it.next();
                hit = hisSetPatterns.iterator();
                SET_LOOP:

                while (hit.hasNext() == true) {
                    hisFeat = (Feature) hit.next();
                    rs = myFeat.match(hisFeat);
                    score += (rs * 2);

                    if (rs != 0) {
                        hit.remove();
                        break SET_LOOP;
                    }
                }
            }
        }

        // tries

        if (triesBool == true) {
        }

        // actual
        it = actualPatterns.iterator();

        while (it.hasNext() == true) {
            myFeat = (Feature) it.next();
            hit = hisActualPatterns.iterator();
            ACTUAL_LOOP:

            while (hit.hasNext() == true) {
                hisFeat = (Feature) hit.next();
                rs = myFeat.match(hisFeat);
                score += (rs * 2);

                if (rs != 0) {
                    hit.remove();
                    break ACTUAL_LOOP;
                }
            }
        }

        fScore = (float) score;
        return new Float((fScore * 100.0) / fTotalFeatures);
    }
}
