package uk.me.bstephen.Meson;

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;
import java.sql.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import org.w3c.dom.Document;
import uk.me.bstephen.Chess.*;

public class SolvingTask extends LongTask {
    private static final String updateSQL01 =	"UPDATE classol " +
            "SET class = COMPRESS(?), sol = COMPRESS(?) " +
            "WHERE pid = ?";
    private String type;
    private String query;
    private DefaultTreeModel classModel;
    private DefaultTreeModel solModel;

    public SolvingTask(String inType, String inQuery) {
        type = inType;
        query = inQuery;
        finished = false;
        count = 0;
    }

    public void run() {
        Connection conn;
        Statement stmt;
        ResultSet rs;
        Problem prb;
        int pid;
        String kings;
        String gbr;
        String position;
        String ep;
        String cast;
        Document solDoc;
        Document classDoc;

        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/meson", "bstephen", "rice37");
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);

            while (rs.next()) {
                pid = rs.getInt("pid");
                kings = rs.getString("kings");
                gbr = rs.getString("gbr");
                position = rs.getString("position");
                ep = rs.getString("ep");
                cast = rs.getString("cast");

                if (type.compareTo("#2") == 0) {
                    prb = new TwoMover();
                } else if (type.compareTo("#3") == 0) {
                    prb = new ThreeMover();
                } else {
                    prb = null;
                }

                System.out.println(pid);
                prb.setPosition(kings, gbr, position, ep, cast);
                prb.setThreats(true);
                prb.solve(true);
                prb.classify(true);
                //MoveNode solRoot = prb.enTreeSolution();
                //MoveNode classRoot = prb.enTreeClassification();
                //solModel = new DefaultTreeModel(solRoot);
                //classModel = new DefaultTreeModel(classRoot);
                solDoc = prb.enXMLSolution();
                classDoc = prb.enXMLClassification();

                ByteArrayOutputStream solBytes = new ByteArrayOutputStream();
                TransformerFactory tf = TransformerFactory.newInstance();
                Transformer transformer = tf.newTransformer();
                DOMSource source = new DOMSource(solDoc);
                StreamResult result = new StreamResult(solBytes);
                transformer.transform(source, result);
                solBytes.close();

                ByteArrayOutputStream classBytes = new ByteArrayOutputStream();
                tf = TransformerFactory.newInstance();
                transformer = tf.newTransformer();
                source = new DOMSource(classDoc);
                result = new StreamResult(classBytes);
                transformer.transform(source, result);
                classBytes.close();

                PreparedStatement pstmt = conn.prepareStatement(updateSQL01);

                pstmt.setBytes(1, classBytes.toByteArray());
                pstmt.setBytes(2, solBytes.toByteArray());
                pstmt.setInt(3, pid);
                pstmt.execute();
                count++;
            }

            rs.close();
            stmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }

        finished = true;
    }
}
