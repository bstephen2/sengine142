package uk.me.bstephen.Meson;

import java.util.*;
import java.sql.*;
import java.io.*;

public class SearchTask extends LongTask {
    private static final String featureSQL = new String(	"SELECT a.pid, a.years, a.kings, a.gbr, a.stip, a.class, c.name, b.name " +
            "FROM problem as a, source as b, award as c " +
            "WHERE (a.stip = '#2') " +
            "AND (a.sid = b.sid) " +
            "AND (a.aid = c.aid) " +
            "ORDER BY a.years, a.kings, a.gbr");

    ArrayList data;
    StaticFeatureList sfl;

    public SearchTask(ArrayList inData, StaticFeatureList inList) {
        data = inData;
        sfl = inList;
        finished = false;
        count = 0;
    }

    public void run() {
        Connection conn;
        Statement stmt;
        ResultSet rs;
        //ProblemRow sr;
        //String SQLWithAddedClass;

        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/meson", "bstephen", "rice37");
            stmt = conn.createStatement();
            rs = stmt.executeQuery(featureSQL);

            while (rs.next()) {
                if (sfl.isAHit(rs.getBinaryStream("a.class")) == true) {
                    //sr = new ProblemRow(	rs.getInt("PID"),
                    //rs.getString("years"),
                    //rs.getString("kings"),
                    //rs.getString("gbr"),
                    //rs.getString("stip"),
                    //rs.getString("c.name"),
                    //rs.getString("b.name"));
                    //data.add(sr);
                }

                count++;
            }

            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }

        finished = true;
    }
}