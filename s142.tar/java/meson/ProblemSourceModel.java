package uk.me.bstephen.Meson;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
import java.sql.*;
import java.util.*;

public class ProblemSourceModel extends AbstractTableModel {
    ArrayList data;

    private Class[] columnClasses = new Class[] { Integer.class, String.class, String.class };
    private String[] columnNames = new String[] { "SID", "Name", "Years" };

    public ProblemSourceModel() {
        super();
        data = new ArrayList(10);
    }

    public Object getValueAt(int row, int col) {
        ProblemSourceRow s = (ProblemSourceRow) data.get(row);

        switch (col) {
        case 0	:
            return s.getSID();

        case 1	:
            return s.getName();

        case 2	:
            return s.getYears();

        default	:
            return null;
        }
    }

    public void addElement(int in_sid, String in_name, String in_years) {
        ProblemSourceRow psr = new ProblemSourceRow(in_sid, in_name, in_years);
        data.add(psr);
    }

    public int getColumnCount() {
        return 3;
    }

    public int getRowCount() {
        return data.size();
    }

    public String getColumnName(int col) {
        return columnNames[col];
    }

    public Class getColumnClass(int col) {
        return columnClasses[col];
    }
}

class ProblemSourceRow {
    Integer sid;
    String name;
    String years;

    public ProblemSourceRow(int in_sid, String in_name, String in_years) {
        sid = new Integer(in_sid);
        name = new String(in_name);
        years = new String(in_years);
    }

    public Integer getSID() {
        return sid;
    }

    public String getName() {
        return name;
    }

    public String getYears() {
        return years;
    }
}