package uk.me.bstephen.Meson;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import java.sql.*;

public class SolvingDialog extends TaskDialog {
    private String inQuery;
    private String inCount;
    private String inType;

    public SolvingDialog(Meson inParent, String type, String query, String count) {
        super(inParent, "Solving ...");
        inQuery = query;
        inCount = count;
        inType = type;
        this.process();
    }

    public int getTarget() {
        Connection conn;
        Statement stmt;
        ResultSet rs;
        int rval = 0;

        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/meson", "bstephen", "rice37");
            stmt = conn.createStatement();
            System.out.println(inCount);
            rs = stmt.executeQuery(inCount);
            rs.next();
            rval = rs.getInt("total");
            rs.close();
            stmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }

        return rval;
    }

    public void runBackgroundProcess() {
        task = new SolvingTask(inType, inQuery);
        task.start();
        timer.start();
    }

    public void tidyUp() {
    }
}
