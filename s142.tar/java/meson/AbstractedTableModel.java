package uk.me.bstephen.Meson;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
import java.sql.*;
import java.util.*;

public class AbstractedTableModel extends AbstractTableModel {
    private static final String selectSQL = new String("SELECT a.year, b.name, a.done, a.hague, a.next " +
            "FROM abstracted as a, source as b " +
            "WHERE " +
            "(a.sid = b.sid)" +
            "ORDER BY a.year");

    ArrayList data;

    private Class[] columnClasses = new Class[] { String.class, String.class, Boolean.class, String.class, String.class };
    private String[] columnNames = new String[] { "Year", "Name", "Done?", "Hague", "Next" };

    public Object getValueAt(int row, int col) {
        AbstractedRow s = (AbstractedRow) data.get(row);

        switch (col) {
        case 0	:
            return s.getYear();

        case 1	:
            return s.getName();

        case 2	:
            return s.getDone();

        case 3	:
            return s.getHague();

        case 4	:
            return s.getNext();

        default	:
            return null;
        }
    }

    public int getColumnCount() {
        return 5;
    }

    public int getRowCount() {
        return data.size();
    }

    public String getColumnName(int col) {
        return columnNames[col];
    }

    public Class getColumnClass(int col) {
        return columnClasses[col];
    }

    public void loadTableData() {
        Connection conn;
        Statement stmt;
        ResultSet rs;
        AbstractedRow sr;

        data = new ArrayList(500);

        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/meson", "bstephen", "rice37");
            stmt = conn.createStatement();
            rs = stmt.executeQuery(selectSQL);

            while (rs.next()) {
                sr = new AbstractedRow(	rs.getString("year"),
                                        rs.getString("name"),
                                        rs.getByte("done"),
                                        rs.getString("hague"),
                                        rs.getString("next"));
                data.add(sr);
            }

            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
}

class AbstractedRow {
    String year;
    String name;
    Boolean done;
    String hague;
    String next;

    public AbstractedRow(String in_year, String in_name, byte in_done, String in_hague, String in_next) {
        year = new String(in_year);
        name = new String(in_name);
        done = new Boolean(in_done == 0 ? false : true);
        hague = new String(in_hague);
        next = new String(in_next);
    }

    public String getYear() {
        return year;
    }

    public String getName() {
        return name;
    }

    public Boolean getDone() {
        return done;
    }

    public String getHague() {
        return hague;
    }

    public String getNext() {
        return next;
    }
}