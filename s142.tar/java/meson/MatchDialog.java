package uk.me.bstephen.Meson;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;

public class MatchDialog extends JDialog {
    private Font boldArial14;
    private Point p;
    private GridBagConstraints gbc;
    private boolean set;
    private boolean tries;
    private boolean isCancelled;
    private final JCheckBox setCheck = new JCheckBox("Set");
    private final JCheckBox triesCheck = new JCheckBox("Tries");

    public MatchDialog(Meson inParent) {
        super(inParent, "Include Set/Tries in match?", true);
        p = inParent.getLocationOnScreen();

        this.setBounds(p.x + 20, p.y + 60, 200, 400);
        Container cPane = this.getContentPane();
        cPane.setLayout(new GridBagLayout());
        this.setResizable(false);

        boldArial14 = new Font("Arial", Font.BOLD, 14);

        gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.NONE;
        gbc.weightx = 0;
        gbc.weighty = 0;
        gbc.ipadx = 0;
        gbc.ipady = 0;
        gbc.insets = new Insets(5, 5, 5, 5);

        set = false;
        tries = false;
        isCancelled = false;

        CHECK_BOXES: {
            setCheck.setSelected(false);
            setCheck.setFont(boldArial14);

            gbc.gridx = 1;
            gbc.gridy = 1;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;
            gbc.anchor = GridBagConstraints.FIRST_LINE_START;

            cPane.add(setCheck, gbc);

            triesCheck.setSelected(false);
            triesCheck.setFont(boldArial14);
            triesCheck.setEnabled(false);

            gbc.gridx = 1;
            gbc.gridy = 2;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;
            gbc.anchor = GridBagConstraints.FIRST_LINE_START;

            cPane.add(triesCheck, gbc);
        }

        BUTTONS: {
            JPanel buttons = new JPanel();
            buttons.setLayout(new FlowLayout(FlowLayout.RIGHT, 4, 4));
            JButton okButton = new JButton("OK");
            okButton.setFont(boldArial14);


            okButton.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    set = setCheck.isSelected();
                    tries = triesCheck.isSelected();
                    MatchDialog.this.setVisible(false);
                }
            }
            );

            JButton cancelButton = new JButton("Cancel");
            cancelButton.setFont(boldArial14);

            cancelButton.addActionListener
            (
            new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    MatchDialog.this.setVisible(false);
                    isCancelled = true;
                }
            }
            );

            buttons.add(okButton);
            buttons.add(cancelButton);

            gbc.gridx = 1;
            gbc.gridy = 3;
            gbc.gridwidth = 1;
            gbc.gridheight = 1;
            gbc.anchor = GridBagConstraints.LAST_LINE_END;

            cPane.add(buttons, gbc);
        }

        this.pack();
        this.setVisible(true);
    }

    public boolean getCancelled() {
        return isCancelled;
    }

    public boolean getSet() {
        return set;
    }

    public boolean getTries() {
        return tries;
    }
}
