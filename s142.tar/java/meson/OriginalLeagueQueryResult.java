package uk.me.bstephen.Meson;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import java.sql.*;
import java.text.*;

public class OriginalLeagueQueryResult extends QueryResult {
    public OriginalLeagueQueryResult(Meson inParent, ResultSet rs, String title) {
        super(inParent, rs, title);
    }

    public void paintResult() {
        OriginalLeagueModel olm = new OriginalLeagueModel(rs);
        olm.loadTableData();

        JTable OLTable = new JTable(olm);
        OLTable.setPreferredScrollableViewportSize(new Dimension(600, 400));
        OLTable.setFont(boldCourier14);
        OLTable.setRowSelectionAllowed(false);

        TableColumn total = OLTable.getColumn("num_origs");
        total.setMaxWidth(120);
        total.setMinWidth(120);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.gridheight = 5;
        gbc.anchor = GridBagConstraints.CENTER;

        cPane.add(new JScrollPane(OLTable), gbc);
    }
}