package uk.me.bstephen.Meson;

public class AwardLeagueQueryProcess extends QueryProcess {
    private String sql =	"SELECT b.name, a.aid, COUNT(*) AS num_award " +
                            "FROM problem as a, award as b " +
                            "WHERE (a.aid = b.aid) " +
                            "GROUP BY a.aid " +
                            "ORDER BY num_award DESC, b.name";

    public AwardLeagueQueryProcess(Meson inParent) {
        super(inParent);
    }

    public void getInfo() {
    }

    public void getSQL() {
        try {
            pstmt = conn.prepareStatement(sql);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    public void showResult() {
        AwardLeagueQueryResult alqr = new AwardLeagueQueryResult(parent, rs, "Award League Query - results");
    }
}