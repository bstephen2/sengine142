package uk.me.bstephen.Meson;

import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

public class DisplaySquare extends JTextField implements MouseListener {
    private String square;
    private String colour;
    private char cc;
    CurrentPiece cp;

    public DisplaySquare(String inColour, String inSquare, CurrentPiece inCp) {
        super(inColour, 1);
        colour = inColour;
        cc = colour.charAt(0);
        square = inSquare;
        cp = inCp;
        this.setFont(new Font("LinaresDiagram", Font.PLAIN, 33));
        this.setMargin(new Insets(0, 0, 0, 0));
        this.addMouseListener(this);
    }

    public String getSquare() {
        return square;
    }

    public void mousePressed(MouseEvent e) {
    }

    public void mouseReleased(MouseEvent e) {
    }

    public void mouseEntered(MouseEvent e) {
    }

    public void mouseExited(MouseEvent e) {
    }

    public void mouseClicked(MouseEvent e) {
        if (e.getClickCount() == 1) {
            char p = cp.getCharPiece();

            if (cc == 'w') {
                switch (p) {
                case 'K'	:
                    this.setText("K");
                    break;

                case 'k'	:
                    this.setText("k");
                    break;

                case 'Q'	:
                    this.setText("Q");
                    break;

                case 'q'	:
                    this.setText("q");
                    break;

                case 'R'	:
                    this.setText("R");
                    break;

                case 'r'	:
                    this.setText("r");
                    break;

                case 'B'	:
                    this.setText("B");
                    break;

                case 'b'	:
                    this.setText("b");
                    break;

                case 'N'	:
                    this.setText("N");
                    break;

                case 'n'	:
                    this.setText("n");
                    break;

                case 'P'	:
                    this.setText("P");
                    break;

                case 'p'	:
                    this.setText("p");
                    break;

                default:
                }
            } else if (cc == 'd') {
                switch (p) {
                case 'K'	:
                    this.setText("I");
                    break;

                case 'k'	:
                    this.setText("i");
                    break;

                case 'Q'	:
                    this.setText("!");
                    break;

                case 'q'	:
                    this.setText("1");
                    break;

                case 'R'	:
                    this.setText("$");
                    break;

                case 'r'	:
                    this.setText("4");
                    break;

                case 'B'	:
                    this.setText("G");
                    break;

                case 'b'	:
                    this.setText("g");
                    break;

                case 'N'	:
                    this.setText("H");
                    break;

                case 'n'	:
                    this.setText("h");
                    break;

                case 'P'	:
                    this.setText(")");
                    break;

                case 'p'	:
                    this.setText("0");
                    break;

                default:
                }
            }
        } else if (e.getClickCount() == 2) {
            this.setText(colour);
        }
    }
}