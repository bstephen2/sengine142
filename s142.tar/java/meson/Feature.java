package uk.me.bstephen.Meson;

import java.util.*;
import java.util.regex.*;


public class Feature {
    private static final Pattern threatPatt = Pattern.compile("^(THREAT_.+)\\(([A-Z])\\)(.*)\\(x([0-9]+)\\)$");

    private static final Pattern TryKeyPatt = Pattern.compile("^(KEY_|TRY_)(.+)\\(([A-Z])\\)(.*)\\(x([0-9]+)\\)$");

    private static final Pattern dualPatt = Pattern.compile("^(.)\\(([a-z])\\)(.*)(/DUALS)\\(x([0-9]+)\\)$");

    private static final Pattern refutPatt = Pattern.compile("^REFUTATION\\(x([0-9]+)\\)$");

    private static final Pattern variationPatt = Pattern.compile("\\(([a-z])\\)(.*)/(.+)\\(([A-Z])\\)(.*)\\(x([0-9]+)\\)$");

    private String text;
    private char firstPiece;
    private char secondPiece;
    private int occurs;

    public Feature(String inText) {
        MATCH_BLOCK: {
            Matcher mr = threatPatt.matcher(inText);

            if (mr.find() == true) {
                occurs = Integer.parseInt(mr.group(4));
                firstPiece = mr.group(2).charAt(0);
                secondPiece = '1';
                text = mr.group(1) + mr.group(3);
                break MATCH_BLOCK;
            }

            mr = TryKeyPatt.matcher(inText);

            if (mr.find() == true) {
                occurs = Integer.parseInt(mr.group(5));
                firstPiece = mr.group(3).charAt(0);
                secondPiece = '1';
                text = mr.group(1) + mr.group(2) + mr.group(4);
                break MATCH_BLOCK;
            }

            mr = dualPatt.matcher(inText);

            if (mr.find() == true) {
                occurs = Integer.parseInt(mr.group(5));
                firstPiece = mr.group(2).charAt(0);
                secondPiece = '1';
                text = mr.group(1) + mr.group(3) + mr.group(4);
                break MATCH_BLOCK;
            }

            mr = refutPatt.matcher(inText);

            if (mr.find() == true) {
                firstPiece = '1';
                secondPiece = '1';
                occurs = Integer.parseInt(mr.group(1));
                text = "REFUTATION";
                break MATCH_BLOCK;
            }

            mr = variationPatt.matcher(inText);

            if (mr.find() == true) {
                firstPiece = mr.group(1).charAt(0);
                secondPiece = mr.group(4).charAt(0);
                occurs = Integer.parseInt(mr.group(6));
                text = inText.substring(0, mr.start()) + mr.group(2) + mr.group(3) + mr.group(5);
                break MATCH_BLOCK;
            }

            System.out.print("BAD PATTERN3 ");
            System.out.println(inText);
            System.exit(1);
        }
    }

    public int getOccurs() {
        return occurs;
    }

    public String getText() {
        return text;
    }

    public char getFirstPiece() {
        return firstPiece;
    }

    public char getSecondPiece() {
        return secondPiece;
    }

    public int match(Feature inFeature) {
        if (text.compareTo(inFeature.getText()) != 0) {
            return 0;
        }

        if (occurs > inFeature.getOccurs()) {
            return inFeature.getOccurs();
        } else {
            return occurs;
        }
    }
}
