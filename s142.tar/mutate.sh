#!/bin/bash
	sengine142	--kings=h1f4 \
					--gbr=0218.41 \
					--pos=h5g2e7c5g1b5g5d4e4g4d2f6 \
					--moves=2 \
					--stip=# \
					--actual \
					--set \
					--tries \
					--fleck \
					--meson \
					--classify
echo "Return Code = $?"
exit 0
