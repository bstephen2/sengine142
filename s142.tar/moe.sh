#!/bin/bash
	sengine142	--kings=a5e4 \
					--gbr=4255.44 \
					--pos=h7f5e8h4b6g4b8c7g6g8e5d4c2d2h6h5c4f3 \
					--moves=2 \
					--stip=# \
					--actual \
					--set \
					--fleck \
					--meson \
					--classify
echo "Return Code = $?"
exit 0
