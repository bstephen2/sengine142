#!/bin/bash
valgrind --leak-check=full \
	sengine142	--kings=a1d6 \
					--gbr=3222.40 \
					--pos=g4e7e4a8f8d7g3f7b6g6e2 \
					--moves=2 \
					--stip=# \
					--actual \
					--set \
					--tries \
					--fleck \
					--meson \
					--classify
echo "Return Code = $?"
exit 0
