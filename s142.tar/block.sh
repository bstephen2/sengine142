#!/bin/bash
	sengine142	--kings=c5a5 \
					--gbr=0010.21 \
					--pos=h5b2b5a4 \
					--moves=2 \
					--stip=# \
					--actual \
					--set \
					--tries \
					--fleck \
					--meson \
					--classify
echo "Return Code = $?"
exit 0
