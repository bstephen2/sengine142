#!/bin/bash
valgrind --leak-check=full \
	sengine142	--kings=a4a6 \
					--gbr=1170.02 \
					--pos=e4b7e3a8c5d7d6 \
					--moves=2 \
					--stip=# \
					--actual \
					--set \
					--tries \
					--fleck \
					--meson \
					--classify
echo "Return Code = $?"
exit 0
